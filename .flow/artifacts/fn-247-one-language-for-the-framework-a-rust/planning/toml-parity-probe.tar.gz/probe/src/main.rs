use std::{env, fs};
fn main() {
    println!("experimental_unbounded={}", cfg!(feature = "experimental-unbounded"));
    for path in env::args().skip(1) {
        let raw = fs::read_to_string(&path).expect("read probe input");
        match toml::de::DeTable::parse(&raw) {
            Err(e) => println!("{path} REFUSE {e}"),
            Ok(table) => {
                let (_, value) = table.get_ref().iter().next().expect("probe has a key");
                let value = value.get_ref();
                if let Some(integer) = value.as_integer() {
                    println!("{path} ACCEPT integer digits={} radix={}", integer.as_str(), integer.radix());
                } else if let Some(date) = value.as_datetime() {
                    println!("{path} ACCEPT datetime={date:?}");
                } else if let Some(string) = value.as_str() {
                    println!("{path} ACCEPT string={string:?}");
                } else {
                    println!("{path} ACCEPT type={}", value.type_str());
                }
            }
        }
    }
}
