from pathlib import Path
import subprocess, os, json, hashlib, tomllib, sys
repo=Path(__file__).resolve().parents[3]
root=Path(__file__).resolve().parent
logs=root/"logs"; logs.mkdir(exist_ok=True)
env=dict(os.environ,CARGO_BUILD_JOBS="1",CARGO_TARGET_DIR=str(repo/".flow/tmp/fn247-toml-probe-target"),CARGO_NET_OFFLINE="true")
commands=[]
def run(label,argv):
    p=subprocess.run(argv,cwd=root,env=env,capture_output=True,text=True)
    (logs/(label+".stdout")).write_text(p.stdout); (logs/(label+".stderr")).write_text(p.stderr)
    commands.append(dict(label=label,argv=argv,cwd=str(root),exit=p.returncode))
    (logs/"commands.json").write_text(json.dumps(commands,indent=2))
    if p.returncode: raise SystemExit(f"STOP {label} exit={p.returncode}")
    return p.stdout
run("cargo-version",["cargo","+1.99.1","--version"])
run("rustc-version",["rustc","+1.99.1","-Vv"])
run("metadata",["cargo","+1.99.1","metadata","--offline","--format-version","1"])
allowed={(p["name"],p["version"],p.get("source"),p.get("checksum")) for p in tomllib.loads((repo/"model/Cargo.lock").read_text())["package"]}
resolved=tomllib.loads((root/"Cargo.lock").read_text())["package"]
extra=[p for p in resolved if p.get("source") and (p["name"],p["version"],p.get("source"),p.get("checksum")) not in allowed]
(logs/"resolver-subset.json").write_text(json.dumps(dict(extra=extra,resolved=resolved),indent=2))
if extra: raise SystemExit("STOP unapproved resolved third-party package")
inputs=sorted((root/"cases").glob("*.toml"))
reference=[]
for path in inputs:
    try: reference.append(dict(case=path.name,status="ACCEPT",value=repr(tomllib.loads(path.read_text()))))
    except Exception as e: reference.append(dict(case=path.name,status="REFUSE",error=type(e).__name__+": "+str(e)))
(logs/"python-reference.json").write_text(json.dumps(dict(version=sys.version,recursion=sys.getrecursionlimit(),int_digits=sys.get_int_max_str_digits(),results=reference),indent=2))
for label,args in [("approved",[]),("experimental-unbounded",["--features","experimental-unbounded"])]:
    run(label+"-build",["cargo","+1.99.1","build","--offline","--locked",*args])
    run(label+"-run",[str(Path(env["CARGO_TARGET_DIR"])/"debug/fn247-toml-probe"),*[str(p) for p in inputs]])
    binary=Path(env["CARGO_TARGET_DIR"])/"debug/fn247-toml-probe"
    (logs/(label+"-binary.sha256")).write_text(hashlib.sha256(binary.read_bytes()).hexdigest()+"  "+str(binary)+"\n")
files=[root/"Cargo.toml",root/"Cargo.lock",root/"src/main.rs",root/"run_probe.py",repo/"model/Cargo.lock",*inputs]
(logs/"input-hashes.json").write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
print("probe complete; "+str(logs))
