import subprocess,os,pathlib,json,time,shutil
base=pathlib.Path(__file__).resolve().parent
root=pathlib.Path('/Users/stephan/Workspace/skunkworks/umpire/temporal/.worktrees/fn25416-provider-adapt/model')
env=os.environ.copy();env.pop('BASH_ENV',None);env.update(CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(base/'target'),MISE_AUTO_INSTALL='false',MISE_EXEC_AUTO_INSTALL='false',UMPIRE_BACKENDS='skip',UMPIRE_APALACHE='skip')
checks=[
 ('final-provider-unit',root/'umpire',['cargo','nextest','run','--locked','-p','umpire-backend-process','--lib','--profile','required','--test-threads','1','--no-tests','fail']),
 ('framework-clippy-final',root/'umpire',['cargo','clippy','--locked','-p','umpire-backend-process','-p','xtask','-p','umpire-tlc','-p','umpire-apalache','--all-targets','--all-features','--','-D','warnings']),
 ('system-clippy-final',root,['cargo','clippy','--locked','-p','temporal-xtask','--all-targets','--all-features','--','-D','warnings']),
 ('framework-fmt-final',root/'umpire',['cargo','fmt','--all','--check']),
 ('system-fmt-final',root,['cargo','fmt','--all','--check']),
]
records=[]
for label,cwd,args in checks:
 free=shutil.disk_usage(base).free
 assert free>=30*1024**3,free
 command=['mise','exec','--',*args];start=time.monotonic()
 with (base/(label+'.log')).open('wb') as out:r=subprocess.run(command,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
 records.append({'label':label,'command':command,'cwd':str(cwd),'exit':r.returncode,'seconds':time.monotonic()-start,'free_before_bytes':free,'free_after_bytes':shutil.disk_usage(base).free})
 (base/'final-focused-checks.json').write_text(json.dumps(records,indent=2)+'\n');print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
