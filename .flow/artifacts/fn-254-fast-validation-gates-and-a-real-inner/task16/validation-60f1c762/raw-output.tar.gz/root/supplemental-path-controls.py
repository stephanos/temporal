from pathlib import Path
import importlib.util,json,os
base=Path(__file__).resolve().parent/'frozen-provider-controls'
spec=importlib.util.spec_from_file_location('runtime',base/'provider-runtime.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.RECORDS=json.loads((base/'runtime-results.json').read_text())
for tool,(relative,_) in m.JARS.items():
 components=Path('build/mise-jars/data/installs').joinpath(relative).parts
 for dangling in [False,True]:
  for index in range(len(components)):
   label=f'{tool}-path-{index}-'+('dangling' if dangling else 'existing')
   root=m.root(label);target=root.joinpath(*components[:index+1]);target.parent.mkdir(parents=True,exist_ok=True)
   outside=root/'outside'
   if not dangling:outside.mkdir()
   target.symlink_to(outside)
   m.admit(label,root,tool,False,'symlink')
   if outside.exists():assert not list(outside.iterdir())
clean=m.RUNTIME/'clean';legacy=clean/'build/apalache/.install.lock';legacy.parent.mkdir(exist_ok=True)
assert not legacy.exists()
os.mkfifo(legacy)
try:m.install('obsolete-fifo-lock-not-consumed',clean,'apalache')
finally:legacy.unlink()
outside=clean/'legacy-lock-outside';outside.write_text('unchanged');legacy.symlink_to(outside)
try:
 m.install('obsolete-symlink-lock-not-consumed',clean,'apalache');assert outside.read_text()=='unchanged'
finally:legacy.unlink()
cleanup=[]
for path in m.RUNTIME.glob('*/build/mise-jars/runs'):
 assert not list(path.iterdir()),path
 cleanup.append(str(path))
(base/'capture-cleanup.json').write_text(json.dumps({'all_empty':True,'paths':cleanup},indent=2)+'\n')
print('supplemental path controls complete',flush=True)
