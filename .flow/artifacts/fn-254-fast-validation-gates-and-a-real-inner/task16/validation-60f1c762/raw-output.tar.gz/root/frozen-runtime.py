from pathlib import Path
import subprocess,json,hashlib,shutil,importlib.util,sys
base=Path(__file__).resolve().parent
folder=base/'frozen-provider-controls';folder.mkdir(exist_ok=False)
for name in ['provider-runtime.py','provider-negative.py','provider_probe.rs']:
 shutil.copy2(base/'final-provider-controls'/name,folder/name)
artifacts={}
for line in (base/'frozen-runtime-build.jsonl').read_text().splitlines():
 row=json.loads(line)
 if row.get('reason')=='compiler-artifact' and row['target']['name'] in ['umpire_backend_process','umpire_tlc','umpire_apalache','umpire_tla']:
  for file in row['filenames']:
   if file.endswith('.rlib'):artifacts[row['target']['name']]=file
assert len(artifacts)==4,artifacts
command=['/home/agent/.rustup/toolchains/1.99.1-aarch64-unknown-linux-gnu/bin/rustc','--edition=2024',str(folder/'provider_probe.rs'),'-L',f'dependency={base}/target/debug/deps','-o',str(folder/'provider-probe')]
for name,file in artifacts.items():command+=['--extern',f'{name}={file}']
(folder/'probe-compile-command.json').write_text(json.dumps(command,indent=2)+'\n')
with (folder/'probe-compile.log').open('wb') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0
spec=importlib.util.spec_from_file_location('proof',base/'standalone-prepared/proof.py');proof=importlib.util.module_from_spec(spec);spec.loader.exec_module(proof)
source=proof.ROOT;before=proof.snapshot(source);assert before['head']=='d4a79702ce170f35698fe736fb72792f55c2d3af'
(folder/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
files=[base/'target/debug/xtask',folder/'provider-probe',*map(Path,artifacts.values())]
(folder/'binaries.json').write_text(json.dumps({str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files},indent=2)+'\n')
for phase in ['positive','negative']:
 script=folder/('provider-runtime.py' if phase=='positive' else 'provider-negative.py');command=[sys.executable,str(script)]
 if phase=='positive':command+=['--phase','positive']
 with (folder/('runtime-'+phase+'.log')).open('wb') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 print(phase,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
after=proof.snapshot(source);assert before==after
(folder/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
print('frozen runtime evidence complete',flush=True)
