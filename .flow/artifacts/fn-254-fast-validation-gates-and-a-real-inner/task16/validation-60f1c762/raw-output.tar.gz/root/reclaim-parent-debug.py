from pathlib import Path
import os,json,hashlib,shutil,stat,time
BASE=Path(__file__).resolve().parent
ROOT=BASE/'target/debug'
assert ROOT.is_dir() and not ROOT.is_symlink() and ROOT.resolve()==ROOT
BLOCKED=[]
for process in Path('/proc').iterdir():
 if not process.name.isdigit():continue
 try:
  executable=os.readlink(process/'exe');cwd=os.readlink(process/'cwd')
  args=(process/'cmdline').read_bytes().split(b'\0')
  environment=dict(item.split(b'=',1) for item in (process/'environ').read_bytes().split(b'\0') if b'=' in item)
 except (OSError,ValueError):continue
 compiler=Path(executable).name in ['cargo','rustc','clippy-driver','rustdoc','cargo-clippy','cargo-nextest']
 in_root=lambda value: value==str(ROOT) or value.startswith(str(ROOT)+'/')
 relevant=in_root(executable.removesuffix(' (deleted)')) or in_root(cwd)
 relevant|=compiler and (environment.get(b'CARGO_TARGET_DIR') in [os.fsencode(ROOT),os.fsencode(ROOT.parent)] or any(os.fsencode(ROOT) in arg for arg in args))
 if relevant:BLOCKED.append({'pid':int(process.name),'executable':executable,'cwd':cwd})
assert not BLOCKED,BLOCKED
preserved=BASE/'protected-native/60f1c762/current-normal-debug-xtask'
source=ROOT/'xtask';shutil.copy2(source,preserved);digest=hashlib.sha256(source.read_bytes()).hexdigest();assert hashlib.sha256(preserved.read_bytes()).hexdigest()==digest
selected=[];kept=[];symlinks=[]
for directory,dirs,files in os.walk(ROOT,followlinks=False):
 parent=Path(directory)
 for name in list(dirs):
  p=parent/name
  if p.is_symlink():symlinks.append({'path':str(p),'target_hex':os.fsencode(os.readlink(p)).hex()});dirs.remove(name)
 for name in files:
  path=parent/name;info=path.lstat()
  if stat.S_ISLNK(info.st_mode):symlinks.append({'path':str(path),'target_hex':os.fsencode(os.readlink(path)).hex()});continue
  assert stat.S_ISREG(info.st_mode),(path,info.st_mode)
  assert info.st_uid==os.getuid(),(path,info.st_uid,os.getuid())
  assert path.resolve().is_relative_to(ROOT)
  item={'path':str(path),'bytes':info.st_size,'device':info.st_dev,'inode':info.st_ino}
  relative=path.relative_to(ROOT)
  if path.suffix in ['.rlib','.rmeta','.o','.d'] or relative.parts[0]=='incremental':selected.append(item)
  else:item['sha256']=hashlib.sha256(path.read_bytes()).hexdigest();kept.append(item)
free_before=shutil.disk_usage(BASE).free
for item in selected:
 path=Path(item['path']);info=path.lstat()
 assert not path.is_symlink() and (info.st_dev,info.st_ino,info.st_size)==(item['device'],item['inode'],item['bytes'])
 assert path.resolve().is_relative_to(ROOT)
 for parent in path.parents:
  if parent==ROOT:break
  assert not parent.is_symlink()
 path.unlink()
for item in kept:
 path=Path(item['path']);assert path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
for item in symlinks:assert os.fsencode(os.readlink(item['path'])).hex()==item['target_hex']
receipt=json.loads((BASE/'standalone-native-build-final.json').read_text())
for name,meta in receipt['binaries'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==meta['sha256']
row={'scope':str(ROOT),'source_head':'60f1c762a618d32478b58ae4e79c151f4355aeb3','owner_release':'Parent authorization after all task16 proof processes terminated; normal debug compiler outputs idle. Parent xtask-bootstrap, child targets, runtime/proof files remain protected.','live_process_check':BLOCKED,'removed_files':len(selected),'removed_apparent_bytes':sum(item['bytes'] for item in selected),'free_before_bytes':free_before,'free_after_bytes':shutil.disk_usage(BASE).free,'preserved_normal_debug_xtask':{'path':str(preserved),'sha256':digest},'noncompiler_files_verified':len(kept),'symlinks_preserved':len(symlinks),'proof_native_hashes_verified':True,'guard_baseline_changed':False,'baseline_event':'Terminal-state cleanup only. Any future run takes a fresh unchanged-policy census baseline; no running proof or guard changed.','removed':selected,'kept':kept,'symlinks':symlinks}
(BASE/'parent-debug-reclaim.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k not in ['removed','kept','symlinks']},indent=2))
