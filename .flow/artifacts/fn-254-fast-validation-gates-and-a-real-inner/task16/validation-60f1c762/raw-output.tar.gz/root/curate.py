from pathlib import Path
import json,hashlib,gzip,shutil,tarfile,subprocess,os,re,sys
BASE=Path(__file__).resolve().parent
ROOT=Path('/Users/stephan/Workspace/skunkworks/umpire/temporal/.worktrees/fn25416-provider-adapt')
HEAD='60f1c762a618d32478b58ae4e79c151f4355aeb3'
PROOF=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else BASE/'standalone-60f1c762'
OUT=BASE/'curated-task16'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
def write(name,data):
 path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2)+'\n')
def copy(source,name):
 path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,path)
validation=read(PROOF/'validation.json')
assert validation['accepted'] and validation['head']==HEAD
assert validation['cleanup']['all_observed_owned_pids_absent']
assert read(PROOF/'source-before.json')==read(PROOF/'source-after.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
OUT.mkdir(exist_ok=False)
old=read(BASE/'frozen-provider-controls/source-before.json')
assert old['head']=='d4a79702ce170f35698fe736fb72792f55c2d3af'
materials=['model/umpire/mise-tools/'+x for x in ['mise.toml','mise.apalache.toml','empty.toml','mise.lock','mise.apalache.lock']]
materials+=['model/umpire/mise.toml','model/umpire/mise.lock','model/Cargo.lock','model/umpire/Cargo.lock','model/umpire/backends/process/src/jar.rs','model/umpire/backends/process/src/support.rs','model/umpire/backends/process/src/syscall.rs','model/umpire/backends/process/src/work.rs','model/umpire/backends/tlc/src/runner.rs','model/umpire/backends/apalache/src/lib.rs','model/umpire/dev/xtask/src/fetch_apalache.rs','model/umpire/dev/xtask/src/main.rs','model/umpire/dev/xtask/src/gate/standalone.rs','model/dev/xtask/src/gate.rs']
identities={}
for name in materials:
 digest=sha(ROOT/name);assert digest==old['files'][name],name;identities[name]=digest
for name in ['default-tools','opt-in-tools']:
 data=json.loads((BASE/'frozen-provider-controls'/f'{name}.stdout').read_text())
 expected={'http:tlc'} if name=='default-tools' else {'http:tlc','http:apalache'}
 assert set(data)==expected,(name,set(data))
diff=subprocess.check_output(['git','diff',old['head'],HEAD,'--','model'],cwd=ROOT)
write('input-reuse.json',{'older_runtime_head':old['head'],'current_source_head':HEAD,'older_evidence':'runtime/','unchanged_material_inputs':identities,'current_diff_sha256':hashlib.sha256(diff).hexdigest(),'reason':'Only a generic comment, canonical UTF8/path-list provider-root admission, matching tests and documentation changed after D4. Successful frozen runtime directories are UTF8 and path-list representable; join_paths preserves their single-path byte values. Current native CLI controls verify supported spaces/quotes/metacharacters and both named refusal modes. The current full standalone validates the final source and changed TLC artifact path. Older D4 binaries are explicitly older evidence, never labeled current.','normal_path_checks':'post-pathlist-checks.json','older_binary_retention':'older-runtime-retention.json'})
copy(BASE/'control-mapping.json','control-mapping.json')
for name in ['runtime-results.json','installed-artifacts.json','downloaded-artifacts.json','installed-tree.json','fixture-http-requests.json','capture-cleanup.json','binaries.json']:
 copy(BASE/'frozen-provider-controls'/name,'runtime/'+name)
for name in ['final-focused-checks.json','post-guard-checks.json','post-pathlist-checks.json','nonutf8-contract.normalized.json','nonutf8-relative-controls.normalized.json','nonutf8-investigation.json','nonutf8-guard-native.json','colon-context.json','standalone-native-build-final.json','older-runtime-retention.json']:
 copy(BASE/name,name)
copy(BASE/'protected-native/manifest.json','protected-binaries.json')
for name in ['validation.json','harness.json','owned-cleanup.json','native-binaries.json','native-bootstrap.json','scheduled-standalone.json','child-nextest-all.json']:
 copy(PROOF/name,'standalone/'+name)
for name in ['source-before.json','source-after.json']:
 path=OUT/'standalone'/f'{name}.gz';path.write_bytes(gzip.compress((PROOF/name).read_bytes(),mtime=0))
production=Path(read(PROOF/'scheduled-standalone.json')['environment']['UMPIRE_STANDALONE_OUTPUT']);children=list(production.glob('proof-*'));assert len(children)==1;child=children[0]
for name in ['result.json','stages.jsonl','inputs.json','setup.jsonl','tools.json']:
 if (child/name).is_file():copy(child/name,'standalone/child-'+name)
observed=0;peak_java=0;peak_rss=0
for line in (PROOF/'owned-process-samples.jsonl').read_text().splitlines():
 row=json.loads(line)
 if row['kind']=='new-owned-process':observed+=1
 if row['kind']=='jvm-sample':
  peak_java=max(peak_java,len(row['jvms']));peak_rss=max(peak_rss,sum(p.get('rss_kib',0) for p in row['jvms']))
write('standalone/resource-observations.json',{'sample_interval_seconds':0.5,'observed_owned_processes':observed,'sampled_peak_java_processes':peak_java,'sampled_peak_combined_java_rss_kib':peak_rss,'owned_cleanup':validation['cleanup'],'limitation':'Sampled RSS is observation, not a kernel heap cap. The reviewed task17 shared lease, JVM group and property-worker policy remains authoritative.'})
# Preserve complete raw logs, command receipts, source seals, fixtures and producer observations without assets or executables.
raw={}
def add(path,name):
 if path.is_file() and not path.is_symlink():raw.setdefault(name,path)
for path in BASE.iterdir():
 if path.is_file() and path.suffix in ['.log','.json','.jsonl','.stdout','.stderr','.py','.rs']:add(path,'root/'+path.name)
for directory,label in [(BASE/'frozen-provider-controls','frozen-runtime'),(BASE/'final-provider-controls','pre-freeze-runtime'),(PROOF,'standalone-current'),(BASE/'standalone-d4a79702','standalone-boundary-red'),(BASE/'standalone-60f1c762','standalone-sampler-red')]:
 for path in directory.iterdir():
  if path.is_file() and path.suffix in ['.log','.json','.jsonl','.stdout','.stderr','.py','.rs']:add(path,label+'/'+path.name)
for directory in [BASE/'standalone-d4a79702',BASE/'standalone-60f1c762',PROOF]:
 for path in (directory/'harness-source').glob('*.py'):add(path,directory.name+'/harness-source/'+path.name)
for path in (BASE/'standalone-retry-harness').iterdir():
 if path.is_file() and path.suffix in ['.py','.json','.log']:add(path,'retry-harness/'+path.name)
for path in (BASE/'failed-proof-60f-preserved/target/gate-receipts').rglob('*'):
 if path.is_file():add(path,'failed-child-receipts/'+str(path.relative_to(BASE/'failed-proof-60f-preserved/target/gate-receipts')))
for top,label in [(BASE/'runtime','preparation-fixtures'),(BASE/'frozen-provider-controls/runtime','frozen-fixtures')]:
 for path in top.glob('*/mise-tools/*'):
  if path.suffix in ['.toml','.lock']:add(path,label+'/'+str(path.relative_to(top)))
for path in (child/'target/gate-receipts').rglob('*'):
 if path.is_file():add(path,'child-receipts/'+str(path.relative_to(child/'target/gate-receipts')))
manifest=[{'path':name,'bytes':path.stat().st_size,'sha256':sha(path)} for name,path in sorted(raw.items())]
write('raw-output-manifest.json',manifest)
archive=OUT/'raw-output.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,path in sorted(raw.items()):tar.add(path,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 entries=tar.getmembers();assert len(entries)==len(manifest)
 for member,row in zip(entries,manifest):assert member.name==row['path'] and hashlib.sha256(tar.extractfile(member).read()).hexdigest()==row['sha256']
write('summary.json',{'task':'fn-254-fast-validation-gates-and-a-real-inner.16','status':'scoped-validation-accepted-awaiting-formal-review','source_head':HEAD,'review_baseline':'f0a82c7a969ec6fd1717a73f98536d3b9c6fe8ee','standalone':{'accepted':True,'seconds':read(PROOF/'scheduled-standalone.json')['seconds'],'nextest_inventory_count':validation['nextest_inventory_count'],'nextest_ignored':validation['nextest_ignored'],'child_counts':validation['child_counts'],'doctests':validation['doctests'],'stages':len(validation['parent_receipt']['child_count_receipts'][0]['stages']),'source_unchanged':True,'parent_own_counts_not_double_charged':validation['parent_own_counts_not_double_charged'],'owned_cleanup':validation['cleanup']},'focused_checks':{'framework_process_xtask_tlc_apalache':'267/267 passed on locked production inputs; exact changed-root controls renewed later','system_locked_gate_and_required_apalache_callers':'16/16 passed','final_root_guards_and_scoped_context':'5/5 passed after separate genuine red runs','clippy':'framework and system scoped all-targets/all-features passed; changed provider/CLI renewed; current full standalone clippy passed','fmt':'both workspaces passed','source_boundary':'complete actual boundary passed after preserving the first failed standalone proof'},'runtime_releases':{'older_validated_head':old['head'],'clean_tlc_install_and_native_model_execution':True,'clean_apalache_install_and_native_bounded_execution':True,'separate_archive_and_jar_hashes':'runtime/downloaded-artifacts.json and runtime/installed-artifacts.json','reuse':'input-reuse.json','default_excludes_apalache':True,'required_opt_in':True},'contract_changes':['Mise owns complete archive extraction, installation locking and best-effort download/extraction leftovers. Native capture cleanup and runtime file/hash admission remain.','Pinned upstream requires UTF8 canonical roots and representable path-list entries; unsupported roots now receive native InvalidInput/status1 before mise/data/capture effects. Other native raw-OS-path and receipt contracts remain.'],'raw_archive':{'path':'raw-output.tar.gz','bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(manifest),'verified':True,'contains_release_assets_or_executables':False},'remaining':['Conductor-owned formal review, Flow closure and integration. No final task8 combined gates/timing claim.'],'platform':'Linux runtime evidence; no Darwin runtime acceptance inferred'})
print(json.dumps({'output':str(OUT),'summary':read(OUT/'summary.json')['standalone'],'archive_bytes':archive.stat().st_size,'raw_members':len(manifest)},indent=2))
