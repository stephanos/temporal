#!/usr/bin/env python3
import argparse, contextlib, hashlib, http.server, io, json, os, pathlib, shutil, subprocess, tarfile, threading, time
BASE=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path('/Users/stephan/Workspace/skunkworks/umpire/temporal/.worktrees/fn25416-provider-adapt/model/umpire')
XTASK=BASE/'target/debug/xtask'
PROBE=BASE/'provider-probe'
RUNTIME=BASE/'runtime'
RUNTIME.mkdir(exist_ok=True)
RECORDS=[]
JARS={'tlc':('http-tlc/1.7.4/tla2tools.jar','936a262061c914694dfd669a543be24573c45d5aa0ff20a8b96b23d01e050e88'),'apalache':('http-apalache/0.62.4/lib/apalache.jar','e5223915507b65cc5f1638bd037ede60f8a4fc1644aff46355779f9b05df9262')}

def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()

def guard():
 free=shutil.disk_usage(BASE).free
 if free < 30*1024**3:raise RuntimeError(f'disk floor reached: {free}')
 return free

def root(name):
 p=RUNTIME/name
 if p.exists():raise RuntimeError(f'fixture already exists: {p}')
 p.mkdir()
 for f in ['Cargo.toml','mise.toml','rust-toolchain.toml']:
  shutil.copy2(SOURCE/f,p/f)
 (p/'dev/xtask/src/gate').mkdir(parents=True)
 shutil.copy2(SOURCE/'dev/xtask/src/gate/tasks.toml',p/'dev/xtask/src/gate/tasks.toml')
 shutil.copytree(SOURCE/'mise-tools',p/'mise-tools')
 return p

def environment(p,extra=None):
 e=os.environ.copy()
 for key in list(e):
  if key.startswith(('UMPIRE_','NEXTEST_','MISE_')) or key=='BASH_ENV':e.pop(key)
 e.update(CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR=str(BASE/'target'),MISE_AUTO_INSTALL='false',MISE_EXEC_AUTO_INSTALL='false',MISE_NOT_FOUND_AUTO_INSTALL='false',MISE_TRUSTED_CONFIG_PATHS=str(p),UMPIRE_CACHE_DISABLE='1',UMPIRE_QUICK_CACHE='0')
 if extra:e.update(extra)
 return e

def save():
 (BASE/'runtime-results.json').write_text(json.dumps(RECORDS,indent=2)+'\n')

def run(label,args,p,success=True,contains=None,extra=None,timeout=240):
 free=guard();env=environment(p,extra);start=time.monotonic()
 with (BASE/(label+'.stdout')).open('wb') as out,(BASE/(label+'.stderr')).open('wb') as err:
  result=subprocess.run(list(map(str,args)),cwd=p,env=env,stdout=out,stderr=err,timeout=timeout)
 stdout=(BASE/(label+'.stdout')).read_text(errors='replace');stderr=(BASE/(label+'.stderr')).read_text(errors='replace')
 row={'label':label,'command':list(map(str,args)),'cwd':str(p),'exit':result.returncode,'seconds':time.monotonic()-start,'free_before_bytes':free,'free_after_bytes':guard(),'stdout_sha256':digest(BASE/(label+'.stdout')),'stderr_sha256':digest(BASE/(label+'.stderr')),'environment':{k:v for k,v in env.items() if k.startswith(('UMPIRE_','MISE_','CARGO_'))}}
 RECORDS.append(row);save();print(label,result.returncode,f'{row["seconds"]:.3f}s',flush=True)
 assert (result.returncode==0)==success,(label,stdout[-2000:],stderr[-2000:])
 if contains:assert contains in stdout+stderr,(label,contains,stdout[-2000:],stderr[-2000:])
 return stdout,stderr

def jar(p,tool):return p/'build/mise-jars/data/installs'/JARS[tool][0]
def admit(label,p,tool,success=True,contains=None):return run(label,[PROBE,'admit',p,tool],p,success,contains)
def install(label,p,tool,success=True,contains=None):return run(label,[XTASK,'fetch-'+tool,p],p,success,contains)
def inspected(p,tool):
 path=jar(p,tool);assert path.is_file() and not path.is_symlink() and path.resolve()==path
 assert digest(path)==JARS[tool][1]
 for parent in path.parents:
  if parent==p:break
  assert not parent.is_symlink()
 return {'path':str(path),'bytes':path.stat().st_size,'sha256':digest(path)}

def installed_metadata(p):
 tree=[]
 for name in ['http-tlc/1.7.4','http-apalache/0.62.4']:
  install_root=p/'build/mise-jars/data/installs'/name
  for path in [install_root,*install_root.rglob('*')]:
   assert path.resolve().is_relative_to(install_root) and not path.is_symlink(),path
   tree.append({'path':str(path.relative_to(p)),'kind':'directory' if path.is_dir() else 'regular','bytes':path.stat().st_size})
 aliases=[{'path':str(path.relative_to(p)),'target':os.readlink(path)} for path in (p/'build/mise-jars/data/installs').glob('*/*') if path.is_symlink()]
 (BASE/'installed-tree.json').write_text(json.dumps({'exact_versions':tree,'unadmitted_mise_aliases':aliases},indent=2)+'\n')
 archives=[]
 for path in (p/'build/mise-jars/cache').rglob('*'):
  if path.is_file() and path.stat().st_size>1000000:
   archives.append({'path':str(path),'bytes':path.stat().st_size,'sha256':digest(path)})
 (BASE/'downloaded-artifacts.json').write_text(json.dumps(archives,indent=2)+'\n')

def positive():
 p=root('clean')
 for tool in JARS:admit('missing-'+tool,p,tool,False,'missing pinned jar')
 assert not (p/'build/mise-jars/data').exists()
 install('clean-tlc-install',p,'tlc')
 assert not (p/'build/mise-jars/data/installs/http-apalache').exists()
 run('default-tools',[PROBE,'context',p,'tlc','ls','--json'],p,contains='http:tlc')
 assert 'apalache' not in (BASE/'default-tools.stdout').read_text()
 run('default-install',[PROBE,'context',p,'tlc','install'],p)
 assert not (p/'build/mise-jars/data/installs/http-apalache').exists()
 run('clean-tlc-execute',[PROBE,'execute',p,'tlc'],p,contains='TLC states=3')
 install('clean-apalache-install',p,'apalache')
 run('opt-in-tools',[PROBE,'context',p,'apalache','ls','--json'],p,contains='http:apalache')
 run('clean-apalache-execute',[PROBE,'execute',p,'apalache'],p,contains='Apalache admitted')
 (BASE/'installed-artifacts.json').write_text(json.dumps({tool:inspected(p,tool) for tool in JARS},indent=2)+'\n')
 installed_metadata(p)
 print('positive phase complete',flush=True)

if __name__=='__main__':
 args=argparse.ArgumentParser();args.add_argument('--phase',choices=['positive','inspect'],required=True);options=args.parse_args();positive() if options.phase=="positive" else installed_metadata(RUNTIME/"clean")
