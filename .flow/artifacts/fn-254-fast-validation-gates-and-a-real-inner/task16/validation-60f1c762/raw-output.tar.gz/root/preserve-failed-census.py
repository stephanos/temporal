from pathlib import Path
import shutil,json,hashlib
BASE=Path(__file__).resolve().parent
attempt=BASE/'standalone-60f1c762-census';receipt=json.loads((attempt/'scheduled-standalone.json').read_text());children=list(Path(receipt['environment']['UMPIRE_STANDALONE_OUTPUT']).glob('proof-*'));assert len(children)==1;child=children[0];target=child/'target';out=BASE/'failed-proof-census-preserved';out.mkdir(exist_ok=False);rows=[]
def copy(source,relative):
 dest=out/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest);digest=hashlib.sha256(source.read_bytes()).hexdigest();assert hashlib.sha256(dest.read_bytes()).hexdigest()==digest;rows.append({'source':str(source),'preserved':str(dest),'bytes':source.stat().st_size,'sha256':digest})
for directory in ['gate-receipts','guest/panic-control-reports','guest/current-contract-reports']:
 root=target/directory
 if root.is_dir():
  for source in root.rglob('*'):
   if source.is_file() and not source.is_symlink():copy(source,Path('target')/source.relative_to(target))
for name in ['debug/xtask','debug/umpire-guest-driver','debug/umpire-process-fixture','xtask-bootstrap/debug/xtask','xtask-bootstrap/debug/umpire-guest-driver','panic-native','current-contract-native','guest/panic-control-reports','guest/current-contract-reports']:
 source=target/name
 if source.is_file():copy(source,Path('target')/name)
for source in (target/'wasm32-wasip1/guest').glob('*.wasm'):copy(source,Path('target')/source.relative_to(target))
for source in child.iterdir():
 if source.is_file() and source.suffix in ['.json','.jsonl','.log']:copy(source,Path('child')/source.name)
for source in target.iterdir():
 if source.is_file() and source.suffix in ['.json','.jsonl','.log','.stdout','.stderr','.event']:copy(source,Path('target-root')/source.name)
for source in (BASE/'standalone-retry-harness').iterdir():
 if source.is_file() and source.suffix in ['.py','.json','.log']:copy(source,Path('harness-source')/source.name)
for name in ['proof.py','census.py','observer.py']:
 recorded=json.loads((BASE/'standalone-retry-harness/manifest.json').read_text())['files'][name];assert hashlib.sha256((out/'harness-source'/name).read_bytes()).hexdigest()==recorded
(out/'manifest.json').write_text(json.dumps({'source_head':'60f1c762a618d32478b58ae4e79c151f4355aeb3','target':str(target),'reason':'Legitimate free-space guard; no source or sampler failure','all_copies_hash_verified':True,'files':rows},indent=2)+'\n');print(json.dumps({'target':str(target),'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'output':str(out)},indent=2))
