#!/usr/bin/env python3
import importlib.util, pathlib, json, os, time, subprocess, shutil, threading, http.server, io, tarfile, hashlib
BASE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('runtime',BASE/'provider-runtime.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.RECORDS=json.loads((BASE/'runtime-results.json').read_text())
run,root,install,admit,jar=m.run,m.root,m.install,m.admit,m.jar
clean=m.RUNTIME/'clean'

for tool in m.JARS:
 path=jar(clean,tool);original=path.open('rb').read(1)
 try:
  with path.open('r+b') as f:f.write(bytes([original[0]^255]))
  install('corrupt-installed-'+tool,clean,tool,False,'integrity mismatch')
  admit('corrupt-runtime-'+tool,clean,tool,False,'integrity mismatch')
 finally:
  with path.open('r+b') as f:f.write(original)
 assert m.digest(path)==m.JARS[tool][1]
 backup=path.with_name(path.name+'.control-save');path.rename(backup)
 try:
  admit('partial-runtime-'+tool,clean,tool,False,'missing pinned jar')
  path.mkdir()
  try:admit('nonregular-runtime-'+tool,clean,tool,False,'regular file')
  finally:path.rmdir()
  path.symlink_to(backup)
  try:admit('symlink-runtime-'+tool,clean,tool,False,'symlink')
  finally:path.unlink()
 finally:backup.rename(path)
 install_root=path.parents[0] if tool=='tlc' else path.parents[1]
 saved=install_root.with_name(install_root.name+'.control-save');install_root.rename(saved);install_root.symlink_to(saved)
 try:admit('symlink-version-'+tool,clean,tool,False,'symlink')
 finally:install_root.unlink();saved.rename(install_root)

hostile=BASE/'hostile-selector.toml';hostile.write_text('[tools]\njava="definitely-not-installed"\n')
run('inherited-selector-isolation',[m.PROBE,'resolve',clean,'tlc'],clean,extra={'MISE_CONFIG_FILE':str(hostile),'MISE_ENV':'hostile','MISE_DATA_DIR':str(BASE/'outside-inherited-data')})
assert not (BASE/'outside-inherited-data').exists()
for component in ['build','build/mise-jars','build/mise-jars/data','build/mise-jars/cache','build/mise-jars/state','build/mise-jars/config']:
 p=root('symlink-'+component.replace('/','-'));outside=p/'outside';outside.mkdir();link=p/component;link.parent.mkdir(parents=True,exist_ok=True);link.symlink_to(outside)
 install('refuse-'+component.replace('/','-'),p,'tlc',False,'symlink')
 assert not list(outside.iterdir())
for config_name in ['mise.toml','mise.lock','mise.apalache.lock']:
 p=root('symlink-config-'+config_name.replace('.','-'));original=p/'mise-tools'/config_name;saved=p/'outside-config';original.rename(saved);original.symlink_to(saved)
 install('refuse-config-'+config_name.replace('.','-'),p,'tlc',False,'symlink')
 assert not (p/'build').exists()

p=root('concurrent');m.guard();started=time.monotonic();children=[]
for index in range(2):
 out=(BASE/f'concurrent-{index}.stdout').open('wb');err=(BASE/f'concurrent-{index}.stderr').open('wb')
 child=subprocess.Popen([str(m.XTASK),'fetch-tlc',str(p)],cwd=p,env=m.environment(p),stdout=out,stderr=err);children.append((child,out,err))
statuses=[]
for child,out,err in children:
 statuses.append(child.wait(timeout=90));out.close();err.close()
assert statuses==[0,0],statuses
assert (BASE/'concurrent-0.stdout').read_bytes()==(BASE/'concurrent-1.stdout').read_bytes()
m.inspected(p,'tlc');assert not list((p/'build/mise-jars/runs').iterdir())
m.RECORDS.append({'label':'actual-concurrent-tlc-install','statuses':statuses,'seconds':time.monotonic()-started,'result':m.inspected(p,'tlc'),'capture_cleanup':True});m.save();print('actual-concurrent-tlc-install',statuses,flush=True)

PAYLOADS={};SLOW=set();REQUESTS=[];RELEASE=threading.Event()
class Handler(http.server.BaseHTTPRequestHandler):
 def do_GET(self):
  REQUESTS.append({'path':self.path,'time':time.time()});body=PAYLOADS[self.path]
  self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers()
  try:
   if self.path in SLOW:
    self.wfile.write(body[:1024]);self.wfile.flush();RELEASE.wait(timeout=30);self.wfile.write(body[1024:])
   else:self.wfile.write(body)
  except (BrokenPipeError,ConnectionResetError):pass
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
def configured(name,tool,payload,checksum=None):
 p=root(name);route='/'+name+('.jar' if tool=='tlc' else '.tgz');PAYLOADS[route]=payload
 config=p/'mise-tools'/('mise.toml' if tool=='tlc' else 'mise.apalache.toml');text=config.read_text();lines=[]
 for line in text.splitlines():
  if line.startswith('url ='):line=f'url = "http://127.0.0.1:{server.server_port}{route}"'
  if line.startswith('checksum ='):line=f'checksum = "sha256:{checksum or hashlib.sha256(payload).hexdigest()}"'
  lines.append(line)
 config.write_text('\n'.join(lines)+'\n')
 lock=p/'mise-tools'/('mise.lock' if tool=='tlc' else 'mise.apalache.lock')
 text=lock.read_text();lines=[]
 for line in text.splitlines():
  if line.startswith('url ='):line=f'url = "http://127.0.0.1:{server.server_port}{route}"'
  if line.startswith('checksum ='):line=f'checksum = "sha256:{checksum or hashlib.sha256(payload).hexdigest()}"'
  lines.append(line)
 lock.write_text('\n'.join(lines)+'\n');return p,route
try:
 for tool in ['tlc','apalache']:
  p,_=configured('bad-checksum-'+tool,tool,b'this is not a release or a valid archive','0'*64)
  install('bad-download-checksum-'+tool,p,tool,False)
  text=(BASE/('bad-download-checksum-'+tool+'.stderr')).read_text();assert 'checksum' in text.lower() or 'sha256' in text.lower(),text
  admit('bad-checksum-runtime-'+tool,p,tool,False,'missing pinned jar')

 def archive(kind):
  out=io.BytesIO()
  with tarfile.open(fileobj=out,mode='w:gz') as tar:
   if kind=='traversal':
    info=tarfile.TarInfo('package/../../outside-marker');data=b'must-not-escape';info.size=len(data);tar.addfile(info,io.BytesIO(data))
   else:
    info=tarfile.TarInfo('package/lib/apalache.jar');info.type=tarfile.SYMTYPE;info.linkname='../../../../outside-marker';tar.addfile(info)
  return out.getvalue()
 for kind in ['traversal','symlink']:
  p,_=configured('hostile-archive-'+kind,'apalache',archive(kind));install('hostile-archive-'+kind,p,'apalache',False)
  assert not list(p.rglob('outside-marker'))
  assert not (BASE/'outside-marker').exists() and not (m.RUNTIME/'outside-marker').exists()
  admit('hostile-runtime-'+kind,p,'apalache',False)

 payload=jar(clean,'tlc').read_bytes();p,route=configured('interrupted-http','tlc',payload);SLOW.add(route)
 run('interrupted-download-cancelled',[m.PROBE,'cancel-install',p,'tlc'],p,False,'cancelled',timeout=45)
 assert any(item['path']==route for item in REQUESTS),'request never started before cancellation'
 assert not list((p/'build/mise-jars/runs').iterdir()),'owned capture leaked on cancellation'
 leftovers=[str(x.relative_to(p)) for x in (p/'build/mise-jars').rglob('*') if x.is_file()]
 m.RECORDS.append({'label':'interruption-leftovers','paths':leftovers,'request_started':True,'capture_cleanup':True});m.save()
 SLOW.remove(route);RELEASE.set()
 install('interrupted-download-retry',p,'tlc')
 admit('interrupted-download-recovered-admission',p,'tlc')
 m.inspected(p,'tlc')
finally:
 RELEASE.set();server.shutdown();server.server_close();thread.join(timeout=5)
 (BASE/'fixture-http-requests.json').write_text(json.dumps(REQUESTS,indent=2)+'\n')
print('negative phase complete',flush=True)
