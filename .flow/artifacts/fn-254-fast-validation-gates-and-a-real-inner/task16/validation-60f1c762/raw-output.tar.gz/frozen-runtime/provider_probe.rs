use std::{path::Path, sync::atomic::AtomicBool};
use umpire_backend_process::{tool_provider::{self, JarTool}, JvmLease, Limits, Scratch, DescendantPolicy, run_process_cancelled_with_policy};
fn run() -> Result<(), Box<dyn std::error::Error>> {
 let args: Vec<_> = std::env::args().collect();
 let root = Path::new(args.get(2).ok_or("root required")?);
 let tool = match args.get(3).map(String::as_str) { Some("tlc") => JarTool::Tlc, Some("apalache") => JarTool::Apalache, _ => return Err("tool required".into()) };
 let _lease = JvmLease::inherited_or_acquire()?;
 match args.get(1).map(String::as_str) {
  Some("cancel-install") => {
   let cancelled=AtomicBool::new(false);
   let result=std::thread::scope(|scope| {
    let flag=&cancelled;
    scope.spawn(move || { std::thread::sleep(std::time::Duration::from_secs(2)); flag.store(true,std::sync::atomic::Ordering::Relaxed); });
    tool_provider::install_cancelled(root,tool,Limits {timeout:std::time::Duration::from_secs(20),..Limits::default()},&cancelled)
   });
   println!("{}",result?.display());
  }
  Some("resolve") => println!("{}",tool_provider::resolve(root,tool)?.display()),
  Some("context") => {
   let mut command=tool_provider::command(root,tool)?; command.args(&args[4..]);
   let scratch=Scratch::new_in(root,"build/provider-control")?;
   let result=run_process_cancelled_with_policy(&mut command,scratch.path(),"context",Limits::default(),None,&AtomicBool::new(false),DescendantPolicy::Orchestration)
    .map_err(|failure| umpire_backend_process::Refusal(format!("{}; {}",failure.refusal,failure.output)));
   let (status,output)=scratch.finish(result)?;
   print!("{output}"); if !status.success() { return Err(format!("context status {status}").into()); }
  }
  Some("admit") | Some("execute") => match tool {
   JarTool::Tlc => {
    let mut checker=umpire_tlc::Tlc::discover(root)?; checker.property_workers=1;
    println!("TLC admitted");
    if args[1]=="execute" {
     let schema=umpire_tlc::Schema { fields: std::collections::BTreeMap::from([("x".into(),umpire_tla::Type::Int{min:0,max:2})]), observers: std::collections::BTreeMap::new() };
     let result=checker.check("ProviderControl","---- MODULE ProviderControl ----\nEXTENDS Integers\nVARIABLE x\nInit == x = 0\nNext == IF x < 2 THEN x' = x + 1 ELSE UNCHANGED x\nSafe == x <= 2\n====\n","INIT Init\nNEXT Next\nINVARIANT Safe\n",&schema)?;
     println!("TLC states={} result={:?}\n{}",result.states.len(),result.properties,result.output);
     if result.states.len()!=3 || result.properties.values().any(|p| p.verdict != umpire_tlc::Verdict::Verified) { return Err("TLC result mismatch".into()); }
    }
   }
   JarTool::Apalache => {
    let checker=umpire_apalache::Apalache::discover(root)?;
    println!("Apalache admitted");
    if args[1]=="execute" {
     let module=umpire_tla::Tla::safety(&umpire_tla::Lift::parse("kettle.rs",include_str!("/Users/stephan/Workspace/skunkworks/umpire/temporal/.worktrees/fn25416-provider-adapt/model/umpire/dev/fixtures/fixtures/sample_kettle/model.rs"))?)?;
     let property=module.metadata.invariants.first().ok_or("no invariant")?;
     let result=checker.check(&module,&property.operator,1)?;
     println!("Apalache {result:?}\n{}",result.output());
     if result.violated()? { return Err("Apalache safety violation".into()); }
    }
   }
  },
  _ => return Err("unknown mode".into())
 }
 Ok(())
}
fn main() { if let Err(e)=run() { eprintln!("provider-probe: {e}"); std::process::exit(1); } }
