# fn-237.3 exact failure-payload proof seam

The native `StepClaim` API can distinguish the exact boolean payload. The admitted source postcondition syntax cannot. There is, however, an existing source/native/TLC route: a **one-transition progress claim scoped to exactly one concrete failure action**, separately for true and false. This proves the relevant next-action result from every reachable pending state without adding state, facts, action variants or framework support. It is a local transition-policy claim, separate from the unrestricted fair-worker eventual closure claim.

All anchors below refer to stable commit `94e47d7878`, read with `git show`/`git grep`. No tests, builds, probes, Flow operations, source writes or new agents ran. The only output is this memo. Existing test functions are inspected evidence of implemented checks; this memo does not assert they were executed in this session.

## Native edge API and the source boundary

`model/umpire/author/dsl/src/claim.rs:146` defines the native callback as:

```rust
fn(&World, &Model, &Model, &Action, &Outcome, &[Fact]) -> Verdict
```

The state arguments are before then after. `StepClaim::after(name, action, predicate)` at line 186 and `after_checks` at line 196 accept the complete generated action value. Therefore a native caller can use:

```rust
StepClaim::<World>::after(
    "pending_retryable_failure_cancels",
    Worker::RespondFailed { retryable: true }.into(),
    |_, before, after, _, _, _| {
        (!before.cancel_requested || after.phase == Phase::Canceled).into()
    },
)
```

Use the accepted pending invariant or strengthen the premise to cooperative Started. `applies_to` at line 206 compares full action equality, and `evaluate` at lines 229–238 passes the actual action, outcome and facts. Native exploration invokes the registered checks on emitted edges at `model/umpire/backends/native/src/explore.rs:442`. This native API alone does not make a callback independently liftable.

The source limitation is explicit:

* `model/umpire/front/src/declare/mod.rs:795` parses `after = ...` as `syn::Path`, not a constructor expression. Lines 282–292 reject a path naming an input-bearing variant with “carries inputs; it is not one catalog action.” Neither `#[postcondition(after = Worker::RespondFailed { retryable: true })]` nor the bare input-bearing variant is admitted.
* `model/umpire/ir/src/tree.rs:136` stores the postcondition filter as `Option<String>`, a variant name, rather than a concrete `ActionRef` with values.
* `declare/mod.rs:936` permits `&self`, optional before, optional outcome, and the separate trailing World. `model/umpire/front/src/body/claim.rs:13` binds before at lines 16–29 and outcome at lines 31–54. `body/mod.rs:198` binds only the optional World. No action or payload variable enters this source claim environment.
* `model/umpire/author/dsl/macros/src/machine.rs:188` generates postcondition callbacks that discard action and facts (`_` arguments at lines 205–207). It dispatches `after_checks` only for the admitted path filter at lines 210–215.

Consequently do not invent an action parameter, `retryable` local, payload attribute, or a source law callback to access that value. A generic payload-filtered postcondition would require separately planned admission/IR/macro/backend support if it were itself an acceptance requirement.

## Existing independently lifted alternative

These two methods use already admitted syntax. They assume the future Model field names in the accepted task shape; add the existing DSL `only` import alongside `path`.

```rust
#[progress]
fn pending_retryable_failure_cancels(&self, world: &World) -> LeadsTo {
    path![
        world.asynchronous_cancel
            && self.phase == Phase::Started
            && self.cancel_requested,
        ..=1,
        self.phase == Phase::Canceled
    ]
    .assuming(only([Worker::RespondFailed { retryable: true }]))
}

#[progress]
fn pending_nonretryable_failure_fails(&self, world: &World) -> LeadsTo {
    path![
        world.asynchronous_cancel
            && self.phase == Phase::Started
            && self.cancel_requested,
        ..=1,
        self.phase == Phase::Failed
    ]
    .assuming(only([Worker::RespondFailed { retryable: false }]))
}
```

The trigger and target are disjoint. Every maximal continuation restricted to that exact action must reach the target in at most one emitted transition. A missing action deadlocks before the target and refutes; a rejected self-loop cycles and refutes; a wrong terminal phase deadlocks after the wrong edge and refutes. If the action has multiple outcomes, every admitted outcome must satisfy the requirement. No fairness assumption is needed.

Source inspection confirms that the scope does **not** restrict initial reachability. Native `backends/native/src/explore.rs:137` seeds the actual starts; its BFS enumerates every admitted catalog action at lines 147–150 without consulting a progress scope. Only after that exploration does it evaluate the progress claims (lines 215–218). `progress.rs:141` seeds obligations from every reached state satisfying trigger and not target. A cut exploration becomes Unknown (`progress.rs:304`), not a completed proof. TLC likewise emits `PrefixEdge_name == (__umpire_pending = 0) /\\ Edge` (`backends/tla/src/emit.rs:343`), while the exact scoped relation applies only to `ActiveEdge_name` after activation. Thus Poll, ordinary retries and Cancel remain available in the prefix, including the path to a pending cap state. This is verified by reading source, not by executing the proposed Model3 claims.

That machinery prevents a scope-induced vacuity, but it cannot manufacture a pending state the Model never reaches. Model3 should separately assert a concrete reachable witness for each pending attempt and applicable World, before either exact failure is delivered. Then assert `checked_step` for each boolean returns the expected nonempty Accepted edge with exact destination, attempt, cleared fields and empty ordinary facts. This independent availability/edge matrix distinguishes a missing operation, wrong phase, wrong outcome and wrong ancillary state. In the scoped progress check itself, disabling the exact failure action in an already reachable pending state refutes by deadlock; no additional availability law is needed to make that particular mutation fail. By contrast, a phase-only target does not inspect outcome or facts, and removing all paths to pending could make both claims vacuous. Those are why explicit reachability and exact edge controls remain required. Source-only missing-edge and missing-pending-prefix controls should confirm these distinct failure routes rather than being conflated with the true/false destination-swap control.

The unrestricted prefix can reach pending at any attempt before the one-action obligation activates. Therefore retry-cap pending states are included; no `attempt < maximum_attempts` restriction belongs in the pending retryable claim. Require explicit reachable pending witnesses for every intended attempt/World, especially maximum 1 and the cap of maximum 3, so an unreachable premise cannot pass silently.

Register the analogous nonpending phase claims with their honest premises: Started and no pending cancellation; retryable below cap reaches Scheduled, retryable at cap reaches Failed; nonretryable reaches Failed. Preserve the existing native exact step matrix for the increment/same-attempt, outcome and cleared-budget details. For independently lifted exact attempt checks, either retain applicable before/after universal laws or split these one-step predicates by the existing finite attempt literals (trigger attempt=k, target attempt=k or k+1). A progress target cannot capture its trigger's arbitrary prior value. Do not claim that a phase-only property proves attempt preservation or Accepted outcome/facts.

The mechanism is already admitted end to end:

| Layer | Pinned source anchor and behavior |
| --- | --- |
| Source scope | `model/umpire/front/src/body/progress.rs:168` reads explicit action arrays; lines 206–225 admit `.assuming(...)` on `path!`; lines 259–285 admit the `..=1` bound and state/World predicates. Use `.assuming(only([...]))`, not an unsupported direct `.only(...)` progress builder. |
| Exact payload | `model/umpire/front/src/body/inputs.rs:186` admits named constructors, including struct fields at lines 197–207; lines 228–247 type-check their literal values and build `ActionRef { name, values }`. |
| Native semantics | `model/umpire/backends/native/src/progress.rs:126` filters catalog actions with exact `assumption.allows`; lines 141–145 begin obligations at every reached trigger; lines 151–160 refute a complete scoped deadlock before target. |
| TLC exact relation | `model/umpire/backends/tla/src/emit.rs:604` restricts a partially selected action variant to the exact admitted input positions via `*_At(index)`. It does not select the variant's whole existential union. |
| TLC prefix and one step | `emit.rs:312` activates at a trigger reached through unrestricted `PrefixEdge` (line 343); `ActiveEdge` at line 341 uses only the selected relation. Lines 373–377 require eventual target on maximal paths and at most one monitored transition. Bounded claims get no weak-fairness benefit (line 357). |

Restricting the continuation here is legitimate because the proposition is specifically “what this one concrete operation does next.” It is not a replacement for closure under arbitrary action interleavings or the total-Tick theorem.

## Existing test analogues and required mutation

`model/umpire/dev/fixtures/fixtures/action_inputs/model.rs:32` already has a named boolean payload (`Fail { retryable }`) and exact concrete Poll assumptions at lines 77–89. Its bounded progress claim is at lines 114–118. `action_inputs/tests.rs:127` runs actual TLC on selected Worlds and asserts claim verdicts and replay counts; lines 174 onward discriminate exact payload fairness from a variant union. This is existing support for typed action identity and real-TLC verdict discrimination, not an existing activity pending-failure proof.

`model/umpire/dev/fixtures/fixtures/parameterized_world/model.rs:62` demonstrates `only([User::Advance])` in an authored scope. `model/umpire/backends/tla/tests/inputs.rs:175` pins exact selected input ordinals; lines 213–233 reject assumptions naming absent concrete values. These support the proposed composition, although no inspected fixture contains this exact pending-failure pair.

For actual source-only policy controls follow `model/temporal/feature/activity/tests.rs:221`: read Model source, assert the unique mutation anchor, edit only that handler branch in a string, use `bound_for(selected_world).lift_source("model.rs", &mutant)`, and invoke `Tlc::discover(...).check_module(&module)`. Keep both property methods unchanged. Inspect `result.properties["Progress_pending_retryable_failure_cancels"].verdict` and the false counterpart. This is the same public runner API used for the existing source-only closure mutants at lines 253–264, with progress property keys as in `action_inputs/tests.rs:169`.

Required discrimination:

1. Healthy source: both properties Verified in each applicable cooperative World, with separately demonstrated reachable pending at the relevant attempts.
2. Change pending retryable failure to Failed (including a cap-only mutant): true-scoped claim Refuted. A cap-specific trigger or trace assertion must prove the cap control actually visits attempt==maximum.
3. Change pending nonretryable failure to Canceled: false-scoped claim Refuted.
4. Swap the branches while keeping both terminal states reachable elsewhere: both claims Refuted. The input scope stays unchanged; only the response transition mutates.
5. Mutate only one selected boolean in the property scope as a separate identity control. Assert metadata `allowed_inputs` selects exactly the intended catalog value and inspect the corresponding `*_At` relation. Do not identify the payload by display text or hard-coded ordinal without checking its typed catalog entry.

The wrong destination may already be in the state set. These controls still fail because the TLC progress property follows the wrong edge under the exact selected payload. Ordinary state-set equality is insufficient and is not the oracle here.

For typed counterexample inspection/replay use the existing activity example at `tests.rs:321`: it reads a property trace, skips observer-only steps using `__umpire_edge_tick`, decodes `__umpire_input`, and compares the exact native operation. A mutated-policy trace should **disagree** with healthy compiled native behavior at the mutated edge; do not expect successful replay of the incorrect destination. Retain before pending state, attempt, exact true/false payload, after phase, outcome and facts in that disagreement assertion. The healthy property run plus the source-mutant Refuted verdict is the primary independent proof; replay mismatch confirms the same-edge witness.

This supplies the required phase boundary using existing APIs. There is a real gap for direct payload-filtered source postconditions, but no new generic feature is needed for these exact one-operation native/TLC policy claims.
