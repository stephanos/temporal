# fn-237.3 execution preparation

Task .3 can extend the existing activity Model and reuse F/O without introducing another Model or framework construct. Freeze the activity interface after O lands, then divide tests, compatibility and interim realization work by file owner. One concrete prerequisite needs root resolution before implementation: the current source grammar cannot author a World-dependent list of fair Poll values, while both checkers reject out-of-catalog fairness entries. Exact-payload fairness emission itself is already delivered.

This memo consumes the accepted canonical fn-237/.3 and `.flow/artifacts/fn-237-activity-timeouts-heartbeat-and/cancellation-boundary-contract.md`; it makes no cancellation-policy change. The root reports fresh plan review SHIP after P1/P2 fixes and commits `f32e51c5cb`/`e2f25dc292`. O remains active and its proposed operation names in `.flow/tmp/fn2372-design-prep.md` are not a frozen consumer API. Sole write `.flow/tmp/fn2373-execution-prep.md`. No source, canonical Flow, Git, test, probe, build, web or agent operation ran. Brainstorming and flow-next-prose guide this implementation preparation within the dispatch's read-only constraints.

## Freeze the consumer interface first

| Existing owner | Required activity change | Freeze before another lane writes |
| --- | --- | --- |
| `feature/activity/model.rs::activity::World` | Retain `maximum_attempts`; add canonical `schedule_to_start`, `start_to_close`, `schedule_to_close`, `heartbeat_timeout` as `Option<Ticks>` and `asynchronous_cancel` | Field order/generated constructor signature, nominal declarations and the explicit checked fixture factory |
| `activity::Model` | Retain public `phase` and `attempt`; add `cancel_requested` and four optional Remaining budgets | Exact field names, initial-state builder and terminal-clearing representation; do not let lanes invent different state literals |
| `activity::Client` | Keep `Cancel` as a fresh distinct logical intent | Existing action identity remains exact; request-ID replay stays outside the outcome promise |
| `activity::Worker` | Keep `Poll(#[domain(attempts)] u8)`, `RespondCompleted`, `RespondFailed { retryable: bool }`; add Heartbeat and named current-attempt acknowledgement | Final new variant spelling and current/stale-attempt representation. Reuse existing finite input binding if acknowledgement carries an attempt. Do not invent a stale-status policy from repeated Cancel |
| `activity::Deadline` | Replace `ScheduleToStart`/`StartToClose` action variants with the single internal `Tick` | Four-value local ExpiredDeadline enum, action catalog order and exact expiry fact names |
| `Model::initial` | Compute complete correlated starts from the selected World | Initial phase Scheduled, attempt 1, pending false, Scheduled/global budgets armed and Started-only budgets absent |
| `Model::client/worker/deadline` | Consume accepted boundary rules and reset/arming laws | Unit client/worker handlers; optional-result Tick handler; unit terminal-clear helper if useful |

Use O's delivered checked constructor and optional-wrapper grammar exactly as its owner freezes them. This memo intentionally supplies no speculative wrapper access method, conversion signature or countdown helper return type. Raw generated `World::new` remains infallible; the fixture boundary checks configuration and authors invariants for native state updates. No generic Model validation hook or silent range repair belongs here.

F is implemented in `front/src/body/effects.rs`. The Tick handler may end in `None`, `Some(ExpiredDeadline::Variant)` or exhaustive tail if/else trees, with supported prefix effects and locals. Fact-returning helper calls, arbitrary early result returns and stored fact Options are outside F's admitted grammar. Keep terminal clearing in a unit effect helper and return the explicit singleton at the Tick leaf. Conditional fact selection must use the intended pre/post SSA value; capture required before-decrement/pending predicates before clearing fields. A fact alone does not enable an unchanged handler. Returning None does not suppress an actual decrement edge.

## Handler checklist under accepted policy

1. `client` checks terminal closure first, preserving the existing NotFound self-loop. Atomic nonterminal Cancel and cooperative Scheduled Cancel close immediately. Cooperative Started first Cancel sets only pending. A fresh pending Cancel rejects FailedPrecondition before any mutation; every budget, attempt and pending field stays exact.
2. `worker` preserves stale Poll FailedPrecondition and current Scheduled Poll behavior. Poll arms start-to-close/heartbeat, disarms schedule-to-start and preserves the spanning global budget. Heartbeat resets only its own optional budget and never closes pending cancellation; use accepted staying semantics when a heartbeat has no net state change. Current pending acknowledgement closes Canceled. Complete/nonretryable Fail close Completed/Failed. Pending retryable Fail closes Canceled without increment, including at the cap. Other retryable Fail increments once and rearms Scheduled budgets only below the cap, otherwise closes Failed. Terminal paths clear all budgets/pending and preserve the terminating attempt.
3. `deadline` decrements every live budget once without underflow, then selects `ScheduleToClose > StartToClose > Heartbeat > ScheduleToStart`. Selection precedes phase classification. Global expiry is TimedOut. Pending attempt expiry is Canceled. Other applicable expiry is TimedOut. Emit exactly the selected deadline fact even for Canceled. Nonexpiring edges emit none. No live budget means no Tick edge. Schedule-to-start remains Scheduled-only, attempt budgets Started-only, and pending implies cooperative Started.
4. Interleavings retain their actual order. Same-Tick deadline priority does not reorder Complete, Fail, Cancel or acknowledgement. A completion that precedes expiry wins; a terminal expiry prevents a later reopening. Do not add worker behavior to the Model to force progress.

Preserve emitted-edge availability as well as handler results. In the pre-.3 Model, a current Poll while Started and terminal worker fallthroughs execute `_ => {}` without `stay!()`, so they are disabled, not accepted self-loops. Only terminal Client Cancel supplies the four retained NotFound loops. Do not add old worker-action terminal edges through a blanket closed-state rejection guard; the exact compatibility relation would change. New Heartbeat staying behavior and any new-action projection need explicit rules, while existing universal closure laws still check every emitted edge.

## Preserve existing laws and repair their premises honestly

The current Model registers exactly `terminal_remains` and `closed_rejects`. The first calls `closable::terminal_remains(self, before)`; the second calls `closable::closed_rejects(self, before, outcome, Rejection::NotFound)`. Keep both universal over the extended state and action domains. Their native hypothetical and independently lifted TLC mutation controls remain active. Clearing budgets on entry to closure must not permit later terminal state changes.

The old retry-at-cap promise is currently executable in `tests.rs::retry_policy_caps_and_stale_delivery`, the six-phase transition matrix and `closings()`, rather than a named registered Model law. Preserve their old atomic/nonpending branch and add an explicit pending branch. A retryable failure at maximum remains Failed only when cooperative cancellation is not pending. A pending retryable failure at maximum must be Canceled with the same attempt. Keep nonretryable failure final at every attempt. Update claimed scopes and expected matrix entries together; deleting the old cap test or retaining its false unconditional prose would both be wrong.

The narrower follow-up `.flow/tmp/fn2373-tick-bound-seam.md` verifies an existing-API route for the total actual Tick bound: live global-budget positivity/bounds, universal nonincrease, Tick strict descent and global expiry, terminal permanence and no terminal Tick. State the induction consequence over all interleavings; do not substitute `within_steps`, a Tick-only scope or an artificial counter. The memo distinguishes the numerical upper bound from Tick availability: missing edges need separate enabledness/relation controls. This is unexecuted preparation, not proof credit.

The separate `.flow/tmp/fn2373-payload-law-seam.md` verifies an existing source/TLC route for the exact retryable/nonretryable pending-failure boundary. Native exact-value step claims exist, but source postcondition attributes do not accept payload-bearing variants. Use one-step progress scoped to each concrete failure value to check the required next phase independently. Native full-graph exploration and TLC's unrestricted pre-trigger prefix preserve reachability of pending states at every attempt, including the cap. Independently assert those premises and exact nonempty Accepted transitions; phase-only progress does not prove outcome/facts, and a deleted pending prefix can otherwise make it vacuous. Actual source-only mutants and required TLC/replay remain implementation obligations; this memo provides no execution credit.

Existing test owners that need adaptation include `six_phase_transition_matrix_includes_disabled_actions`, `registered_closure_laws_check_every_phase_action_pair`, `hypothetical_reopening_and_terminal_moves_refute_registered_closure_laws`, `hypothetical_accepted_and_wrong_rejection_refute_registered_closed_rejection`, `tlc_refutes_closure_law_mutants_of_this_source`, and the two actual-TLC retry/rejection replay controls. Preserve their assertions' purpose while extending state construction and source mutation anchors. Do not pin the old action count after new actions are intentionally added.

Author state bounds/arming/pending invariants and separately assert accepted boundary results. The schedule-to-close total-tick bound applies only to declared applicable Worlds/starts. Its proof must count actual Tick transitions, not all actions, and must detect a reset spanning budget or missed expiry without counter clamping, discarded invalid updates or exploration cuts. All-timeouts-absent Worlds have no Tick and still require the independent progress proof.

## Exact-action fairness seam and prerequisite

The delivered fn-227.8 seam remains concrete throughout:

- `author/dsl/src/scope.rs::Assumption` stores exact action values. `backends/native/src/progress.rs::validate_assumption` rejects fair values absent from the selected catalog and `fair_cycle` checks each selected action.
- `front/src/body/progress.rs::{assumption_body,action_list}` admits explicit action arrays. `front/src/body/inputs.rs::action_ref` resolves unit actions or constructors with literal/source-constant payloads.
- `backends/tla/src/bind.rs::scoped_catalog` enforces selected-catalog membership. `emit.rs::fair_relations` emits one specialized `Worker_Poll_At(position)` obligation per concrete fair payload, and metadata `Progress::fair_inputs` identifies exact catalog ordinals. `dev/fixtures/fixtures/action_inputs/{model,tests}.rs` supplies existing discriminating controls.

The required list for selected maximum m is `Poll(1)..Poll(m)` plus RespondCompleted, with no exclusion of Heartbeat, Fail, Cancel or Tick. A static source list containing Poll(1), Poll(2), Poll(3) is invalid in the one-attempt compatibility World. A list containing only Poll(1) omits fairness after retry in larger Worlds. Current source assumptions accept neither a conditional tail nor dynamic list enumeration, and `dev/testing::Bound` has no per-World assumption binding override. Native selector `Progress::assuming` exists, but does not by itself change independently lifted source assumptions or erase invalid authored registrations.

Root must resolve this bounded authoring/support issue before .3 implements a World-dependent fairness helper. Reanchor I's receipt and select an existing supported route if one is demonstrated; otherwise return the precise missing source operation to explicit support planning as the task requires. Do not silently widen Poll's catalog, filter absent fair values, emit one existential Worker/Poll WF, copy native graph behavior into TLA or add unplanned front-end constructs inside .3. This finding changes no accepted fairness policy.

Once the authoring route is frozen, record the actual selected finite fair list and specialized operators for every tested World. Missing RespondCompleted must expose an infinite heartbeat path. Missing current-attempt Poll must expose retry starvation with stale rejected Poll self-loops. Mutating only a specialized fair payload or replacing it with variant-union fairness must discriminate under actual native/TLC checks. Bounded safety claims receive no fairness benefit.

## Final compatibility projection

Keep `compatibility/original/**`, `manifest.json` and `verify.py` unchanged. `verify.py` checks all 15 originals against the independent fn-227 SHA256 file and source commit `af0ebafc571d33651fdf2c008d4415ad72467a0d`. Update only the active `checkpoint.rs` projection/harness and its explanatory README where necessary.

The selected World is one attempt, atomic cancellation, one-tick ScheduleToStart/StartToClose, with ScheduleToClose/Heartbeat absent. Project state to Phase; assert attempt==1, pending false and applicable budget consistency before erasure. Map Poll(1) to old Poll and deduplicate both retryable failure assignments into old RespondFailed. Map expiring Tick using its exact fact to the old ScheduleToStart/StartToClose action and erase that fact only after validating the mapping. Keep outcome and destination exact. New internal projected stutters require explicit stated rules; arbitrary visible edges cannot disappear. Heartbeat may be a projected state stutter, but its treatment must be justified rather than accidentally emitted as an old edge.

Compare exact starts, six states and eleven old edges, including all four terminal Cancel NotFound loops. Keep `retained_original_hashes_and_exact_lifecycle_projection` and `changed_original_lifecycle_edge_fails_the_same_comparison`. The changed-edge control must fail the same equality relation. Never broaden `outcome_key` to collapse FailedPrecondition into NotFound. Unexpected cooperative facts or pending states in this World must fail, not be erased permissively.

## Minimum discriminating matrix

| Positive family | Counterfactual that must fail |
| --- | --- |
| Zero rejected at fixture/binding boundary; None/one/max budgets; one-tick expiry; no-budget disabled Tick | Underflow, nonterminal armed zero, invalid native update hidden as disabled or normalized |
| Each deadline alone and simultaneous global/attempt/heartbeat expiry, both pending and ordinary | Wrong priority, wrong/missing/duplicate exact fact, Canceled fact forced to TimedOut, ordinary-edge fact leakage |
| Poll/reset, retry schedule-to-start rearming, heartbeat reset, spanning global budget | Global reset on Poll/retry/heartbeat; missing applicable reset |
| Scheduled/atomic Cancel, Started pending Cancel, exact rejected fresh repetition | Atomic cancellation becomes pending; repetition succeeds/resets budget/becomes NotFound |
| Pending Heartbeat/ack/Complete/nonretryable Fail/retryable Fail below and at cap | Heartbeat closes; acknowledgement-only cancellation; completion/nonretryable result loses; pending cap returns Failed or schedules retry |
| Current/stale Poll and acknowledgement matrix; terminal actions | Reopening, accepted terminal edge, wrong terminal rejection, stale response treated as current |
| Timeoutless one/multiple-attempt progress with exact selected fair list | Missing closing WF, missing current Poll WF, union fairness or stale-payload substitution |
| Applicable schedule-to-close tick bound | Reset spanning budget, skip expiry or clamp a counter to fake the bound |
| Final atomic projection and original hash verification | Changed original edge, lost terminal loop, new visible edge hidden by projection |

Use native compiled/interpreted checking plus independently source-lifted required TLC. Replay false claims through pending retryable failure and both Canceled attempt-expiry facts, retaining exact action payload, choice, outcome, fact list and selected World. Wrong-fact replay controls must mutate the same state/action edge. Counts and Cases(n) are measured after implementation, not inferred from the current six/eighteen-state retry checkpoint.

## Production compatibility and safe work lanes

Task .3 owns constructor compatibility only. `feature/activity/temporal.rs::runtime` currently constructs `World::new(3)`; `realization/src/live.rs` constructs `World::new(maximum_attempts)`. Both need the new arguments while preserving pre-.4 semantics: actual admitted maximum_attempts, atomic mode and timeout-absent live defaults. These live defaults differ from the final one-tick offline compatibility World. Adapt state literals such as `temporal.rs`'s `activity::Model { phase, attempt }` without reconstructing speculative pending/budget state. Preserve the current unheld atomic refusal. Heartbeat/ack program rows, actual request-derived timeout admission and the pinned cooperative live binding belong to .4.

After O and the activity actor/World/state/claim interface freeze, the task worker may use disjoint lanes:

| Lane | Exclusive write owner | Boundary |
| --- | --- | --- |
| Model owner, serial | `feature/activity/model.rs` and interface note | Handlers, law premises, starts, priority and exact named claims. Other lanes request interface changes through this owner |
| Policy verification | `feature/activity/tests.rs` and new explicitly included policy-test modules | Native/TLC matrices, mutants, progress and tick-bound evidence; no production semantics edits |
| Compatibility | `feature/activity/compatibility/checkpoint.rs` and README | Projection/equality/control only; no original files, hash manifest or verification-script edits |
| Interim realization | `feature/activity/{temporal,phase}.rs`, `realization/src/live.rs`, affected realization tests | Compile compatibility with atomic/absent defaults only; no .4 admission or scope expansion |

Freeze any shared test helper before parallel edits. The Model owner alone reconciles changed test imports/state factories. One worker commits. Serialize guest refresh, active golden regeneration, broad gates and final receipt collection after all lanes land; do not run concurrent generators against the same expected tree. `model/README.md`, guest bytes and activity `expected/**` are final integration ownership, not another parallel writer.

Future required gates remain the canonical focused activity/realization tests, actual required activity TLC, scoped fmt/strict clippy, then `make model-check`, `UMPIRE_BACKENDS=require make model-check`, `make model-time`, normal `make umpire-guest`, slice and gaps. Reanchor actual package names and predecessor receipts when .3 is admitted. Record actual counts, traces, fairness descriptors, byte-preservation checks and soft-target misses. Live exact-cause limits stay .4's declared evidence scope; an offline expiry fact is not live causality evidence.

## Separate prerequisite design for World-selected fairness

Root confirmed the authoring gap and will plan a separate prerequisite after O and before .3. It must receive fresh plan review before execution. Do not expand the active O task, change Model policy or start this support work from this memo.

Native authoring already has the needed semantics. `author/dsl/macros/src/machine.rs::assumption_claims` calls `Model::method(self)` when the method has trailing `&World`; `progress_claims` likewise passes the selected World into a progress method. Existing declaration registration records that signature. The bounded native shape can therefore be:

```rust
#[assumption]
fn fair_worker(world: &World) -> Assumption {
    if world.maximum_attempts == 1 {
        fair([Worker::Poll(1), Worker::RespondCompleted])
    } else if world.maximum_attempts == 2 {
        fair([Worker::Poll(1), Worker::Poll(2), Worker::RespondCompleted])
    } else {
        fair([Worker::Poll(1), Worker::Poll(2), Worker::Poll(3), Worker::RespondCompleted])
    }
}
```

The associated progress method takes `&World` and calls `.assuming(Self::fair_worker(world))`. This is a support-fixture sketch, not a change to the activity source. The existing native checker verifies that the returned assumption stays unchanged across reached states; source admission should prevent state dependence earlier.

The smallest source addition is exhaustive `if WorldPredicate { AssumptionLeaf } else { AssumptionTree }` around the already admitted assumption builder leaves. Require a final else and permit nested else-if. A leaf remains existing `fair`/`only`/`without` with explicit concrete action arrays, including their existing builder chains and named assumption-helper resolution. Restrict conditions to typed primitive World bool fields or primitive World scalar comparisons with typed literals/source constants, with parentheses and existing boolean connectives. The activity only needs equality against 1 and 2. Do not add loops, match, dynamic arrays, iterators, World-derived action payload constructors, state/outcome/action-input conditions, arbitrary calls or a general expression evaluator. Existing helper depth limits and signature/identity resolution continue to apply.

The front end must parse/type-check every branch independently from authored source. A reference to Poll(3) is syntactically/type valid in the three-attempt branch even when the selected World has one attempt. At selected-World binding, evaluate only the World predicate tree using actual typed bound World values, choose one leaf and then apply the unchanged selected-catalog membership/refusal checks to that leaf. The inactive leaf is never unioned, catalog-filtered or treated as an implicit family. A selected leaf naming an unavailable Poll must still refuse.

Suggested logical interfaces are an admitted conditional assumption plan with `Leaf(existing AssumptionDef)` and `If(typed World predicate, then plan, else plan)`, and a narrow binding resolver producing the existing flat AssumptionDef. Preserve named assumption identity and source location across resolution. `ProgressDef` and registered named assumptions must share this source-derived plan, so direct registration, helper calls and progress scope resolve the same branch. The representation must survive macro embedding and independent source re-admission. This is an opt-in internal IR extension; it is not a public scheduling framework. Exact Rust field placement remains a fresh-review decision. In particular, naive added fields on always-printed `Lifted`/`ProgressDef` structures can change every legacy expansion. Review the representation/printing strategy first and prove the existing flat-source path retains its required unchanged artifacts; do not assume a derived Print change is byte-neutral.

| Owner | Narrow responsibility |
| --- | --- |
| `front/src/body/progress.rs` | Admit exhaustive conditional assumption syntax, preserve existing flat parser, resolve helpers with their actual World identity |
| `front/src/body/expr.rs` and existing World environment | Reuse typed predicate parsing, then enforce the World-only restricted node set; reject state/after/before/input/outcome dependence and shadowing mistakes by location |
| `ir/src/tree.rs` and opt-in embedded Print path | Carry typed conditional assumption plans without losing branch predicates, locations or leaf action identities; keep flat behavior/required bytes unchanged |
| `author/dsl/macros/src/{machine,lifted}.rs` | Reuse current native World parameter plumbing; mechanically transport the opt-in plan and keep interpreted accessors aligned. No native callback may choose a source branch |
| `backends/tla/src/bind.rs` | Resolve from validated `binding.world` before `scoped_catalog`; current `bind_catalog` invokes that check too early for an unresolved plan, so reorder this boundary explicitly |
| `backends/tla/src/{emit,names}.rs` | Consume resolved flat leaves and retain existing exact `fair_relations`, `fair_inputs` and action naming. An unresolved plan must refuse emission, not become a union |
| `backends/native/src/interpret.rs` and testing bridge | Audit whether opt-in plan transport needs mechanical support; compiled native World selection remains independent of the source resolver. Reuse existing progress-scope stability checks |
| Existing front/TLA tests plus one generic fixture | Located refusals, binding/embedding parity, actual native/TLC branch controls, typed replay and unaffected flat artifact checks |

The resolver should be a bounded predicate operation over the admitted guard subset and the already validated World bindings. It must not run native assumption methods, query native enabled edges, use reached state sets or filter the native catalog to infer policy. Native catalog identity remains a subsequent validation input. Bound maximum 1, 2 and 3 through the same fixture type, with exact expected fair action lists of two, three and four actions respectively. Keep typed catalog ordinals and payload values in metadata; do not parse Display/Debug.

The new generic fixture should retain the existing action_inputs stale-payload shape, add an explicit closing action and an enabled heartbeat self-loop, and make selected World size determine the attempt domain. Positive controls require source/native selected-list equality, exact allowed/fair ordinals, one WF per selected concrete Poll plus close, and native/TLC agreement under all three Worlds. All ordinary actions remain allowed.

Discriminating controls must include a stale Poll loop that cannot discharge current Poll fairness, missing-close fairness that permits infinite heartbeat, omission of the last selected Poll that permits retry starvation, and a source-only branch predicate/leaf mutation while compiled native code stays fixed. Compare the selected flat assumption and WF metadata directly as well as actual verdicts; a semantic mutation may correctly change the verdict or trigger a typed selected-catalog refusal. Also swap only a fair payload, broaden exact WF to a union, alter a legal selected World binding, and choose an out-of-catalog leaf. Each must fail through the established independent comparison/refusal route. Keep bounded claims' no-fairness-benefit structural check; do not claim it is behaviorally discriminating where the existing action_inputs control explicitly says it is not.

Located refusal tests cover nonexhaustive conditionals, state-dependent predicates, unsupported calls/arithmetic, wrong-kind World comparisons, unknown fields, helper recursion and malformed leaves. Repeat selected World binding through main/invariant/postcondition/negative/progress configurations so one family cannot retain another branch. The support task ends with an independently bound concrete list and existing exact-WF proofs, leaving .3 to consume that seam without another source-language extension.
