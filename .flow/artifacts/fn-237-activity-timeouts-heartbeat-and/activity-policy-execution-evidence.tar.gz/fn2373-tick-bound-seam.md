# fn-237.3 total actual Tick bound

The existing admitted invariant/postcondition surface is sufficient to prove the total actual Tick bound by a decreasing natural-number argument over the real schedule-to-close budget. There is no direct action-weighted counting progress claim in the inspected API. Do not substitute `Steps(B)`, restrict the action scope to Tick, or introduce a history counter. Register the local laws below, check them independently in native and source/TLC, and state their induction consequence explicitly in the task receipt.

This is read-only preparation against the existing committed API (O closed at `d6306a579f`). No tests, builds, probes, source changes or Flow operations ran. The sole write is this memo. The activity Model still has its old direct deadline handlers; the names of new activity budget fields remain for the .3 owner to freeze. This finding does not depend on the concurrent .6 fairness work.

## What existing counting surfaces actually mean

* `model/umpire/author/dsl/src/progress.rs:3` defines `ProgressEvaluation.bound` as the maximum number of transitions to the first target; `Progress::within_steps` at line 87 explicitly counts transitions. It has no counted-action selector.
* `model/umpire/author/dsl/src/path.rs:629` defines only `Gap::Any` and `Gap::AtMost(u32)`. `Path::claim` at line 772 accepts two state predicates and refuses structured patterns or additional waypoints. Action patterns and finite repeat expansion (`Pattern::repeat_exact`, line 358) serve path enumeration/search; they are not a universal arbitrary-interleaving event-count theorem.
* `model/umpire/backends/tla/src/emit.rs:310` increments `__umpire_steps` on every active scoped edge, through `Monitor_*`/`ActiveEdge_*` at lines 323–329. Its internal bounded monitor saturation is not an actual-Tick metric. Excluding non-Tick actions changes the transition system, omitting retries and heartbeat resets that the requested bound must cover.
* `model/umpire/backends/tla/src/emit.rs:345` adds weak fairness only to unbounded progress. Keep closure under the separately selected exact fair Poll values plus Complete as an independent eventuality. The total-Tick safety bound requires no fairness.

## Smallest sound proof using already admitted claims

For a selected World with `schedule_to_close = Some(Ticks(B))`, let `R(s)` denote the payload of the actual schedule-to-close remaining field in a nonterminal state. It is a mathematical abbreviation, not an added Model field or a source helper that requires new admission.

Register these independently authored obligations using ordinary `#[invariant]` and `#[postcondition]` methods with `check!`:

| Obligation | Existing source form | Required assertion |
| --- | --- | --- |
| Initial/domain bound | State invariant taking `&World`, plus exact initial-state comparison | Every live state in this World has `Some(Remaining)` with `1 <= R <= B`; starts arm it to exactly B. Validate the selected positive Ticks range. |
| No replenishment | Unfiltered postcondition taking before/after/World | When both endpoints are live and the World has a global deadline, `R(after) <= R(before)`. This includes every retry, heartbeat, Poll, pending Cancel and rejected edge. |
| Actual Tick descent | `#[postcondition(after = Deadline::Tick)]` | Every emitted Tick has a nonterminal before state. In a globally bounded World, if its after state is still live, `R(before) == R(after) + 1`. |
| Global expiry | Same Tick-filtered postcondition or another named claim | If the globally bounded before state has R=1, after is TimedOut; validate the selected ScheduleToClose fact separately through the existing fact evidence surface. This is stronger than merely asserting some terminal state. |
| Terminal permanence | Retain the existing unfiltered `terminal_remains` law | No terminal state reopens. Terminal state representation clears budgets and pending as accepted policy requires. |

Also retain the exact ordinary-action preservation/reset laws required by .3. For the counting theorem itself, universal nonincrease is sufficient; asserting equality on an unfiltered postcondition would incorrectly forbid Tick descent. The global expiry phase assertion must remain unconditional on pending cancellation under the accepted priority policy.

These assertions use already admitted bool comparisons, integer comparisons/arithmetic, `Option::is_some`/`is_none`, eager `unwrap_or(Remaining { ticks: 0 })`, and payload reads. Express implications with boolean connectives; do not use Option combinators or pattern matching. The spelling of `Remaining` and its field should follow the frozen O consumer interface. A separate bound invariant is necessary: deriving `Finite` does not automatically check native updates.

The induction is over **all real emitted transitions**, assigning weight 1 exactly to Deadline::Tick and 0 to every other action. Before the first terminal state, after k actual Ticks, nonincrease on other edges and strict Tick descent give `R <= B-k`. Positivity therefore permits at most B-1 Ticks with a live after state. A Tick that first closes contributes at most one more, making the total at most B. If a worker or client action closes earlier, it contributes zero. Terminal permanence and the Tick precondition law rule out any further actual Tick, including accepted or rejected Tick self-loops. Thus every finite prefix and every infinite execution contains at most B actual Ticks, regardless of how many heartbeat, worker, Cancel or rejection actions intervene and regardless of retry count. Infinite non-Tick behavior is possible without fairness; it does not invalidate the Tick bound. The separate fair-worker progress claim rules out nonclosing fair behavior.

No auxiliary counter, bound clamp, exploration cut or per-attempt restart appears in this proof. Terminal clearing does not erase consumed Tick history from the argument: counting stops at the first terminal edge and terminal Tick edges are independently forbidden.

## Why this is an admitted native/source/TLC proof

The generic optional countdown fixture already exercises the exact constituent source operations:

* `model/umpire/dev/fixtures/fixtures/optional_ticks/model.rs:9` declares positive Ticks and zero-inclusive Remaining; lines 86–95 author explicit native/source bounds checks.
* Its `#[postcondition(after = Clock::Tick)] decrements` at line 103 compares before payload with after payload plus one and receives the selected World. `starts_selected` at line 112 combines before/after and World conditions. These are direct analogues of the needed local laws; its bounded `finishes` at line 127 is **not** an analogue of the requested weighted bound because that fixture has no arbitrarily many interfering actions.
* `model/umpire/author/dsl/src/claim.rs:146` defines the edge predicate surface. `StepClaim::new`/`after` at lines 181–188 and `applies_to` at line 206 implement universal and action-filtered checks. Native exploration evaluates those checks on emitted edges at `model/umpire/backends/native/src/explore.rs:442`.
* Source-derived TLA emission at `model/umpire/backends/tla/src/emit.rs:231` emits every postcondition as an always action property over `ModelEdge`; filtered claims additionally compare `__umpire_action'`. Source expressions preserve before and after references. These are independently emitted properties, not a theorem inferred from native edge enumeration.
* `optional_ticks/tests.rs:188` checks actual required TLC for selected None/one/max Worlds, asserts the decrement law Verified and the deliberately false nondecrement law Refuted, and asserts counterexample replay counts. Lines 151–172 mutate only the lifted countdown update and compare it with compiled native behavior.
* `model/temporal/feature/activity/model.rs:146` already registers universal terminal permanence and closed rejection laws. `model/temporal/feature/activity/tests.rs:221` supplies the activity-specific source mutation/TLC closure-law pattern to retain.

The framework reports each local claim's verdict; it does not synthesize a new named weighted-count progress verdict. The total-Tick theorem is the explicit induction consequence of those checked obligations over a complete reachable graph for each admitted selected World. If acceptance requires a single built-in weighted-count report row instead of this law bundle and derivation, that is a separate framework capability gap and must be planned explicitly. It is unnecessary to establish the mathematical bound requested here.

## Discriminating controls and proof limits

Reset schedule-to-close to B on retry, Poll or heartbeat after at least one Tick. The unfiltered nonincrease law must refute the first increasing edge while the state remains live. Use B greater than one and a reachable retry/heartbeat sequence; a reset when R already equals B is behaviorally inert and cannot discriminate. Check the same source-only reset through actual TLC and replay its edge, as well as compiled native mutation coverage.

Skip global expiry at R=1 while decrementing to Some(0): the live-positive invariant and explicit expiry law refute. Keep R=1 instead, or reset it: strict Tick descent/expiry refutes. Disarm the global budget while remaining live: the live-presence invariant refutes. Permit a Tick after terminal closure, even as a self-loop: the Tick before-state nonterminal assertion refutes. A different terminal result on global expiry fails the phase/priority law even though the weaker numerical upper bound still holds.

Disabling Tick altogether is different: postconditions only check emitted edges, so they cannot establish an edge exists. It still satisfies the numerical “at most B actual Ticks” safety theorem vacuously. Preserve enabledness/transition-matrix tests for every live-budget state and source/native relation comparison, including the missing-Tick source mutant. The existing optional fixture's source-only removed-update mutant at `tests.rs:151` is the analogue. If a missing expiring edge is called “skipped expiry,” require that relation/availability control in addition to the law bundle; do not claim the bound alone detects it.

Likewise, a budget incorrectly initialized below B could satisfy the upper bound. Exact selected starts and the required countdown/reset policy checks detect that semantic error. None-configured Worlds have no finite schedule-to-close theorem; they retain the independent no-live-budget Tick-disabled and exact-fair-worker eventual closure obligations.

This route needs no new support task for counting. It needs explicit registered laws, complete native/source/TLC checking for the selected matrix, exact state/edge evidence for Tick availability, and the stated proof derivation. None has been executed by this preparation memo.
