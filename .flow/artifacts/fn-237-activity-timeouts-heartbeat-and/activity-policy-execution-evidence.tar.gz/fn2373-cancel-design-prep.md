# fn-237.3 cancellation decision preparation

The conductor should settle two separate policies before admitting fn-237.3. I recommend distinct pending Cancel rejects with FailedPrecondition, explicitly as an independent design choice. For closure, I recommend a bounded cooperative handshake contract for this vertical, with an explicit canonical scope amendment and predeclared live refusal at pending attempt boundaries. That preserves the approved retry/deadline laws while avoiding a false claim that every real cancellation requires worker acknowledgement. A full boundary-aware cancellation contract is the stronger alternative below; it requires additional policy decisions that the public sources do not settle.

This is a proposal for the root's next task-boundary decision, not an implementation or an approved amendment. Sole write `.flow/tmp/fn2373-cancel-design-prep.md`. No source, canonical Flow, Git, lifecycle, test, probe or build mutation ran. The active fn-237.1 worker remains the only committer. Brainstorming supplied the alternatives and flow-next-prose supplied the artifact prose contract; this dispatch's sole-output/read-only restrictions govern their generic workflow instructions.

## Evidence and confidence

I read `AGENTS.md`, `model/README.md`, the Umpire specification, architecture rules and module map, canonical fn-237/.3/.4, current `model/temporal/feature/activity/model.rs`, its compatibility harness and the two research reports. The new report is `.flow/tmp/fn237-cancellation-contract-research.md`; the retained report is `.flow/artifacts/fn-227-parameterized-models-declared-worlds/cancellation-evidence-research.md`. No new external research was performed. Source statements below inherit the reports' pinned API and documentation revisions.

**Direct, high confidence.** Public documentation promises one cancellation request/delivery and says repeating the request does not deliver another cancellation. The Cancel request's `request_id` deduplicates cancellation requests. Documentation assigns FailedPrecondition to an existing activity whose state disallows an operation, and NotFound to absence. It does not say whether an already-pending distinct Cancel is a valid idempotent operation or an invalid state operation. [Pinned request-cancel guidance](https://github.com/temporalio/documentation/blob/56a8a19b04e7fe642e4f8da03ff997afc42b40bd/docs/encyclopedia/activities/activity-operations/request-cancel.mdx#L45-L50), [operation errors](https://github.com/temporalio/documentation/blob/56a8a19b04e7fe642e4f8da03ff997afc42b40bd/docs/encyclopedia/activities/activity-operations/index.mdx#L68-L75), [API request ID](https://github.com/temporalio/api-go/blob/20151aa90480/workflowservice/v1/request_response.pb.go#L18393-L18408).

**Direct, high confidence.** Cancel RPC success accepts a request. A heartbeat notifies a worker. RespondActivityTaskCanceled acknowledges cancellation. These are three distinct events. Cancellation without a running attempt closes immediately; while an attempt runs, completion and nonretryable failure can win. Documentation also describes cancellation at the next attempt boundary for a non-heartbeating attempt, giving start-to-close timeout as an example. Consequently, the approved unqualified “only explicit worker cancellation acknowledgement closes as Canceled” statement is too broad as a public protocol claim. [Pinned request-cancel guidance](https://github.com/temporalio/documentation/blob/56a8a19b04e7fe642e4f8da03ff997afc42b40bd/docs/encyclopedia/activities/activity-operations/request-cancel.mdx#L25-L47), [API cooperative contract](https://github.com/temporalio/api-go/blob/20151aa90480/workflowservice/v1/service_grpc.pb.go#L799-L805).

**Unknown.** The reports do not establish the exact pending retryable-Fail outcome, its interaction with exhausted retries, heartbeat-timeout cancellation precedence, or simultaneous whole-execution timeout versus attempt-boundary cancellation. The fact that nonretryable failure may win does not prove a rule for every failure. The standalone terminal Cancel status table and same-request-ID result replay/lifetime also remain unspecified.

The supplied live sequence, Cancel success while Started followed by pending state and a second distinct Cancel returning status 9, is descriptive evidence only. It supplies no authority for either recommendation. A successful comparison with it would not upgrade an inference into a published guarantee.

## Decision 1. Distinct pending Cancel

Two deterministic policies fit the published one-delivery guarantee.

| Policy | Model result while pending | Tradeoff |
| --- | --- | --- |
| Reject a new cancellation intent | Rejected(FailedPrecondition), unchanged pending state | Gives “request once” an explicit invalid-state meaning. The status follows the documented category only after choosing this interpretation. |
| Accept idempotently | Accepted self-loop, unchanged pending state | Treats cancellation as desired-state idempotence. The one-delivery promise alone does not guarantee RPC success. A real status 9 would remain a disagreement. |

I recommend the first, with medium confidence in the design choice and high confidence that it is compatible with the cited guidance. A pending activity exists; a second distinct request is a new operation against a state already carrying that intent. This supplies an explicit reason for invalid-state rejection independent of a server observation. The public text does not compel it, so record the interpretation rather than describing FailedPrecondition as directly specified.

`Client::Cancel` should denote a fresh logical request in this policy. Rejected repetition must preserve the current attempt, every budget and pending state. It must not restart a budget, replace a pending reason, close the activity or create another cancellation notification. The heartbeat bit may remain true on successive heartbeats; “one delivery” does not justify promising that the wire bit appears only once.

Same-request-ID replay is a separate protocol scope. Do not map replay to another fresh `Client::Cancel`, and do not claim the original successful response must replay merely from a deduplication comment. The smallest .3 Model keeps request IDs out of its state and declares its scope as distinct logical intents. The .4 binding must correlate actual request IDs and identify unsupported replay before judging its outcome. This needs no generic deduplication framework.

Keep atomic compatibility behavior unchanged. Atomic Cancel closes immediately, so later Cancel observes a terminal state and retains the existing NotFound law. Pending FailedPrecondition is reachable only in the cooperative World. The distinction does not require relaxing `closed_rejects`.

## Decision 2. Acknowledgement and attempt boundaries

There are three approaches, with different claims.

| Approach | Benefit | Cost or limit |
| --- | --- | --- |
| Bounded handshake, recommended for this vertical | Keeps existing retry and expiry rules and the promised pending/heartbeat/ack/completion/failure controls | Explicitly excludes live pending attempt-boundary conformance. Requires canonical scope language and a named deferred obligation. |
| Boundary-aware cancellation | Represents the documented non-heartbeating boundary and can eventually support a general live protocol binding | Must decide pending timeout/failure precedence, revise applicable cooperative laws and test their combinations. Current research does not determine the complete matrix. |
| Universal acknowledgement-only live promise | Requires the fewest words changed in the task | Contradicts the published boundary description. I do not recommend admitting it as a faithful protocol contract. |

The bounded option preserves a concrete offline Model policy. Cooperative Started + Cancel sets pending; Heartbeat preserves Started/pending; explicit worker acknowledgement yields Canceled; Complete yields Completed; Fail follows the existing retry policy; Tick follows the existing deadline policy. Scheduled Cancel yields Canceled without a worker acknowledgement. The acknowledgement-only law applies to worker-originated cancellation closure during an otherwise continuing attempt. It makes no live conformance claim for pending cancellation followed by timeout, retryable failure or another attempt boundary.

That scope is an explicit abstraction, not evidence that real boundaries yield TimedOut or Scheduled. Its offline graph may expose those chosen transitions to check the approved deadline/retry laws. Results outside the live scope must be labelled as offline policy results. The independently documented pending start-to-close boundary is a known coverage obligation, not a passed cancellation case. The root must keep that obligation open; completing .3 and .4's bounded controls cannot claim the complete standalone cancellation matrix is implemented.

The boundary-aware alternative needs an explicit independent design table. A plausible candidate gives whole-execution schedule-to-close expiry priority as TimedOut; lets pending cancellation win when an attempt ends by start-to-close/heartbeat timeout or a retryable failure with attempts remaining; lets Complete and nonretryable Fail win; and decides exhausted retryable Fail separately. Only parts of that candidate are directly sourced. Heartbeat-timeout extension, whole-execution precedence and exhausted-retry precedence are design inferences or unknowns. Adopting the candidate silently would override the current “every expiry TimedOut” and unconditional retryable-Fail laws. Those changes belong in canonical requirements before Model code. They need no new framework feature, but they are more semantic work than the bounded choice.

## Exact proposed canonical delta

The existing text does not safely authorize either a universal protocol claim or an implicit boundary exception. It explicitly says only acknowledgement closes as Canceled, every expiry yields TimedOut, and failure at maximum attempts yields Failed. Preserve those distinctions by recording the bounded scope before implementation. Suggested wording follows; this report edits none of the canonical files.

**fn-237 R2 and Edge Cases cancellation paragraph.** Replace the acknowledgement sentence with:

> With a running attempt, cooperative Cancel records pending cancellation. Heartbeat reports pending without closing. Explicit worker cancellation acknowledgement closes as Canceled; completion and failure retain their declared race and retry behavior. Scheduled Cancel closes as Canceled without worker acknowledgement. This vertical models a bounded cooperative handshake. Its live conformance scope excludes pending cancellation followed by an attempt boundary, including timeout and retryable failure; those interactions require a separately approved boundary policy. The acknowledgement-only law applies to worker-originated cancellation closure within that bounded handshake. Offline deadline and retry results outside the live scope carry no live protocol claim.

Add to the same paragraph:

> A new distinct Cancel while pending rejects with FailedPrecondition and changes no state or budgets, under the explicit interpretation that cancellation may be requested once. Client::Cancel denotes a distinct logical request. Same-request-ID replay is outside this Model's request-identity scope.

Keep the R2 expiry requirement unchanged for the offline Model. Add an acceptance requirement that the documented pending start-to-close boundary remains an explicit deferred live obligation. A task closure must identify where that obligation is tracked, rather than claim it disappeared through a binding refusal.

**fn-237 R3.** No behavior change. Add only:

> Cooperative scope decisions do not alter the atomic compatibility World, immutable old reference bytes, retained laws or exact lifecycle projection. New cooperative laws state their applicability explicitly. Re-run the retained comparison after each cancellation-policy edit.

**fn-237.3 Approach 3 and cancellation acceptance.** Replace the unqualified acknowledgement-only wording with the bounded paragraph above. Add independent matrix controls for fresh pending Cancel rejection, repeated heartbeat notification without closure, Scheduled cancellation, and unsupported same-ID/attempt-boundary live scope. Retain every old law; the Model's existing retry, terminal and expiry obligations remain executable. Do not implement the bounded scope by disabling Tick, dropping retryable actions, removing laws, suppressing observations or modifying the frozen reference.

**fn-237.4 protocol binding.** Name and version the bounded handshake scope with its evidence and explicit exclusions in the Start receipt. Its required held-attempt heartbeat/ack path, completion race and separate schedule-to-start expiry remain required. Unsupported boundary/replay evidence cannot establish the general cooperative protocol. A later boundary-aware extension must amend the canonical policy and prove the excluded rows before widening admission.

These are scope amendments with a known remaining obligation, not mere editorial clarification. My confidence is high that the amendment is necessary for an honest bounded claim. My recommendation for choosing this smaller vertical is medium; the root may prefer to settle the larger boundary matrix now.

## Controls and fn-237.4 refusal boundary

| Case | Offline Model/control | Live binding requirement |
| --- | --- | --- |
| Scheduled Cancel | Immediate Canceled, including cooperative World | Actual Cancel and terminal Describe; no invented worker acknowledgement |
| Started first Cancel | Accepted, Started/pending | Actual request/result plus pending Describe |
| Pending new distinct Cancel | FailedPrecondition self-loop | Fresh correlated request ID; retain raw status and compare without remapping |
| Same request ID replay | Outside request-identity scope | Predeclared Unsupported unless a separate independently specified dedup contract is proved |
| Pending Heartbeat, repeated Heartbeat | Pending, no terminal cancellation | Actual cancel_requested bit; never equate it with RespondActivityTaskCanceled |
| Pending worker acknowledgement | Canceled | Actual current-attempt acknowledgement and terminal evidence |
| Pending Complete or nonretryable Fail | Completed or Failed | Preserve actual worker response and race order |
| Pending retryable Fail, attempts left or exhausted | Existing offline retry law | Separate unsupported rows until an independent boundary policy is approved; do not infer from nonretryable Fail |
| Pending start-to-close/heartbeat expiry | Existing offline timeout law, exact expiry fact | Unsupported bounded scope; documented start-to-close coverage obligation stays open |
| Simultaneous whole/attempt expiry while pending | Authored offline priority, independently checked | Unsupported until live boundary/priority policy is specified and proved |
| Terminal or stale worker acknowledgement | Retain terminal laws; stale token case separate | Actual token/attempt correlation; do not transplant worker NotFound rules to client Cancel |
| Atomic compatibility World | Exact retained lifecycle projection | Offline compatibility proof; no inference of a live cancellation-mode Start option |

Native and TLC should exercise the same pending/repeat/heartbeat/ack/race matrix and retain the heartbeat-closes mutation, changed-old-edge mutation, retry, exact-action fairness and deadline controls. These are future verification requirements. None ran here.

A binding must decide scope from the declared contract and actual correlated operation/state, before interpreting a surprising status or terminal result. An already-in-scope mismatch remains a finding. It cannot become Unsupported after seeing disagreement. If the root chooses Accepted repetition, the supplied status 9 is a genuine expected-Accepted/observed-FailedPrecondition disagreement. If the root chooses rejection, preserve the same witness as a conforming observation only after the independent policy is recorded. Neither case permits status 9 to become NotFound. Unknown protocol revisions, missing request-ID correlation, unsupported timeout quantization and an absent/unsupported cancellation binding must refuse with the relevant field or contract named. No pending Describe, heartbeat, Cancel RPC acknowledgement or callback label may be normalized into terminal worker cancellation.
