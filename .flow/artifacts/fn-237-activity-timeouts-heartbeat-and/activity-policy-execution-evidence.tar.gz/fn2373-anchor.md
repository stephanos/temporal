# Worker anchor bundle - fn-237-activity-timeouts-heartbeat-and.3 (spec fn-237-activity-timeouts-heartbeat-and)

Each section is the verbatim output of the command it is labeled with, in fixed order, untruncated. The bundle is a floor, not a ceiling - memory keyword-search and every further read remain available.

===== [1/11] task_show: `flowctl show fn-237-activity-timeouts-heartbeat-and.3 --json` =====
{
  "success": true,
  "assignee": "stephanos@users.noreply.github.com",
  "claim_note": "",
  "claimed_at": "2026-10-24T17:48:20.255236Z",
  "created_at": "2026-10-21T21:36:52.603826Z",
  "depends_on": [
    "fn-237-activity-timeouts-heartbeat-and.1",
    "fn-237-activity-timeouts-heartbeat-and.2",
    "fn-237-activity-timeouts-heartbeat-and.6"
  ],
  "id": "fn-237-activity-timeouts-heartbeat-and.3",
  "priority": null,
  "spec": "fn-237-activity-timeouts-heartbeat-and",
  "spec_path": ".flow/tasks/fn-237-activity-timeouts-heartbeat-and.3.md",
  "status": "in_progress",
  "title": "Activity deadlines, cooperative cancellation and final lifecycle refinement",
  "updated_at": "2026-10-24T17:48:20.255218Z",
  "impl": null,
  "review": null,
  "sync": null,
  "status_source": "flow-state"
}

===== [2/11] task_md: `flowctl cat fn-237-activity-timeouts-heartbeat-and.3` =====
---
satisfies: [R2, R3]
---
# fn-237-activity-timeouts-heartbeat-and.3 Activity deadlines, cooperative cancellation and final lifecycle refinement

## Description
Moved from fn-227.4 on 2026-10-21.

This task is the activity-policy consumer of completed F (fn-237.1), O (fn-237.2), World-selected exact assumptions (fn-237.6) and fn-227.3. Remove framework fact/Option/conditional-assumption implementation from this task. Apply the approved R2/R3 contracts (fn-227's R4/R5 amendments at `bbf0835fbf`), retaining all laws and independently lifted source semantics. The final compatibility World and separate no-timeout World answer distinct questions; no all-timeouts-absent expiry witness is claimed.

**Size:** M after fn-227.3/F/O/fn-237.6. One existing activity lifecycle extension using already-proved typed parameters, facts, selected-World exact assumption source admission and replay. Native/TLC policy matrices, fairness and the existing refinement harness are substantial controls of that one extension. A newly required unsupported source construct returns to explicit support planning; it cannot be hidden by removing a law or using native-graph emission.
**Dependencies:** Consume fn-237-activity-timeouts-heartbeat-and.1 (F), fn-237-activity-timeouts-heartbeat-and.2 (O) and the committed implementation/Flow closure of fn-237-activity-timeouts-heartbeat-and.6. Cross-spec prerequisite fn-227.3 (retries and the retained-lifecycle refinement harness), satisfied through this spec's dependency on fn-227. No dependency on fn-227.12 (T); live timeout and cancellation admission belongs to fn-237.4, which consumes this task; fn-237.5 follows it.
**Files:** `model/temporal/feature/activity/{model.rs,tests.rs,temporal.rs,phase.rs}`; activity `expected/**`; the fn-227.3-owned `compatibility/**` projection/harness, without changing immutable old reference bytes; `model/temporal/realization/tests/realization.rs` only for compatibility with the new state/actions before fn-237.4's evidence implementation; `model/temporal/hosts/go/umpire_temporal_guest.wasm`; `model/README.md`.
**Touches:** [model/temporal/feature/activity/**, model/temporal/realization/src/live.rs, model/temporal/realization/tests/**, model/temporal/testing/**, model/temporal/hosts/go/umpire_temporal_guest.wasm, model/README.md]

### Approach

1. Consume fn-227.2's checked scalar constructor and O's typed Ticks/Remaining representation for the four optional configured deadlines and dynamic countdowns. Use one explicit test-local checked World factory for offline fixtures and fn-237.4's extension of fn-227.5's native option admission for live configuration. Keep one canonical range declaration. Some(Ticks(0)) fails those explicit configuration boundaries and source binding; raw World::new remains infallible. Author and source-lift bounds invariants for countdown starts/updates, so a forged or broken native Model value refutes a claim rather than relying on nonexistent generic admission. None is absent. A one-tick armed budget expires on its first decrement without underflow. State explicitly whether terminal exhausted Remaining zero is retained or cleared. No armed nonterminal zero may deadlock instead of expiring.
2. Replace direct deadline actions with the one Tick. Decrement every live budget as authored, expire the first exhausted deadline in an explicit Model priority, and emit exactly its F enum fact. Ordinary/nonexpiring edges emit no fact. Schedule-to-close spans all attempts; start-to-close/heartbeat reset on Poll. State and test schedule-to-start arming/reset across retries and heartbeat reset while Started rather than leaving those implicit. Tick without a live budget is disabled.
3. Preserve atomic cancellation for offline compatibility. Cooperative Cancel during Started sets pending; Heartbeat reports pending without closing, completion/failure remain permitted races, and current-attempt worker acknowledgement closes as Canceled. Pending retryable failure (including at the cap) and selected StartToClose/Heartbeat expiry also close Canceled; selected ScheduleToClose expiry is TimedOut. A fresh distinct pending Cancel rejects FailedPrecondition without changing state. These are explicitly chosen boundary policies; preserve original atomic/nonpending retry laws and add separate cooperative exceptions. Terminal closure clears budgets and pending state. Use a named acknowledgement action. Keep pending state/facts distinct from terminal cancellation; retain ordinary terminal closure/rejection laws. Scheduled cancellation and rejected stale acknowledgements/attempts receive explicit matrix controls.
4. Use existing exact-action weak fairness, separately for each admitted concrete Poll{expected_attempt:k} and RespondCompleted, while retaining heartbeat, failure, cancellation and Tick choices. Poll fairness is necessary after a retry returns to Scheduled; closing-action fairness prevents infinite heartbeat from satisfying the whole worker obligation. RespondCompleted remains enabled in Started even with cancellation pending under the approved race policy. Record the actual finite fair-action list and emit a separate WF obligation for every selected action value. Fairness over one existential Worker/Poll family is insufficient, because stale rejected Poll values could satisfy it forever. Verify eventual closure in a no-timeout World without inventing deadlines, excluding heartbeat or forcing completion behavior in the Model. Verify the schedule-to-close total-tick bound only over its declared applicable Worlds/starts. Its negative controls reset a spanning budget or break an expiry and must refute; no clamped counter, disabled invalid update or exploration cut may fabricate a proof.
5. Run fn-227.3's retained-graph comparison with one attempt, atomic cancellation, one-tick schedule-to-start/start-to-close and the other timeouts absent. State the full state/action/fact projection, including Tick-to-deadline mapping using expiry fact, input assignment deduplication and any explicitly erased new internal stutters. Show those rules preserve every old visible edge and terminal rejection behavior. The immutable old reference and changed-old-edge failure control remain active. Re-run after every timeout/cancellation policy change.

### Investigation targets

Required:

- `model/temporal/feature/activity/model.rs` and `tests.rs` for the post-fn-227.3 lifecycle, laws and retry matrix.
- `.flow/artifacts/fn-227-parameterized-models-declared-worlds/{deadline-fact-contract.md,optional-ticks-contract.md}` for delivered support interfaces.
- `.flow/artifacts/fn-227-parameterized-models-declared-worlds/cancellation-evidence-research.md` for pinned public protocol evidence and its approved correction.
- `model/temporal/feature/activity/compatibility/` for the fn-227.3 retained reference and comparison harness.
- `model/temporal/feature/activity/temporal.rs` and `model/temporal/realization/tests/realization.rs` for necessary interim binding compatibility.

### Verification

Quick from model/: `mise exec -- cargo test -p umpire-temporal-tests`; `mise exec -- cargo test --manifest-path temporal/realization/Cargo.toml`; repeat activity backend tests under `UMPIRE_BACKENDS=require`. Exercise each deadline alone, simultaneous expiry, reset/spanning across retries, zero/one/max, no-live-budget and pending cancellation races. On timeoutless Worlds, removing closing-action fairness must expose the infinite heartbeat counterexample, and omitting current-attempt Poll fairness must expose retry starvation despite other stale rejecting Polls. Run changed-edge, broken-budget, broken-expiry and heartbeat-closes mutations through actual tests. Scoped fmt and strict clippy.

Closed I (fn-227.8; `3fd1d2f551`, `0469334f91`) already delivers exact concrete-value WF. Consume fn-237.6's bounded exhaustive World-only helper selection to author Poll(1)..Poll(maximum_attempts) plus RespondCompleted independently in source and compiled native. Reanchor both receipts, preserve I's action_inputs controls and its explicitly nondiscriminating bounded-fairness behavioral limitation, and exercise stale-Poll starvation on the actual activity. A missing exact-WF regression goes through its owning support boundary; do not reopen closed I, infer policy by catalog intersection, or implement generic framework support inside this consumer.

Full from root: `make model-check`, `UMPIRE_BACKENDS=require make model-check`, `make model-time`, refreshed `make umpire-guest`, `make umpire-check-model-slice`, `make umpire-check-model-gaps`. Required TLC must execute the activity and replay exact expiry facts and false claims. Retain native/default and larger-world counts, Cases(n), actual fairness descriptors and timing including soft-budget misses. Update only approved activity output; old independent evidence and unrelated artifacts/metadata remain exact.

### Worker actions under programmed workers (2026-10-24)

Heartbeat and the cancellation acknowledgement are Model actions the worker performs and Umpire observes in server history (fn-243); nothing in the Model changes for that. `temporal.rs` gains their program rows in fn-237.4, not here; this task only keeps the realization compiling against the new state and actions.

### Boundary-policy proposal for fresh review

Consume the revised R2 matrix and retained independent public research. Tick selection is ScheduleToClose > StartToClose > Heartbeat > ScheduleToStart; one exact expiry fact records the selected trigger even when terminal phase is Canceled. Preserve ordinary/no-expiry empty facts. The older activity-specific fact=>TimedOut/Cancel=>empty statements are superseded, not the generic F contract. Keep frozen atomic compatibility artifacts and exact projection unchanged. Explicitly scope old retry-at-cap laws to atomic/nonpending states and independently check the new cooperative branch; do not remove laws or conceal an exception. Same-request-ID replay has no Model outcome promise. Public evidence versus design inference must be labelled before comparing the deployment. Add pending retryable-failure below/at-cap, pending attempt-expiry, global-priority and fact-only mutants to native/TLC controls.


Selected policy and provenance: `.flow/artifacts/fn-237-activity-timeouts-heartbeat-and/cancellation-boundary-contract.md`; exact live evidence limits are in `cancellation-boundary-evidence-shape.md`. Fresh plan review must pass before implementation.

### Constructor compatibility owner (plan-review P2)

This task owns minimal production constructor compatibility in `model/temporal/realization/src/live.rs` and the feature default-runtime constructors when the generated World gains fields, so its gates compile before .4 adds live admission. Preserve the exact pre-.4 admitted semantics: actual maximum_attempts plus atomic cancellation and the previous timeout-absent live defaults; do not enable cooperative mode, fabricate Start fields or admit nonzero timeout values here. The declared final offline compatibility World separately retains its one-tick deadlines and exact old projection. .4 later replaces the live defaults with validated request-derived fields and a pinned binding. Keep the existing unheld atomic scope refusal until .5 consumes .4's committed proof.
## Acceptance
- [ ] Independently specify repeated cancellation while a cancellation request is pending from the approved domain/API contract before comparing implementation behavior. The retained server code 9 observation does not itself authorize Model semantics or a NotFound remapping; preserve a genuine disagreement as a finding.
- [ ] All four deadline arming/reset/spanning and authored simultaneous-priority controls pass. Exact expiry facts, zero handling and disabled no-budget Tick survive native/TLC agreement and replay.
- [ ] Cooperative pending-heartbeat/acknowledgement and completion/failure races follow the approved policy; atomic compatibility and all terminal/stale-attempt laws remain. A heartbeat-only closure mutation fails.
- [ ] Exact concrete Poll and closing-action weak-fairness obligations verify progress natively and on required TLC Worlds, including no-timeout/retry Worlds. Union-fairness, missing-close and stale-Poll starvation controls remain discriminating; applicable tick-bound/reset/expiry defects refute without counter clamping or cuts.
- [ ] The final compatibility World passes exact retained-lifecycle projection/comparison; changed old edges fail. All old reference bytes and every old law remain independently checked.
- [ ] Activity goldens/coverage state Cases(n), source/TLC counts and timings. Existing live controls pass after the normal guest refresh; unrelated golden/expansion bytes remain exact. Live timeout/protocol admission is handed to fn-237.4, not inferred from a checker World.


## Done summary
TBD

## Evidence
- Commits:
- Tests:
- PRs:

===== [3/11] spec_show: `flowctl show fn-237-activity-timeouts-heartbeat-and --json` =====
{
  "success": true,
  "branch_name": "fn-237-activity-timeouts-heartbeat-and",
  "completion_review_status": "unknown",
  "completion_reviewed_at": null,
  "created_at": "2026-10-21T21:34:42.906942Z",
  "default_impl": null,
  "default_review": null,
  "default_sync": null,
  "depends_on_epics": [
    "fn-227-parameterized-models-declared-worlds"
  ],
  "id": "fn-237-activity-timeouts-heartbeat-and",
  "impl_review_rounds": {
    "fn-237-activity-timeouts-heartbeat-and.1": 0,
    "fn-237-activity-timeouts-heartbeat-and.2": 0,
    "fn-237-activity-timeouts-heartbeat-and.6": 0
  },
  "next_task": 1,
  "plan_review_rounds": 0,
  "plan_review_status": "ship",
  "plan_reviewed_at": "2026-10-24T15:37:23.715400Z",
  "ready": true,
  "review_hash_epoch": {
    "impl:fn-237-activity-timeouts-heartbeat-and.1": 1,
    "impl:fn-237-activity-timeouts-heartbeat-and.2": 1,
    "impl:fn-237-activity-timeouts-heartbeat-and.6": 1,
    "plan": 2,
    "plan#completion": 0
  },
  "review_pending_rounds": {},
  "review_reservations": {},
  "review_transport_failures": {
    "impl:fn-237-activity-timeouts-heartbeat-and.1": 0,
    "impl:fn-237-activity-timeouts-heartbeat-and.2": 0,
    "impl:fn-237-activity-timeouts-heartbeat-and.6": 0,
    "plan": 0
  },
  "spec_path": ".flow/specs/fn-237-activity-timeouts-heartbeat-and.md",
  "status": "open",
  "title": "Activity timeouts, heartbeat and cooperative cancellation (model, temporal)",
  "updated_at": "2026-10-24T17:33:24.040539Z",
  "tasks": [
    {
      "id": "fn-237-activity-timeouts-heartbeat-and.1",
      "title": "Optional handler facts through native adapters and independent TLC replay",
      "status": "done",
      "status_source": "flow-state",
      "implicit_owner": false,
      "priority": null,
      "depends_on": []
    },
    {
      "id": "fn-237-activity-timeouts-heartbeat-and.2",
      "title": "Bounded nominal optional values through source binding, emission and decode",
      "status": "done",
      "status_source": "flow-state",
      "implicit_owner": false,
      "priority": null,
      "depends_on": []
    },
    {
      "id": "fn-237-activity-timeouts-heartbeat-and.3",
      "title": "Activity deadlines, cooperative cancellation and final lifecycle refinement",
      "status": "in_progress",
      "status_source": "flow-state",
      "implicit_owner": false,
      "priority": null,
      "depends_on": [
        "fn-237-activity-timeouts-heartbeat-and.1",
        "fn-237-activity-timeouts-heartbeat-and.2",
        "fn-237-activity-timeouts-heartbeat-and.6"
      ]
    },
    {
      "id": "fn-237-activity-timeouts-heartbeat-and.4",
      "title": "Live timeout admission, cooperative cancellation evidence and SDK cancellation proof",
      "status": "todo",
      "status_source": "committed",
      "implicit_owner": false,
      "priority": null,
      "depends_on": [
        "fn-237-activity-timeouts-heartbeat-and.3"
      ]
    },
    {
      "id": "fn-237-activity-timeouts-heartbeat-and.5",
      "title": "After .4: DESIGN.md timeout and cancellation write-up",
      "status": "blocked",
      "status_source": "flow-state",
      "implicit_owner": false,
      "priority": null,
      "depends_on": [
        "fn-237-activity-timeouts-heartbeat-and.4"
      ]
    },
    {
      "id": "fn-237-activity-timeouts-heartbeat-and.6",
      "title": "World-selected exact fairness lists through independent source binding",
      "status": "done",
      "status_source": "flow-state",
      "implicit_owner": false,
      "priority": null,
      "depends_on": [
        "fn-237-activity-timeouts-heartbeat-and.2"
      ]
    }
  ],
  "no_plan": false
}

===== [4/11] spec_md: `flowctl cat fn-237-activity-timeouts-heartbeat-and` =====
# Activity timeouts, heartbeat and cooperative cancellation (model, temporal)

> HTML render lens: open `.flow/artifacts/fn-237-activity-timeouts-heartbeat-and/spec.html` locally — regenerable, markdown is the record. <!-- flow-next:artifact-link -->

## Conversation Evidence

> user (2026-10-20), in the fn-227 capture: "what would we parameterize there on the tempporal model?"
> assistant: world parameters `maximum_attempts`, the four timeouts present or absent with small values, asynchronous cancel; dynamic `attempt`, deadline budgets, `cancel_requested`; action inputs `retryable` on RespondFailed, Heartbeat, Poll's expected attempt; computed starts over small domains; leave out task queues, versioning and local activities.
> user (2026-10-21), approving the three compatibility, cancellation and request-evidence amendments described in fn-227's Decision Context: "yes Approve all three"
> user (2026-10-21), owner decision: move the activity timeout semantics out of fn-227 into a new spec: old R5 entirely, tasks fn-227.9 (facts F), fn-227.10 (optional values O) and fn-227.4 (deadlines, cooperative cancel, final lifecycle refinement), the cooperative-cancellation live part of R6 and fn-227.5, the final one-tick compatibility World refinement re-run, and a write-up task for the timeout and cancellation additions.
> user (2026-10-21): "we need TLC on the real, activity Model still" — fn-227 therefore keeps its R3 in full, including fn-227.11's source `impl Phased`/`reject!` admission, so the activity Model is TLC-checked before this spec starts.

## Goal & Context

fn-227 extends the activity Model in place with a declared World, action inputs and a bounded retry policy, proves a retained-lifecycle refinement checkpoint with one attempt, the old direct deadline actions and atomic cancellation, admits the activity source to TLC, and binds `maximum_attempts` from the actual Start request. This spec finishes the activity lifecycle on top of that: the four optional timeouts as abstract tick budgets, Heartbeat, one `Tick` action with an exact expired-deadline fact, cooperative cancellation, the fair-worker progress claim and the schedule-to-close total-tick bound, the final one-tick compatibility World, and the live realization of timeouts and cooperative cancellation.

The content moved from fn-227 on 2026-10-21 with its owner-approved contracts unchanged. It was split so that fn-227 can close with the declared-World, input and retry surface (and TLC on the real activity Model) while the timeout and cancellation semantics, which need two further framework support slices (zero-or-one handler facts and bounded nominal optional values), proceed as their own vertical.

## Architecture & Data Models

- **Activity World, extended.** fn-227's World (`maximum_attempts: 1..=3`) gains `schedule_to_start`, `start_to_close`, `schedule_to_close`, `heartbeat_timeout`, each `Option<Ticks>` over a small domain, and `asynchronous_cancel: bool`. State gains per-deadline remaining budget in abstract ticks and `cancel_requested`. Actions gain heartbeat, explicit worker cancellation acknowledgement and `Deadline::Tick`, beside the existing `Client::Cancel`. The retained old lifecycle graph is the independent reference for an explicit semantic-refinement check. The final compatibility World uses one attempt, atomic cancellation and one-tick schedule-to-start/start-to-close budgets, with the other timeouts absent. A separate all-timeouts-absent World has no Tick edge.
- **Support slices.** Facts checkpoint F lets a handler return `Option<F>` for one local fieldless enum, lowered independently to zero-or-one typed facts; the activity uses it for the expired-deadline fact. Optional-value checkpoint O gives bounded nominal newtypes (`Ticks`, `Remaining`) and `Option` of them an exact source encoding, binding and decode, consuming fn-227.2's single range declaration and checked scalar constructor.
- **World-selected exact assumptions.** Task fn-237.6 supplies bounded exhaustive World-only if/else selection around existing literal fair/only/without leaves. Every branch is admitted; primitive Bool fields/comparisons and Int comparisons with matching literal/source-constant values select exactly one leaf from validated typed World values before catalog membership. Registered and progress assumptions preserve helper identity; unused selected invalid scopes refuse. Inactive larger-domain leaves are not filtered or unioned. The compiled native callback stays independent, and closed I's per-concrete-value WF semantics stay unchanged. Naming reserves conditional generated fairness operators and aliases before binding; unresolved plans fail closed. No general evaluator, dynamic list or public callback API is added.
- **Realization.** fn-227.5's transactional `Realize<activity::World>` admission from the actual filled `StartActivityExecutionRequest` and successful same-invocation result extends to the timeout fields through a per-field timeout-to-tick table. An explicit pinned protocol binding supplies cooperative cancellation, since Start has no cancellation-mode field. Workers follow fn-243's programs: the activity program gains heartbeat and cancellation-acknowledgement rows (response kinds `RecordActivityTaskHeartbeat` and `RespondActivityTaskCanceled`; the cancel-requested bit a heartbeat response reveals becomes a key field), schedule-to-start uses the existing prepoll hold, while a distinct explicit response-hold fault is required for the server-started witness (prepoll hold alone cannot establish Started), and judgment reads server history: actual Cancel, pending Describe, heartbeat with the cancel notification, worker acknowledgement and terminal Describe. There is no Answer path. Actual heartbeat response and worker-acknowledgement RPC evidence reaches Judge/replay through the feature-owned ActivityEvidence Any wrapper, captured by the owned transport and validated by the existing Observed/facade/Realization owners; Describe alone is insufficient.

## API Contracts

- The deadline-fact support uses an opt-in `Option<F>` handler result for one local fieldless enum, independently lowered to zero-or-one typed facts. Unit handlers, old expansions, enabledness and reject/stay semantics remain unchanged.
- Optional bounded timeouts retain nominal source types and exact domain checks through binding, emission and decoding; Finite enumeration alone is not construction validation. Explicit fixture/live admission validates configuration; authored native invariants detect invalid state updates, while source bindings and typed decoding independently refuse invalid values. No generic Machine/state validity hook or fallible World constructor is added.
- No change to `Steps`, `Outcome`, `Verdict`, the author-name rendering contract or the core oracle protocol. No generic core envelope or core ABI change beyond fn-227's approved optional request `Any` at `Observation` tag 4, and no fabricated Start cancellation field.

## Edge Cases & Constraints

- The schedule-to-close budget spans attempts; start-to-close and heartbeat budgets reset on each `Poll`; `Tick` with no live budget is disabled. The retained retry laws hold unchanged in atomic Worlds and without cooperative pending cancellation: retryable failure retries exactly below maximum_attempts and otherwise closes Failed; nonretryable failure closes Failed at every attempt. With cooperative pending cancellation, retryable failure closes Canceled at the current attempt, including at the cap, and starts no retry. This boundary-precedence rule is an independently chosen policy, not an inferred server guarantee.
- With asynchronous cancellation, Cancel in Started records a pending request. Heartbeat reports that request without closing; completion/failure remain permitted races. Explicit current-attempt worker acknowledgement closes as Canceled. Pending retryable failure and selected StartToClose/Heartbeat expiry also close as Canceled at the attempt boundary. Selected ScheduleToClose expiry yields TimedOut. A fresh distinct pending Cancel rejects with FailedPrecondition and preserves all state; this is the chosen invalid-state interpretation, while same-request-ID replay remains unspecified. Terminal closure clears pending state and budgets. Atomic cancellation remains available to the offline compatibility World. Live cancellation mode comes from the explicit protocol binding, never an invented Start option or silent default.
- `Some(Ticks(0))` fails the explicit configuration boundaries and source binding; raw `World::new` remains infallible. A one-tick armed budget expires on its first decrement without underflow. No armed nonterminal zero may deadlock instead of expiring.
- Every Model without facts or optional values keeps byte-identical goldens and expansion snapshots; old unit-handler expansions stay exact.
- R30 budgets hold: inner loop under 10 s and gate under the current soft target warm; the activity's default fixture World is bounded so the native checker finishes well inside them, and the larger Worlds are exercised through TLC under `UMPIRE_BACKENDS=require`.
- No new crates beyond what the workspace already admits; the fn-210 R18 dependency policy applies.

## Acceptance Criteria

- **R1:** Handler facts and bounded optional values are admitted independently in native adapters and source lifting: an opt-in `Option<F>` handler result for one local fieldless enum yields zero-or-one typed facts, and bounded nominal newtypes and `Option` of them keep their exact domain through source binding, emission and decoding. Each has a shared fixture with goldens that agrees with TLC and replays false claims. Errors: unsupported carriers, aliases, nested options and unsupported source forms are located compile or source refusals; out-of-range or wrong-kind values refuse at binding or decoding; old expansions and all pre-existing artifacts stay byte-identical.
- **R2:** The activity Model carries the four optional timeouts, Heartbeat, Tick and asynchronous cancellation. Cooperative Started Cancel records pending without changing budgets; heartbeat reports pending without closing. Complete and nonretryable Fail may win; current-attempt worker acknowledgement, retryable failure (including at the cap), and selected StartToClose/Heartbeat expiry close pending cancellation as Canceled. A fresh distinct pending Cancel rejects FailedPrecondition with an exact self-loop under the explicit invalid-state policy; same-request-ID replay is unspecified. Tick decrements all live budgets and selects one expiry by ScheduleToClose > StartToClose > Heartbeat > ScheduleToStart. Selected ScheduleToClose expires TimedOut; attempt-deadline expiry while pending is Canceled; every other applicable expiry is TimedOut. Exactly the selected deadline fact is emitted, independently of terminal phase; ordinary/nonexpiring edges have none. State the exact-action fair-worker assumptions and verify eventual closure and the spanning ScheduleToClose total-tick bound natively/default and by TLC/larger Worlds. Errors: all timeouts absent disables Tick; no pending-heartbeat evidence alone implies Canceled; zero/underflow and wrong-priority/fact/boundary controls remain discriminating.
- **R3:** The final compatibility World has one attempt, atomic cancellation, one-tick schedule-to-start/start-to-close budgets and no other timeouts. It passes fn-227 R4's retained-lifecycle refinement control: a stated state/action/fact projection, including the Tick-to-deadline mapping, and exact comparison against the retained old lifecycle graph. Re-run the control after every timeout/cancellation change. Errors: a changed old lifecycle edge must fail the control; old reference bytes and every old law stay independently checked. Cooperative pending exceptions never alter the atomic compatibility policy or frozen evidence. Existing retry laws remain checked over their original atomic/nonpending scope, with separate executable cooperative boundary laws.
- **R4:** The realization extends fn-227's transactional live World admission to the four timeout fields through an explicit per-field timeout-to-tick table and to `asynchronous_cancel` through the explicit pinned protocol binding. Worker heartbeat and acknowledgement are program rows (fn-243), judged from server history. The live run with the raw executor, then the sdk executor with identical judgments, proves a held-started server cancellation (distinct response-hold fault, preserving the prepoll fault for schedule-to-start) with actual Cancel, pending heartbeat and acknowledgement, a completion-after-cancel race, and a schedule-to-start expiry under a hold; fn-227's retry proof and existing Complete/Fail/HostRefusal/context-Cancellation controls keep passing. Errors: out-of-domain timeout values return field-named Unsupported and freeze admission; a missing or unsupported binding names `asynchronous_cancel` and refuses admission; no generic core envelope, core ABI or Start field change. The mandatory live rows above remain unchanged. Name the boundary policy and distinguish its larger offline graph from live admitted evidence: exact pending-expiry causes require actual typed/correlated evidence; otherwise that narrow scope is predeclared field-named Unsupported and documented, never reconstructed from desired actions, configured timeouts, elapsed time or terminal Canceled alone. A surprising in-scope outcome remains a finding. No refusal discharges an original mandatory row or fn-243.5 proof.
- **R5:** DESIGN.md records the timeout and cancellation additions: the extended activity World and state table, deadline priority and zero/reset laws, cooperative cancellation, the exact-action fair-worker assumption, the final compatibility projection, native and TLC state counts per selected World, and `make model-time` output. No error surface beyond the gate.

## Boundaries

- No real clock: `Tick` is an abstract unit; wall-clock timeout values in requests map to tick budgets through a declared domain, not to durations.
- No nondeterministic choice within one action and no typed outcomes beyond what the activity needs; facts are limited to the expired-deadline fact in R2.
- No task queue, worker versioning, local activity, eager dispatch or Nexus parameters.
- No Bank or Voting port; facts and optional values are built for the activity Model and their two shared fixtures only.
- No Apalache work; fn-211 consumes the same lifted tree afterwards.
- No change to fn-227's declared-World, input, retry or request-transport surfaces beyond consuming them.

## Decision Context

2026-10-24, conductor-selected prerequisite under the autonomous milestone goal [inferred, confirmed by repository/spec/gap scouts]: existing R2 needs different exact Poll lists for selected maximum_attempts 1/2/3, while source assumption leaves currently accept only literal lists. One cohesive M, fn-237.6, joins source admission, typed selection and independent binding across five existing production owners. Splitting would introduce an intermediate unresolved-plan contract without another needed capability; a general evaluator or catalog-derived policy is rejected as unnecessary for this bounded grammar. This source support changes no accepted cancellation/deadline cell and does not reopen closed I. The planning record and verbatim scout findings are retained under `.flow/artifacts/fn-237-activity-timeouts-heartbeat-and/world-fairness-*`.

Execution order: committed fn-237.2 -> fn-237.6 -> fn-237.3 -> fn-237.4 -> committed fn-243.5 -> fn-237.5. Task .3 retains its original F/O prerequisites. Cross-spec task edges are unsupported: the conductor admits fn-243.5 only after .4's implementation and Flow closure are ancestors of umpire (retaining fn-243.4), then clears .5's existing block only after fn-243.5's implementation and closure are ancestors too. fn-228/fn-243 remain open until their retained obligations close. No whole-spec edge is added between fn-237 and fn-243.

Shared-file dispatch inventory (plan-review P2): .1/.2 share `model/README.md` and `model/temporal/hosts/go/umpire_temporal_guest.wasm`; .1/.6 share `model/README.md`. These pairs are serial despite no direct dependency path. F/O are already committed and done before .6 admission; do not reopen them or manufacture retroactive edges. Remaining source, shared cache, documentation, guest and final-gate ownership stays serial at the stated chain boundaries.

Plan-review P1 fixes the live execution delegation contract without changing R2 policy: .4 admits at most one nonterminal heartbeat followed by one terminal response per polled task, selects the follow-up row from the actual correlated heartbeat response, and proves SDK cancellation delivery as well as wire evidence. Legacy terminal-only programs retain their behavior. The task owns decoder/raw/SDK changes together; a repeated response field is not an existing sequence interpreter.

Maintainability (plan review): duplication - none identified; structure - Task .4 adds heartbeat, cancellation and timeout projection branches to Realization::describe, which already reconstructs retries and validates terminal evidence. Resolve by extending existing Observed/receipt validation and keeping feature-local worker evidence projection beside Describe projection, without a sibling interpreter or duplicated policy.

2026-10-24, conductor-selected planning amendment under the standing autonomous milestone goal: independently amend the previously unqualified acknowledgement-only, retry-at-cap and TimedOut-only rules with the boundary policy in R2. Public request-cancel guidance documents attempt-boundary cancellation; repeated-request status and several precedence cells remain unspecified. FailedPrecondition for a fresh pending intent, retryable-failure precedence at the cap, heartbeat-timeout cancellation and global-timeout priority are declared Model design choices, not facts inferred from the retained status-9 counterexample. Preserve that witness and every genuine comparison disagreement. The original API/ABI, immutable atomic reference and required live rows remain unchanged. The activity-specific TimedOut-only/empty-cancellation-fact sentences in the older deadline-fact engineering report are superseded for this consumer; its generic F interface and byte-preservation requirements are unchanged. Fresh plan review is required before this policy is implemented. The selected contract, provenance and live evidence limits are retained at `.flow/artifacts/fn-237-activity-timeouts-heartbeat-and/cancellation-boundary-contract.md`, `cancellation-contract-research.md` and `cancellation-boundary-evidence-shape.md`.

2026-10-24: this spec follows fn-243 (programmed workers), which supersedes the Shim and the live Answer path for Temporal workers. Consequences: .4's worker evidence is program rows and server history, not Answer; the held attempt and the schedule-to-start expiry use fn-243's hold fault; the live slice runs through `umpire explore` with the raw and sdk executors. fn-211 is deferred, so the 2026-10-23 queue order below reads fn-228, fn-238, fn-244, fn-243, then this spec. Task paths predate fn-244's layout; the mapping is under Resolved via Codebase.

2026-10-23, owner: "let's enable the deferred ones and add them to the end". Reactivate all five tasks after fn-211, fn-228 and the remaining fn-238 tasks. Preserve the existing timeout, cancellation, refinement and live-evidence requirements; queue order does not add dependency edges. Reanchor task paths and support contracts against the integrated Runner and interpreted-checker changes before admission.

2026-10-21, owner: move the activity timeout semantics out of fn-227 into this spec. fn-227 keeps R3 in full, including source `impl Phased`/`reject!` admission (fn-227.11), because "we need TLC on the real, activity Model still". fn-227 also keeps retries with the refinement checkpoint (fn-227.3), request transport (fn-227.12), transactional live admission with the SDK retry proof (fn-227.5) and its own write-up (fn-227.6). This spec depends on fn-227.

Approved amendments carried over unchanged. fn-227's 2026-10-21 owner approval ("yes Approve all three") approved three named amendments; two of them bind this spec:

- R2/R4 use cooperative cancellation with explicit protocol evidence, including heartbeat signaling and completion/failure races. Live cancellation mode comes from an explicit pinned protocol binding, never an invented Start option.
- fn-227 R4's lifecycle refinement against retained old evidence replaces impossible byte equality. The reviewer independently confirmed that the original literal witness was impossible because the old graph has enabled deadline actions and the new Model adds state/input spelling. The approved replacement is an executable semantic-refinement witness with the compatibility World specified in R3, a stated state/action/fact projection and exact comparison against the retained old lifecycle graph. Preserve the original graph/goldens as evidence. Hiding fields, keeping files without a proof, or removing old edges does not discharge the requirement. fn-227's retry checkpoint establishes the projection with the retained deadline behavior; this spec re-runs the proof with the final one-tick compatibility World.

These approvals do not approve other protocol changes, remove laws or complete tasks.

Rejected (from fn-227): a real-time clock in the Model (TLC and native exploration need an abstract tick, and the realization maps durations to budgets); a sibling activity Model beside the six-phase one.

## Resolved via Codebase

- Paths after fn-244.1 (2026-10-24): `model/umpire/dsl` is `model/umpire/author/dsl` (macros under it); `model/umpire/lift` is `model/umpire/backends/tla` (crate `umpire-tla`); `model/umpire/backends/tlc` is unchanged; `model/umpire/tests/fixtures/<name>` is `model/umpire/dev/fixtures/fixtures/<name>` (crate `umpire-fixtures`); `model/umpire/testing` is `model/umpire/dev/testing`; `umpire-wasm` is `umpire-runtime` at `model/umpire/protocol/runtime`; the Go Runner is `model/umpire/hosts/go/runner` and the Temporal Driver is `common/testing/testpilot/temporal`. `model/temporal/**` paths are unchanged.
- Support aliases carried from fn-227: F (facts) is this spec's task fn-237.1, O (optional values) is fn-237.2. I (input source) is fn-227.8, P (phase/rejection source admission) is fn-227.11, T (request capture) is fn-227.12. Each support slice closes its own vertical controls before its activity consumer. Overlapping source/generated ownership is scheduled serially; task dependencies express consumption, not permission to share a cache or checkout.
- Committed `bbf0835fbf` native `checker/src/progress.rs` selects exact fair action values and the TLC emitter constructs WF for each admitted action operator. fn-227.8 (I) owns exact concrete input identity/fairness.
- Closed I's delivered exact-value WF commits are `3fd1d2f551` and `0469334f91`; fn-237.6 adds only selected-World source expressibility. Reanchor at O's final executable source `6f0fb85f56b20dfa1e94fbeb286f17ce2ae61a41` and committed closure `d6306a579ff220f1abdfb35cd8abcc9b068e91e7`. Reuse `model/umpire/dev/testing/src/bound.rs:89` selected-World guard and `model/umpire/backends/tla/tests/world.rs:381` five-CFG controls. The conditional fixture must instantiate every CFG family and reject legal World swaps even when verdicts match.
- Runtime admission, receipt, freeze and Reset transactions are fn-227.5's; this spec extends its admission table and evidence mapping, not its transaction state machine.
- Engineering contracts stay at their fn-227 artifact paths: `.flow/artifacts/fn-227-parameterized-models-declared-worlds/{deadline-fact-contract.md,optional-ticks-contract.md,cancellation-evidence-research.md,start-admission-contract.md}`.

## Quick commands

Early proof point: before the activity consumer, fn-237.6's ordinary `world_fairness` fixture compares compiled native, interpreted, embedded and independently re-admitted source with actual required TLC at maxima 1/2/3. Assert exact Poll(1)..Poll(m) plus close (2/3/4 values), allowed/fair ordinals and separate WF obligations. Source-only selector/leaf mutants keep compiled code fixed; missing-close heartbeat and missing-current-Poll retry starvation must replay. Preserve the established action_inputs bounded-fairness control's behavioral limitation and every old tracked artifact byte.

```bash
make model-check
UMPIRE_BACKENDS=require make model-check
make model-time
```

## Requirement coverage

| Req | Description | Task(s) | Gap justification |
| --- | --- | --- | --- |
| R1 | Handler facts and bounded optional values are admitted independently in native adapters and source lifting: an opt-in `Option<F>` handler result for one local fieldless enum yields zero-or-one typed facts, and bounded nominal newtypes and `Option` of them keep their exact domain through source binding, emission and decoding. Each has a shared fixture with goldens that agrees with TLC and replays false claims. Errors: unsupported carriers, aliases, nested options and unsupported source forms are located compile or source refusals; out-of-range or wrong-kind values refuse at binding or decoding; old expansions and all pre-existing artifacts stay byte-identical. | fn-237-activity-timeouts-heartbeat-and.1, fn-237-activity-timeouts-heartbeat-and.2 | — |
| R2 | The activity Model carries the four optional timeouts, Heartbeat, Tick and asynchronous cancellation. Cooperative Started Cancel records pending without changing budgets; heartbeat reports pending without closing. Complete and nonretryable Fail may win; current-attempt worker acknowledgement, retryable failure (including at the cap), and selected StartToClose/Heartbeat expiry close pending cancellation as Canceled. A fresh distinct pending Cancel rejects FailedPrecondition with an exact self-loop under the explicit invalid-state policy; same-request-ID replay is unspecified. Tick decrements all live budgets and selects one expiry by ScheduleToClose > StartToClose > Heartbeat > ScheduleToStart. Selected ScheduleToClose expires TimedOut; attempt-deadline expiry while pending is Canceled; every other applicable expiry is TimedOut. Exactly the selected deadline fact is emitted, independently of terminal phase; ordinary/nonexpiring edges have none. State the exact-action fair-worker assumptions and verify eventual closure and the spanning ScheduleToClose total-tick bound natively/default and by TLC/larger Worlds. Errors: all timeouts absent disables Tick; no pending-heartbeat evidence alone implies Canceled; zero/underflow and wrong-priority/fact/boundary controls remain discriminating. | fn-237-activity-timeouts-heartbeat-and.1, fn-237-activity-timeouts-heartbeat-and.2, fn-237-activity-timeouts-heartbeat-and.3, fn-237-activity-timeouts-heartbeat-and.6 | — |
| R3 | The final compatibility World has one attempt, atomic cancellation, one-tick schedule-to-start/start-to-close budgets and no other timeouts. It passes fn-227 R4's retained-lifecycle refinement control: a stated state/action/fact projection, including the Tick-to-deadline mapping, and exact comparison against the retained old lifecycle graph. Re-run the control after every timeout/cancellation change. Errors: a changed old lifecycle edge must fail the control; old reference bytes and every old law stay independently checked. Cooperative pending exceptions never alter the atomic compatibility policy or frozen evidence. Existing retry laws remain checked over their original atomic/nonpending scope, with separate executable cooperative boundary laws. | fn-237-activity-timeouts-heartbeat-and.3 | — |
| R4 | The realization extends fn-227's transactional live World admission to the four timeout fields through an explicit per-field timeout-to-tick table and to `asynchronous_cancel` through the explicit pinned protocol binding. Worker heartbeat and acknowledgement are program rows (fn-243), judged from server history. The live run with the raw executor, then the sdk executor with identical judgments, proves a held-started server cancellation (distinct response-hold fault, preserving the prepoll fault for schedule-to-start) with actual Cancel, pending heartbeat and acknowledgement, a completion-after-cancel race, and a schedule-to-start expiry under a hold; fn-227's retry proof and existing Complete/Fail/HostRefusal/context-Cancellation controls keep passing. Errors: out-of-domain timeout values return field-named Unsupported and freeze admission; a missing or unsupported binding names `asynchronous_cancel` and refuses admission; no generic core envelope, core ABI or Start field change. The mandatory live rows above remain unchanged. Name the boundary policy and distinguish its larger offline graph from live admitted evidence: exact pending-expiry causes require actual typed/correlated evidence; otherwise that narrow scope is predeclared field-named Unsupported and documented, never reconstructed from desired actions, configured timeouts, elapsed time or terminal Canceled alone. A surprising in-scope outcome remains a finding. No refusal discharges an original mandatory row or fn-243.5 proof. | fn-237-activity-timeouts-heartbeat-and.4 | — |
| R5 | DESIGN.md records the timeout and cancellation additions: the extended activity World and state table, deadline priority and zero/reset laws, cooperative cancellation, the exact-action fair-worker assumption, the final compatibility projection, native and TLC state counts per selected World, and `make model-time` output. No error surface beyond the gate. | fn-237-activity-timeouts-heartbeat-and.5 | — |

===== [5/11] git_status: `git status --short --branch` =====
## umpire...origin/umpire [ahead 7]

===== [6/11] git_log: `git log -5 --oneline` =====
88f3f2098e docs(flow): order MILESTONES spec sections by execution order
d54466b547 chore(flow): task receipt fn-237-activity-timeouts-heartbeat-and.6
f0380f58fa docs(flow): preserve primary World fairness SHIP receipt
88f2f3d8c4 docs(flow): preserve World fairness gate and replay evidence
01e2fee468 docs(flow): retain standards follow-up for World fairness

===== [7/11] git_branch: `git rev-parse --abbrev-ref HEAD` =====
umpire

===== [8/11] memory_enabled: `flowctl config get memory.enabled --json` =====
{
  "success": true,
  "key": "memory.enabled",
  "value": true
}

===== [9/11] glossary: `flowctl glossary list --json --match "<task title + description>"` =====
(no glossary entry matches the task title or description - skipped)

===== [10/11] memory_index: `flowctl memory list` =====
bug/build-errors/
  track-schema-inputs-before-reusing-2026-09-07 — "Track schema inputs before reusing generated Lean modules" (module: model/lakefile.lean)
  glossary-renames-can-reintroduce-names-2026-09-13 — "Glossary renames can reintroduce names the vocabulary gate retired" (module: tools/umpire/internal/retiredvocabulary/check.go)
  ci-job-timeout-must-exceed-a-gates-go-2026-09-26 — "CI job timeout must exceed a gate's Go -timeout or output is lost" (module: .github/workflows/umpire.yml)
  slicescollectmapskeys-turns-empty-into-2026-09-27 — "slices.Collect(maps.Keys) turns empty into nil; cmp.Or[error] trips SA4023" (module: common/testing/testpilot/temporal/worker)
  package-only-model-headers-need-normal-2026-10-06 — "Package-only Model headers need normal compilation in every caller" (module: Makefile)
  isolate-scala-cli-author-builds-after-2026-10-16 — "Isolate Scala CLI author builds after local macro jar changes" (module: model/framework/README.md)
  match-enum-values-rather-than-2026-10-18 — "Match enum values rather than references in empty derives" (module: model2/umpire/dsl/macros/src/action.rs)
  resolve-model-impl-identity-in-its-2026-10-19 — "Resolve Model impl identity in its original lexical and trait context" (module: model/umpire/dsl/macros/src/machine.rs)
  preserve-generic-declaration-context-in-2026-10-21 — "Preserve generic declaration context in generated adapters" (module: model/umpire/dsl/macros/src/machine/declared.rs)

bug/data/
  joined-composition-keys-must-be-checked-2026-09-28 — "Joined composition keys must be checked injective before keying rows" (module: model/Umpire/Command/Compose.lean)

bug/integration/
  portable-execution-boundaries-must-2026-09-03 — "Portable execution boundaries must preserve runtime context" (module: tools/umpire/runner/runner.go)
  portable-model-plans-need-exact-2026-09-03 — "Portable model plans need exact artifacts and checked obligations" (module: model/Temporal/Tool/PortableEvaluationContract.lean)
  portable-schemas-must-preserve-source-2026-09-03 — "Portable schemas must preserve source semantic kinds and cardinalities" (module: proto/internal/temporal/server/api/umpire/v1/portable_test_plan.proto)
  behavior-neutral-refactors-must-not-2026-09-04 — "Behavior-neutral refactors must not strengthen validation" (module: model/Umpire/Observation/Evaluation/Admission.lean)
  contract-work-bounds-must-follow-typed-2026-09-04 — "Contract work bounds must follow typed values" (module: tools/umpire/verification)
  full-integration-gates-must-select-the-2026-09-04 — "Full integration gates must select the complete migrated suite" (module: Makefile)
  program-admission-must-validate-2026-09-04 — "Program admission must validate producer kinds and bound repeated lookups" (module: tools/umpire/internal/execution)
  coverage-findings-must-retain-2026-09-05 — "Coverage findings must retain independent obligations and evidence" (module: model/Umpire/Planning/CaseAnalysis.lean)
  default-empty-extensions-must-preserve-2026-09-05 — "Default-empty extensions must preserve canonical fingerprints" (module: model/Umpire/Property/Check.lean)
  joint-conflict-scopes-require-realized-2026-09-05 — "Joint conflict scopes require realized trigger identity" (module: model/Umpire/Planning/CaseAnalysis.lean)
  keep-raw-semantics-behind-checked-input-2026-09-05 — "Keep raw semantics behind checked input boundaries" (module: model/Umpire/Property/Evaluation.lean)
  nested-admission-diagnostics-must-2026-09-05 — "Nested admission diagnostics must retain exact source coordinates" (module: model/Umpire/Property/Check.lean)
  reconciliation-must-preserve-authority-2026-09-05 — "Reconciliation must preserve authority, IDs, and references" (module: .plans/UMPIRE4_SPEC.md)
  reusable-cases-need-run-coordinates-and-2026-09-05 — "Reusable Cases need run coordinates and event-aligned captures" (module: model/Temporal/CaseRuntime.lean)
  validate-protobuf-descriptor-structure-2026-09-05 — "Validate protobuf descriptor structure before accepting same-name responses" (module: tools/umpire/internal/ir/runtime_value.go)
  moved-conformance-tests-must-not-import-2026-09-06 — "Moved conformance tests must not import functional adapters" (module: common/testing/testpilot/conformance_test.go)
  check-unbounded-lean-numbers-before-2026-09-07 — "Check unbounded Lean numbers before protobuf narrowing" (module: model/Umpire/Case/Compiler.lean)
  dual-purpose-coverage-maps-need-per-2026-09-09 — "Dual-purpose coverage maps need per-entry admissibility" (module: model/Umpire/Observation/Projection/Coverage.lean)
  homogeneous-owner-index-blocked-mixed-2026-09-09 — "Homogeneous owner index blocked mixed-schema field Properties" (module: model/Umpire/Property/Evaluation.lean)
  keyed-capture-operands-must-be-checked-2026-09-09 — "Keyed capture operands must be checked against their declaration" (module: model/Umpire/Property/Check.lean)
  portable-carriers-must-keep-the-checked-2026-09-09 — "Portable carriers must keep the checked namespace and type rules" (module: model/Testpilot/Scoped.lean)
  consolidated-extractor-dropped-a-2026-09-27 — "Consolidated extractor dropped a caller's nonempty-field rejection" (module: common/testing/testpilot/temporal/driver.go)
  every-scenario-command-scenario-carries-2026-09-27 — "Every scenario-command Scenario carries ordering; pinned schedules decide it" (module: model/Umpire/Search/Product/Scenario.lean)
  test-output-parsers-must-accept-tlog-2026-09-27 — "Test output parsers must accept t.Log file:line decoration" (module: tools/umpire/cmd/umpire-repeat/signature.go)
  a-checked-artifact-cannot-supply-its-2026-09-28 — "A checked artifact cannot supply its own completeness universe" (module: model/Umpire/Command/ComposeProofs.lean)
  feature-modules-must-import-temporal-2026-09-28 — "Feature modules must import Temporal conventions or IDs change family" (module: model/Temporal/Case/Conventions.lean)
  channel-catalogs-and-visible-results-2026-09-30 — "Channel catalogs and visible results must survive source lifting" (module: model/scalav2/lifter/Lift.scala)
  realized-controls-constrain-admission-2026-09-30 — "Realized controls constrain admission evidence compatibility" (module: model/scalav2/specimens/activity.md)
  paired-level-validators-must-check-each-2026-10-06 — "Paired level validators must check each artifact independently" (module: model/irgen/src/main/scala/modelir/lint/Structure.scala)
  transition-table-reads-must-omit-2026-10-06 — "Transition-table reads must omit realization-only refinement metadata" (module: tools/umpire/model/compose.go)
  retired-protobuf-names-must-guard-every-2026-10-09 — "Retired protobuf names must guard every top-level declaration kind" (module: tools/umpire/ir/schema_test.go)
  schema-closure-tests-must-compile-2026-10-09 — "Schema closure tests must compile imported generated declarations" (module: model/check/test/Gate.test.scala)
  output-relocation-must-scope-shared-2026-10-11 — "Output relocation must scope shared readers and publication" (module: tools/umpire/cmd/umpire-gen-cases)
  preserve-explicit-replay-bindings-when-2026-10-13 — "Preserve explicit replay bindings when sharing a Model" (module: tools/umpire/check/checking.go)
  encode-fixture-folder-names-before-2026-10-18 — "Encode fixture folder names before generating Rust identifiers" (module: model2/umpire/testing/src/discovery.rs)
  separate-archived-scan-roots-from-2026-10-18 — "Separate archived scan roots from historical source paths" (module: tools/umpire/ir)
  use-file-snapshots-for-reviewable-2026-10-18 — "Use file snapshots for reviewable external insta goldens" (module: model2/framework/samples/tests/kettle.rs)
  match-complete-macro-invocations-when-2026-10-19 — "Match complete macro invocations when selecting machine outcomes" (module: model/umpire/dsl/macros/src/machine.rs)
  preserve-rust-expression-and-inference-2026-10-20 — "Preserve Rust expression and inference contracts in path macros" (module: model/umpire/dsl/macros/src/path.rs)
  prove-result-shape-before-propagating-2026-10-21 — "Prove result shape before propagating generated-enum coverage" (module: model/temporal/annotate/syntax/src/realize.rs)
  required-numeric-generation-must-sample-2026-10-21 — "Required numeric generation must sample present candidates" (module: model/umpire/annotations/src/value.rs)
  preserve-scalar-bound-identities-when-2026-10-22 — "Preserve scalar bound identities when naming shared IR expressions" (module: model/umpire/front/src/body/vector.rs)
  rejected-delivery-steps-must-not-2026-10-22 — "Rejected delivery steps must not authorize callback replies" (module: model/temporal/feature/activity/temporal.rs)
  correlate-pending-proposals-with-2026-10-23 — "Correlate pending proposals with operation completion evidence" (module: model/temporal/feature/activity/temporal.rs)
  preserve-arithmetic-evaluation-roots-2026-10-23 — "Preserve arithmetic evaluation roots across empty domains and unused values" (module: model/umpire/lift/src/safety.rs)
  preserve-property-categories-and-bound-2026-10-23 — "Preserve property categories and bound native start-failure replay" (module: model/umpire/backends/apalache/src/replay.rs)
  facade-admission-must-normalize-dsl-2026-10-24 — "Facade admission must normalize DSL prefixes through grouped imports" (module: model/umpire/author/dsl/macros/src/roots.rs)
  match-terminal-failure-and-retained-2026-10-24 — "Match terminal failure and retained retry history separately" (module: model/temporal/feature/activity/temporal.rs)

bug/performance/
  authoring-comparisons-must-force-equal-2026-09-06 — "Authoring comparisons must force equal checker work" (module: model/Temporal/Feature/Nexus2/AuthoringTests.lean)
  canonical-identity-embeds-whole-2026-09-09 — "Canonical identity embeds whole generated schema (27MB per payload)" (module: model/Umpire/Operation/Canonical.lean)
  build-counterexample-paths-only-for-2026-10-18 — "Build counterexample paths only for failing predicates" (module: model2/framework/checker/src/explore.rs)

bug/runtime-errors/
  interface-nil-checks-must-cover-every-2026-09-04 — "Interface nil checks must cover every nil-capable kind" (module: tools/umpire/temporal/nexus/runner.go)
  monitor-closure-must-honor-cancellation-2026-09-04 — "Monitor closure must honor cancellation without rebuilding proofs" (module: tools/umpire/verification)
  freeze-contract-transitions-when-2026-09-05 — "Freeze Contract transitions when execution becomes incomplete" (module: tools/umpire/verification)
  retain-opaque-completion-authority-2026-09-05 — "Retain opaque completion authority across rejected acceptance" (module: tools/umpire/temporal/server)
  workflow-replay-must-complete-2026-09-05 — "Workflow replay must complete unfinished admissions once" (module: tools/umpire/temporal/worker)
  replay-rejection-lost-to-2026-09-27 — "Replay rejection lost to finalizePlanning's unsatisfiable-Scenario priority" (module: model/Umpire/Search.lean)
  field-alterations-must-range-over-2026-09-28 — "Field alterations must range over structure fields, not the reachable catalog" (module: model/Umpire/Command/Predicate.lean)
  finite-ir-admission-must-count-work-2026-09-30 — "Finite IR admission must count work before listing catalogs" (module: model/scalav2/goir)
  finite-search-requires-injective-2026-09-30 — "Finite search requires injective identity and bounded admission" (module: model/go/umpire)
  reconstruct-crash-resets-and-budget-2026-10-16 — "Reconstruct crash resets and budget updates atomically" (module: model/framework/dsl/StateField.scala)
  reject-async-methods-before-discarding-2026-10-19 — "Reject async methods before discarding generated call results" (module: model/umpire/dsl/macros/src/machine.rs)

bug/security/
  retain-backend-capture-handles-across-2026-10-23 — "Retain backend capture handles across untrusted process execution" (module: model/umpire/backends/tlc/src/process.rs)

bug/test-failures/
  differentials-must-enumerate-every-2026-09-28 — "Differentials must enumerate every search caller, not only declarations" (module: model/Umpire/Search/Tests/Differential.lean)
  gate-retry-polling-before-observing-2026-10-22 — "Gate retry polling before observing Scheduled evidence" (module: tests/testpilot_model_slice_test.go)

knowledge/decisions/
  host-verified-model-provenance-without-2026-09-03 — "Host-verified model provenance without protocol signatures" (module: Umpire PortableTestPlan provenance)

===== [11/11] dependencies: ids, titles, statuses, done summaries =====
- fn-237-activity-timeouts-heartbeat-and.1 [done] - Optional handler facts through native adapters and independent TLC replay
    Optional handler facts now pass through native adapters, independent SSA lowering, typed interpretation and both TLA emitters. The new generic fixture exercises four forced fact witnesses and clearing; all 799 old artifacts and 15 frozen originals remain byte-identical.
    
    Tier:session jev-unavailable(no_key), explicitAGENTS implementer6.1medium/reviewer6.1high; samefamilydisclose.
    stage: impl-review - ran [2026-10-24T11:46:40Z..2026-10-24T11:52:28Z] (SHIP; three fresh codex:gpt-6.1-sol:high draws, zero findings)
    baseline: green (focused six-crate command, exit 0 before edits)
    
    Full gates: make model-check exit 0, 401.5006 s; UMPIRE_BACKENDS=require make model-check exit 0, 561.2351 s; make model-time exit 0, 361.2700 s wall. Timed gate 352.224 s exceeds the 60 s soft target; inner loop 8.910 s meets 10 s. The individual test-stage timing 197.:00s is inconclusive and retained verbatim.
    
    Native fixture: 7 states, 31 edges. TLC: 57 distinct observer states, 248 generated; five counterexamples replayed. Controls cover all adapter combinations, Debug-only facts, native enabledness/rejection, SSA and canonical constructor refusals, source/IR fact-only mutants, exact replay vector forgeries and observer preservation. Required TLC executes both selected Worlds. Safety emission was controlled; live Apalache remains deferred.
    
    Correctness audit: one Should Fix, resolved with a red-to-green canonical-path control. Standards audit: zero findings. Primary review: all three draws SHIP. Reviewer and implementers are from the same family under the explicit routing choice.
    
    Evidence: .flow/artifacts/fn-237-activity-timeouts-heartbeat-and/ (execution record, raw quality reports, TLC witnesses, gate attempts, timing and manifests). Linked guest bytes are unchanged. All four writer worktrees were removed normally after verified task-owned archives. No Activity policy, optional-value support, old golden, canary pin or MILESTONES change. The broader legacy Go tooling baseline remains inherited red outside the active model gate.
    
    GATE_SKIPPED:model-check:green-receipt 5be80b30 - baseline reused from prior post-gate pass
    GATE_SKIPPED:model-check-required:green-receipt 5be80b30 - baseline reused from prior post-gate pass
    GATE_SKIPPED:model-time:green-receipt 51dc99f5 - baseline reused from prior post-gate pass
    
    Tracker sync: n/a (bridge inactive)
    
    stage: plan-sync - skipped(config: planSync.enabled != true)
- fn-237-activity-timeouts-heartbeat-and.2 [done] - Bounded nominal optional values through source binding, emission and decode
    Stored bounded nominal values and their optional forms now preserve authored identity, backing and bounds through native export, source binding, IR/interpreter, TLA emission, exact TLC decoding and typed replay. The independent no-fact optional_ticks fixture covers None/one/max countdowns, malformed values, eager defaults, all five CFG families and selected-World replay; activity policy and World-dependent fairness authoring remain outside this task.
    
    Tier: session jev-unavailable(no_key); explicit AGENTS implementer gpt-6.1-sol medium / reviewer gpt-6.1-sol high. Primary reviewer execution is evidenced by the explicit codex:gpt-6.1-sol:high command and three session receipts; review uses the same model family. No actual implementer model is inferred.
    
    stage: impl-review - ran [2026-10-24T15:11:10.948654Z..2026-10-24T15:17:40.261785Z], SHIP. Correctness/contracts/integration each report 0 introduced and 0 pre_existing findings. Raw reports, raw output archives, metadata and final receipt are retained under .flow/artifacts/fn-237-activity-timeouts-heartbeat-and/optional-values-primary-*.
    
    Baseline: green make model-check before source edits at e2f25dc292cf048d3b61e33b9b2b25e97fedaf97, actual kernel wait status/exit 0. The initial wrong-directory attempt is inconclusive and receives no credit. Early optional source refused before implementation. Compatibility controls for ordinary Some/None constants and fieldless Option enum failed 101 before the final no-bounded-descriptor guards, then all five source controls passed. Seven semantic mutants were detected by executed failing tests.
    
    Final executable source: 6f0fb85f56b20dfa1e94fbeb286f17ce2ae61a41. Subsequent commits contain Flow/evidence only. Actual final gates:
    
    - make model-check: exit 0, 498.206s, 679 passed test summaries.
    - UMPIRE_BACKENDS=require make model-check: exit 0, 635.305s, 679 passed test summaries; real TLC agreement and replay required.
    - make model-time: exit 0, wall 381.736s; gate 374.886s misses inherited 60s soft target, inner 6.660s meets 10s. No added wrapper kill timeouts.
    - make umpire-check-model-slice: exit 0, 65.546s.
    - make umpire-check-model-gaps: exit 0, 379.728s, both canonical mandatory parent assertions present. A stopped diagnostic reader may have consumed intermediate pipe stdout; diagnostic observation is inconclusive, with no verification credit or exact-output/count claim for that interval. The gate itself was unchanged and completed normally.
    - Final workspace fmt check: exit 0. Final full gates include strict workspace Clippy, docs, tests and wasm/Go consumers; focused affected-crate tests/strict Clippy and required fixture controls also passed as retained in implementation evidence.
    
    Final Verify classified FULL and the strict CLI honored all three final-source receipts:
    GATE_SKIPPED:model-check:green-receipt 6f0fb85f
    GATE_SKIPPED:model-check-required:green-receipt 6f0fb85f
    GATE_SKIPPED:model-time:green-receipt 6f0fb85f
    
    Native/interpreted None/one/max have states 2/3/5, edges 1/2/4, and exactly 0/1/3 Tick edges. Required TLC checks cover these selected Worlds and replay false claims. Native factories and source binding reject malformed selections; authored native invariants separately refute forged invalid starts/updates. Generic World::new/Machine/Checker remain infallible association/exploration boundaries. Apalache adaptation is compile-through, with no live optional-value claim.
    
    Fresh parallel quality audits found correctness 1 and standards 4 issues initially; the main-CFG selected-binding anchor, continuation refusal and module/document extraction fixes resolved them. Final and compatibility follow-ups both report 0 remaining/0 new; reports are preserved verbatim.
    
    All 827 pre-existing active artifacts and 15 original compatibility comparisons remain byte-exact, including metadata; only the new optional_ticks fixture has new expectations. Guest SHA-256 remains b4a4f57f1a64525ae568bd56a73eff85b0b253aeae44d9e4de3e2d88f546cf2a; no refresh or canary repin occurred. Original fn243 evidence and existing F fixture/bridge are preserved. The inherited broader legacy tools Go failure is not an all-repository green claim.
    
    Continuation guard: parent fn237 and fn243/fn228 remain open. Root owns future fairness prerequisite, Model3, binding4, fn2435 and fn2375 sequencing; no cancellation/fairness policy or MILESTONES edits were implemented here. Full evidence is optional-values-implementation-evidence.json, protected authority is optional-values-preserved-manifest.json, and the reproducible guard is optional-values-preserved-audit.py in the same artifact directory.
    
    stage: plan-sync - skipped(config: planSync.enabled != true)
- fn-237-activity-timeouts-heartbeat-and.6 [done] - World-selected exact fairness lists through independent source binding
    Model authors can select exact literal fair/only/without scopes through exhaustive World-only conditionals. Both source consumers validate World values, select every registered/progress plan before catalog membership, preserve registration and rebinding, and reserve possible generated names without unioning policy; compiled native callbacks and existing per-value WF semantics remain independent.
    
    Tier: session (jev-unavailable(no_key)); AGENTS implementer gpt-6.1-sol medium / reviewer gpt-6.1-sol high.
    
    stage: impl-review - ran [2026-10-24T17:27:27.542168+00:00..2026-10-24T17:33:24.034854Z], SHIP. Three actual codex:gpt-6.1-sol:high draws report zero introduced, zero pre-existing and no unaddressed R-IDs. Review uses the same model family. No actual implementer model is inferred. Reviewers inspected committed fresh verification evidence; their local checks used cached binaries because Cargo rebuilding was read-only, and they did not rerun required TLC.
    
    Baseline green before source edits. Actual exits were zero for model-check (493.938s), required model-check (697.328s) and model-time (401.697s). Base 52b2ed61b90e16090e5a4ebc2a4c037786de9388 was persisted before implementation. Concurrent source-free Flow/MILESTONES commits remain in the complete range and receive no task credit.
    
    Final executable source is 94e47d78789bb4de8bd2c372027e7785baa30545. Full gates at 01e2fee46829b3464088b9ba8d5bbdc26f10d8c1 exited zero:
    
    - make model-check: 497.288s; 702 Rust passes, zero failures, four ignored, plus active host checks.
    - UMPIRE_BACKENDS=require make model-check: 582.113s; 702 Rust passes, zero failures, four ignored; actual source/TLC agreement and semantic controls required.
    - make model-time: 352.388s wall; gate 343.787s misses the inherited 60s soft target, inner 8.454s meets 10s.
    
    Affected-crate tests, strict Clippy and final workspace fmt passed. Required fixture tests passed 7/7 in 44.19s. Maxima 1/2/3 have 3/6/9 states, 4/11/20 edges, 2/3/4 exact fair values and all 4/5/6 ordinary values allowed. Three source-readmitted TLC baselines replay one negative counterexample each. Four emitted WF mutants reach typed-replay verdict disagreement; heartbeat and stale-Poll lassos retain concrete ordinal, choice, outcome, facts and back-edge evidence. Source-only and metadata-only mutations refuse separately. All five nonempty CFG families retain the selected World.
    
    The existing Bound owner now compares progress metadata against effective original compiled scopes at reached states. Empty graphs invoke no progress callback and establish no agreement for unevaluated callbacks. Generic fixture interpretation uses the embedded tree; independently admitted fixture source is checked through TLC/native agreement. Raw shared-front interpretation at all three Worlds is covered by the TLA integration owner. These boundaries are explicit in world-fairness-proof-boundaries.md.
    
    Fresh quality audits found correctness zero and standards two mechanical size findings. Existing-private-owner and guide relocations resolved both; standards follow-up is zero. Initial relocation import failures were fixed without weakening old tests; final native tests and full gates pass. All raw reports and failed diagnostics are preserved.
    
    All 849 protected old artifacts and 15 original compatibility comparisons remain byte-exact, including O's new expectations and action_inputs controls. Guest SHA-256 remains b4a4f57f1a64525ae568bd56a73eff85b0b253aeae44d9e4de3e2d88f546cf2a; no refresh or repin occurred. The broader archived Scala/IR Go umbrella remains inherited red and is outside this active-gate claim.
    
    GATE_SKIPPED:model-check:green-receipt 01e2fee4
    GATE_SKIPPED:model-check-required:green-receipt 01e2fee4
    GATE_SKIPPED:model-time:green-receipt 01e2fee4
    
    Full evidence, archives and review receipt are under .flow/artifacts/fn-237-activity-timeouts-heartbeat-and/world-fairness-*. Four host subagents served two implementation lanes and two audit axes. Both task worktrees and branches were removed normally; no command remains running. This closes task .6 only. The parent and downstream activity/live obligations remain open; the conductor owns MILESTONES and the later HTML refresh.
    
    stage: plan-sync - skipped(config: planSync.enabled != true)

