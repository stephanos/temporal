use umpire_dsl::machine;
#[machine]
pub mod probe {
    use umpire_dsl::{Action, Finite, State, World, check};
    #[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Finite)]
    pub struct Ticks(#[inputs(1..=3)] pub u8);
    #[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Finite)]
    pub struct Remaining { #[inputs(0..=3)] pub ticks: u8 }
    #[derive(World)]
    pub struct World { pub timeout: Option<Ticks> }
    #[derive(State)]
    pub struct Model { pub left: Option<Remaining> }
    #[derive(Action, Copy)]
    pub enum Clock { Tick }

    impl Model {
        #[starts]
        fn initial(world: &World) -> impl IntoIterator<Item = Self> {
            [Self { left: None }]
        }
        #[on(Clock)]
        fn clock(&mut self, action: Clock, world: &World) {
            match action { Clock::Tick => { self.left = Self::tick(self.left); } }
        }
                fn tick(left: Option<Remaining>) -> Option<Remaining> {
            if left.is_some() && left.unwrap_or(Remaining { ticks: 0 }).ticks > 0 {
                Some(Remaining { ticks: left.unwrap_or(Remaining { ticks: 0 }).ticks - 1 })
            } else { left }
        }

        
    }
}
