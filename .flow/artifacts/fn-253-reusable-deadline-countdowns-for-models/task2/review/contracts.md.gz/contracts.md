## Findings

**Severity**: P3
**Confidence**: 100
**Classification**: introduced
**File:Line**: `model/design/deadline-countdowns.md:47`
**R-IDs**: [R1]
**Problem**: The verdict names the three split invariants as `policy_in_range`, `attempt_within_policy`, `countdowns_within_budget`. The measured probe (`prepare.py:85`, and all regenerated `activity-*.rs` variants at the lines Grep shows) names the third one `countdown_bounds`. The verdict's own line-counts table and `line-counts.json` also use `countdown_bounds`. A reader cross-checking the verdict against the archived rewrite will not find `countdowns_within_budget`.
**Suggestion**: Use `countdown_bounds` in the verdict's "Measured experiment" paragraph, optionally noting that R4's eventual production name is the spec's "countdowns within budget".

**FYI (non-blocking)**
- `summary.json` `representation` reads `bound1..255` (missing space). Cosmetic.
- The task's `Touches` lists only the verdict and `.flow/tmp/fn253-spike/**`; the change also lands `.flow/artifacts/.../task2/**` and a MILESTONES.md status update. Both are expected evidence/status-board writes, and the task's own Approach requires archiving the assets before scratch expiry, so this is consistent in spirit.

## What I verified

- **Refusal ownership (R1 core).** Every front-end anchor in the table resolves to the code that emits the quoted message: `body/expr.rs:320-323` ("unsupported expression"), `shape.rs:78-80` ("unsupported declaration"), `shape.rs:173-177` ("trait or generic impl"), `body/typer.rs:40` ("unsupported type"), `body/optional.rs:11-12` ("bounded newtypes must be nongeneric"), `body/mod.rs:231-237` ("only pure helper calls..."), `body/claim.rs:144-146` ("claim body supports check!..."), `library.rs:4-5` (closable/phased only). Reported spans match the regenerated probe sources in `.flow/tmp/fn253-spike/` byte-for-byte (e.g. `activity-local.rs:213` col 29, `activity-shared.rs:26` col 32, `activity-library.rs:145` col 5, `local-arm.rs:23` col 57).
- **Native compilation vs admission distinction.** `lifted.rs:17-20` confirms the macro embeds the admission `Result` and generates `Interprets` only on `Ok`. The retained `output/native-{local,library,shared,project-library}.log` all end in `Finished`, while the same sources are refused in `admission.jsonl`. The verdict states this correctly and makes no interpreter/TLC equivalence claim. The "initial-only calls admitted" explanation is backed by `shape.rs:223-225` (computed starts are not body-lowered).
- **Chosen API.** The signatures in the verdict match `countdown-proposed.rs` exactly; `tick` saturation, `arm` absence preservation, `armed(None)`/`expired(None)` false, `within` checking `N > 0` and `1..=N`/positive-remaining, `descends` as `after == tick(before)` all match the source. Laws are unit-returning `check!` bodies in the `closable.rs` style; `_holds` sketches are explicitly disclaimed. `check!`, `Finite`, `claim::evaluate`, `Verdict` exports the probes depend on exist in the production DSL crate.
- **Reproducibility.** Cargo.toml relative paths, `install-stubs.py` root assertions, and `run.sh` HEAD/PWD guards are mutually consistent with the verdict's reconstruction block. Rust 1.99.1 pin matches `model/umpire/mise.toml` and the `rust-toolchain.toml` files. Disposable-source hashes for the three installed DSL files equal the authored probe hashes in `summary.json`.
- **No production changes.** `model/umpire/author/dsl/src/lib.rs` has no `countdown*` module; `model/temporal/realization/src/` has no `countdown_spike.rs`. The diff touches only `.flow/`, `MILESTONES.md`, and the new design doc.
- **Handoff state.** `.flow/tmp/fn253-spike/` is present with `README.md` and `run.sh`; `.worktrees/fn2532-spike/` no longer exists.
- **Parked unknowns.** All three are answered or correctly parked: library-owned types chosen; authoring pattern chosen with the registered-library cost named; protocol sharing of the Temporal layer left as the owner's decision without being used to hold R1 open.

## Requirements coverage

| R-ID | Status | Evidence |
| --- | --- | --- |
| R1 | met | Rewrite performed in a disposable worktree, never merged; 16 refusals each with span and front-end owner; verdict chooses representation and Temporal-layer form |
| R2 | deferred | Owned by .3/.4/.5 per spec coverage table |
| R3 | deferred | Owned by .6 |
| R4 | deferred | Owned by .1/.7/.9 |
| R5 | deferred | Owned by .8 |
| R6 | deferred | Owned by .10 |

Unaddressed R-IDs: []

Classification counts: 1 introduced, 0 pre_existing.

```json
{"classification_counts":{"introduced":1,"pre_existing":0},"unaddressed":[]}
```

<verdict>SHIP</verdict>