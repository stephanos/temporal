Verification complete. Everything the verdict asserts about the front end checks out at the current tip, and the probe assets are internally consistent with the archived evidence.

**What I verified**

- Every refusal message in the table exists at the cited owner range: `shape.rs:79` and `:176`, `body/typer.rs:40`, `body/claim.rs:146`, `body/mod.rs:236`, `body/optional.rs:12`, `body/expr.rs:322`. The claim-delegation path at `body/claim.rs:168` really does recognise only `closable::`, and `library.rs:4–5` really has only the two fixed sources, as the doc states.
- The native-versus-admission distinction is accurately described: `lifted.rs:17–20` runs `admit_checks`, embeds the `Result`, and emits `Interprets` only on `Ok`, while `declare::machine` in `macros/src/lib.rs:64` is the only `?`-propagated phase. The doc cites exactly this.
- The probe's API dependencies exist: `umpire_front::read(&File, &[&ItemMacro])` with `Refusal::{Model, Hook}`, `#[macro_export] check!`, `claim::evaluate(..).verdict`, `Verdict::{Holds, Fails}`, and `Finite::domain() -> impl Iterator`.
- Probe mechanics are correct: `tick` saturates, `expired(None)` is false, `within` encodes `1..=configured <= N` matching the baseline `state_bounds` at `model.rs:361–423`, the `tick_priority` rewrite `expired(tick(x))` is equivalent to the baseline `is_some() && ticks <= 1`, and the `activity-example` test assertions follow from the code.
- Reproduction path: `install-stubs.py` parent-walk and `run.sh` HEAD/path guards resolve correctly for the documented `git worktree add --detach` recipe; the disposable-source hashes match the authored probe hashes they are copies of.
- No production source changed; scratch probe is present under `.flow/tmp/fn253-spike/`. (The `.worktrees` listing timed out so worktree removal is taken from the summary, not confirmed.)

**Findings**

- **Severity**: P3
- **Confidence**: 100
- **Classification**: introduced
- **File:Line**: `model/design/deadline-countdowns.md:47`
- **R-IDs**: [R1]
- **Problem**: The verdict says the preparer produces three split invariants named `policy_in_range`, `attempt_within_policy`, `countdowns_within_budget`. The archived rewrite (`probes/prepare.py:1262`, `line-counts.json`) names the third one `countdown_bounds`. A reader following the linked line-count file will not find the name the verdict quotes.
- **Suggestion**: Change the doc to `countdown_bounds`, or note that the spec's R4 name `countdowns_within_budget` is the target name for .7 and the probe used a shorter one.

- **Severity**: P3
- **Confidence**: 100
- **Classification**: introduced
- **File:Line**: `.flow/artifacts/fn-253-reusable-deadline-countdowns-for-models/task2/probes/prepare.py:1380`
- **R-IDs**: []
- **Problem**: `trait_impls.replace('Ticks {', 'Ticks {').replace('    impl countdown', '    impl countdown')` are two identity replacements. Dead code in a reproduction script invites the reader to look for an effect that does not exist.
- **Suggestion**: Use `trait_impls` directly.

**FYI (not findings)**

- `check-results.py` matches expected messages by substring, so "verified 21 exact outcome/message expectations" in the verdict is slightly stronger than the checker; outcomes are exact, messages are prefix-matched. Harmless given the manifest strings are near-complete.
- The `armed` substitution window in `prepare.py` runs from `fn deadline(` to `fn decrement(`, so it also spans `retry`, `expire_attempt` and `clear_terminal`, wider than the comment says. The asserted count of exactly one match per field confirms only the Tick guard matched, so the result is correct.
- Parked protocol-independence scope is handled correctly: the doc recommends independent authoring and explicitly leaves the permission decision to the owner without holding R1 open on it.

## Requirements coverage

| R-ID | Status | Evidence |
| --- | --- | --- |
| R1 | met | Worktree spike with 16 refusals, each with position, message and owner file range (all anchors verified); verdict chooses shared `Ticks<N>`/`Remaining<N>` and README pattern with reasons; six signatures fixed for .3; local-helper admission status stated with refusals; reproduction recipe and pinned lock archived. |
| R2 | deferred | Owned by .3/.4/.5. |
| R3 | deferred | Owned by .6. |
| R4 | deferred | Owned by .1/.7/.9. |
| R5 | deferred | Owned by .8. |
| R6 | deferred | Owned by .10. |

Unaddressed R-IDs: []

Classification counts: 2 introduced, 0 pre_existing.

```json
{"classification_counts":{"introduced":2,"pre_existing":0},"unaddressed":[]}
```

<verdict>SHIP</verdict>