import subprocess, json, datetime, hashlib, pathlib, os, sys
root=pathlib.Path.cwd(); proof=root/'.flow/tmp/fn2561-resume-20261030'
name=sys.argv[1]; command=sys.argv[2]; start=datetime.datetime.now(datetime.timezone.utc).isoformat()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
diff=subprocess.check_output(['git','diff','HEAD','--binary'])
env=os.environ.copy(); env['GOFLAGS']='-p=2'; env['CARGO_BUILD_JOBS']='2'
with (proof/(name+'.log')).open('wb') as f:
 p=subprocess.run(['bash','-c','cd '+str(root)+' && '+command],stdout=f,stderr=subprocess.STDOUT,env=env)
log=proof/(name+'.log')
r={'name':name,'command':command,'head':head,'source_diff_sha256':hashlib.sha256(diff).hexdigest(),'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':p.returncode,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'environment':{k:env.get(k) for k in ['GOFLAGS','GOCACHE','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','TMPDIR']}}
(proof/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n'); print(json.dumps(r)); print(log.read_text(errors='replace')[-2500:]); sys.exit(p.returncode)
