import subprocess,pathlib,re,hashlib,json
base='9212a1caed'; root=pathlib.Path.cwd(); removed=['ir','interp','check','realization','export','internal']; assert all(not (root/'tools/umpire'/p).exists() for p in removed)
files=subprocess.check_output(['git','ls-files'],text=True).splitlines(); bad=[]; exemption=[]
pattern=re.compile(r'(?:go.temporal.io/server/)?tools/umpire/(?:ir|interp|check|realization|export|internal)(?:[/`"\s]|$)|umpire-(?:install|check)-backends')
for p in files:
 if not pathlib.Path(p).is_file():continue
 if p.startswith(('model/archived/','.flow/','.plans/','.turbo/','docs/superpowers/')) or p=='common/testing/testpilot/dependency_boundary_test.go':continue
 if not (p.endswith(('.go','.md','.yml','.yaml','.toml','.sh')) or p=='Makefile'):continue
 for i,l in enumerate(pathlib.Path(p).read_text(errors='replace').splitlines(),1):
  if pattern.search(l):bad.append([p,i,l])
assert not bad,bad
current_map=pathlib.Path('.plans/UMPIRE_MODULES.md').read_text().split('## Historical Scala and Go migration ownership')[0]
assert not pattern.search(current_map)
assert '## Current Go tooling ownership' in current_map

protected=['model/archived','common/testing/testpilot/dependency_boundary_test.go']
assert not subprocess.check_output(['git','diff',base,'--',*protected])
s=pathlib.Path('Makefile').read_bytes(); old=subprocess.check_output(['git','show',base+':Makefile']); marker=b'##### Rust'; markers=[line for line in s.splitlines() if b'Rust' in line and line.startswith(b'#')];print('rust markers',markers)
# Stable suffix starts at the current independent native workspace declarations.
marker=b'##### model: Umpire in Rust (fn-210) #####'
assert marker in s and marker in old
assert s[s.index(marker):]==old[old.index(marker):]
r={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'removed':removed,'live_matches':bad,'archive_and_negative_fixture_unchanged_against':base,'rust_suffix_sha256':hashlib.sha256(s[s.index(marker):]).hexdigest(),'exemptions':['model/archived/**','historical .flow/.plans/.turbo and docs/superpowers records','common/testing/testpilot/dependency_boundary_test.go synthetic forbidden-import control']}
print(json.dumps(r,indent=2));pathlib.Path('.flow/tmp/fn2561-resume-20261030/source-audit.json').write_text(json.dumps(r,indent=2)+'\n')
