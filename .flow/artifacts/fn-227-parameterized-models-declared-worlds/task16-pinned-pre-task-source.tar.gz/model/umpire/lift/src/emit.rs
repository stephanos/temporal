use crate::{
    Action, Diagnostic, Field, Lifted, Metadata, Module, Progress, Property, Type, bind::Entry,
    names::operator,
};
use std::collections::BTreeMap;
use std::fmt::Write;
use umpire_front::{
    expr::{Expr, ExprKind, Op, Unary},
    tree::{ActionDef, ActionRef, AssumptionDef, Branch, FieldDef, Start},
};

/// The observer holding an edge's outcome.
pub(crate) const OUTCOME: &str = "__umpire_outcome";
pub(crate) const OBSERVERS: [&str; 7] = [
    "__umpire_edge_tick",
    "__umpire_pending",
    "__umpire_steps",
    "__umpire_action",
    "__umpire_choice",
    OUTCOME,
    "__umpire_facts",
];

#[expect(clippy::too_many_lines, reason = "Definitions are emitted in module dependency order")]
pub(crate) fn emit(model: &Lifted) -> Result<Module, Diagnostic> {
    if model.requires_binding() && (model.world_values.is_none() || model.complete_starts.is_none())
    {
        return Err(Diagnostic::of(
            &model.file,
            &model.location,
            "declared World requires a selected World and complete-start binding",
        ));
    }
    // Only Models with action inputs observe the concrete catalog ordinal of each edge.
    let inputs = model.has_inputs();
    let mut observers = OBSERVERS.to_vec();
    if inputs {
        observers.push(INPUT);
    }
    let mut out = String::new();
    line(&mut out, format!("---- MODULE {} ----", model.name));
    line(&mut out, "EXTENDS Integers, TLC, Sequences");
    if !model.world_fields.is_empty() {
        line(&mut out, format!("CONSTANTS {}", model.names.world.join(", ")));
    }
    let mut constants_cfg = String::new();
    if let Some(values) = &model.world_values {
        for (symbol, value) in model.names.world.iter().zip(values) {
            line(&mut constants_cfg, format!("CONSTANT {symbol} = {}", expr(value)));
        }
    }
    line(
        &mut out,
        r#"__umpire_Div(__umpire_a, __umpire_b) ==
    IF Assert(__umpire_b # 0, "Rust integer division by zero") /\ Assert(~(__umpire_a = (-2147483647 - 1) /\ __umpire_b = -1), "Rust integer division overflow")
    THEN IF __umpire_b = (-2147483647 - 1)
         THEN IF __umpire_a = (-2147483647 - 1) THEN 1 ELSE 0
         ELSE IF __umpire_a < 0
              THEN LET __umpire_d == IF __umpire_b < 0 THEN -__umpire_b ELSE __umpire_b
                       __umpire_n == -(__umpire_a + 1)
                       __umpire_q == __umpire_n \div __umpire_d
                       __umpire_r == __umpire_n - __umpire_q * __umpire_d
                       __umpire_negative == -__umpire_q - (IF __umpire_r = __umpire_d - 1 THEN 1 ELSE 0)
                   IN IF __umpire_b < 0 THEN -__umpire_negative ELSE __umpire_negative
              ELSE IF __umpire_b < 0 THEN -(__umpire_a \div (-__umpire_b)) ELSE __umpire_a \div __umpire_b
    ELSE 0"#,
    );
    line(&mut out, "");
    for (name, value) in &model.constants {
        let name = model.names.constants.get(name).unwrap_or(name);
        line(&mut out, format!("{name} == {}", expr(value)));
    }
    let fields: Vec<_> = model.fields.iter().map(|f| f.name.as_str()).collect();
    let mut variables = fields.clone();
    variables.extend(&observers);
    line(&mut out, format!("VARIABLES {}", variables.join(", ")));
    line(&mut out, format!("vars == <<{}>>", variables.join(", ")));
    line(&mut out, format!("ModelVars == <<{}>>", fields.join(", ")));
    line(&mut out, "");
    let mut initial = Vec::new();
    if let Some(starts) = &model.complete_starts {
        initial.push(disjoin(
            starts
                .iter()
                .map(|state| {
                    conjoin(
                        model
                            .fields
                            .iter()
                            .zip(state)
                            .map(|(field, value)| format!("{} = {}", field.name, expr(value))),
                    )
                })
                .collect(),
        ));
    } else {
        for field in &model.fields {
            initial.push(match &field.start {
                Start::Computed => {
                    return Err(Diagnostic::of(
                        &model.file,
                        &field.location,
                        "computed starts require a complete-start binding",
                    ));
                }
                Start::Value(value) => format!("{} = {}", field.name, expr(value)),
                Start::Range(lo, hi) => format!("{} \\in ({}..{})", field.name, expr(lo), expr(hi)),
                Start::ExclusiveRange(lo, hi) => format!(
                    "(IF {} < {} THEN {} \\in ({}..({} - 1)) ELSE FALSE)",
                    expr(lo),
                    expr(hi),
                    field.name,
                    expr(lo),
                    expr(hi)
                ),
            });
        }
    }
    let outcome_type = model.outcome_type.clone();
    initial.extend([
        "__umpire_edge_tick = FALSE".into(),
        "__umpire_pending = 0".into(),
        "__umpire_steps = 0".into(),
        "__umpire_action = \"\"".into(),
        "__umpire_choice = 0".into(),
        format!("__umpire_outcome = {}", default(&outcome_type)),
        "__umpire_facts = <<>>".into(),
    ]);
    if inputs {
        initial.push(format!("{INPUT} = 0"));
    }
    line(&mut out, format!("Init == {}", conjoin(initial)));
    line(&mut out, "");
    let catalog = model.catalog.as_deref().unwrap_or_default();
    for (index, action) in model.actions.iter().enumerate() {
        let entries: Vec<_> = catalog.iter().filter(|entry| entry.action == index).collect();
        let identity = if action.fields.is_empty() {
            entries.first().map(|entry| entry.ordinal.to_string())
        } else {
            Some(format!("{}_Inputs[{}][1]", operator(&action.name), model.names.index))
        };
        let identity = identity.as_deref();
        let mut shared = Shared::new(&model.names.shared);
        for branch in &action.branches {
            step(model, &action.name, branch, identity, &mut |value| {
                shared.count(value);
                String::new()
            });
        }
        let branches = action
            .branches
            .iter()
            .map(|branch| {
                conjoin(step(model, &action.name, branch, identity, &mut |value| {
                    shared.emit(value)
                }))
            })
            .collect();
        let branches = format!("{}{}", shared.definitions.concat(), disjoin(branches));
        if action.fields.is_empty() {
            line(&mut out, format!("{} == {branches}", operator(&action.name)));
        } else {
            input_relation(&mut out, model, index, &entries, branches);
        }
    }
    line(
        &mut out,
        format!(
            "ModelNext == {}",
            disjoin(model.actions.iter().map(|a| operator(&a.name)).collect())
        ),
    );
    line(&mut out, "ModelEdge == __umpire_edge_tick' # __umpire_edge_tick");
    line(
        &mut out,
        "Edge == ModelNext /\\ (__umpire_edge_tick' = ~__umpire_edge_tick) /\\ UNCHANGED <<__umpire_pending, __umpire_steps>>",
    );
    line(&mut out, "Complete == ~ENABLED ModelNext /\\ UNCHANGED vars");
    line(&mut out, "Next == Edge \\/ Complete");
    line(&mut out, "Spec == Init /\\ [][Next]_vars");
    line(&mut out, "");
    let mut cfg = format!("SPECIFICATION Spec\n{constants_cfg}");
    let invariants = model
        .invariants
        .iter()
        .map(|claim| {
            let operator = format!("Invariant_{}", claim.name);
            line(&mut out, format!("{operator} == {}", expr(&claim.expr)));
            line(&mut cfg, format!("INVARIANT {operator}"));
            Property {
                name: claim.name.clone(),
                cfg: format!("SPECIFICATION Spec\n{constants_cfg}INVARIANT {operator}\n"),
                operator,
            }
        })
        .collect();
    let postconditions = model
        .postconditions
        .iter()
        .map(|claim| {
            let operator = format!("Post_{}", claim.name);
            let applies = claim.after.as_ref().map_or_else(
                || "ModelEdge".into(),
                |action| format!("ModelEdge /\\ (__umpire_action' = {})", text(action)),
            );
            line(
                &mut out,
                format!("{operator} == [][~({applies}) \\/ ({})]_vars", expr(&claim.expr)),
            );
            line(&mut cfg, format!("PROPERTY {operator}"));
            Property {
                name: claim.name.clone(),
                cfg: format!("SPECIFICATION Spec\n{constants_cfg}PROPERTY {operator}\n"),
                operator,
            }
        })
        .collect();
    let negative = model
        .negative
        .iter()
        .map(|claim| {
            let operator = format!("Negative_{}", claim.name);
            line(&mut out, format!("{operator} == {}", expr(&claim.expr)));
            Property {
                name: claim.name.clone(),
                cfg: format!("SPECIFICATION Spec\n{constants_cfg}INVARIANT {operator}\n"),
                operator,
            }
        })
        .collect();
    for assumption in &model.assumptions {
        if model.progress.iter().any(|claim| claim.assumption.same_scope(assumption)) {
            line(
                &mut out,
                format!(
                    "Assumption_{} == {}",
                    assumption.name,
                    disjoin(scoped_relations(model, assumption))
                ),
            );
        }
    }
    let mut progress = Vec::new();
    for claim in &model.progress {
        let name = &claim.name;
        let allowed: Vec<_> = model
            .actions
            .iter()
            .enumerate()
            .filter(|(index, action)| {
                positions(model, *index, action)
                    .iter()
                    .any(|(_, reference, _)| claim.assumption.allows(reference))
            })
            .map(|(_, action)| action)
            .collect();
        let scoped = format!("Scoped_{name}");
        let scope = model
            .assumptions
            .iter()
            .find(|assumption| assumption.same_scope(&claim.assumption))
            .map_or_else(
                || disjoin(scoped_relations(model, &claim.assumption)),
                |assumption| format!("Assumption_{}", assumption.name),
            );
        line(&mut out, format!("{scoped} == {scope}"));
        line(
            &mut out,
            format!(
                "Activate_{name} == (__umpire_pending = 0) /\\ ({}) /\\ ~({}) /\\ (__umpire_pending' = 1) /\\ (__umpire_steps' = 0) /\\ UNCHANGED <<ModelVars, __umpire_edge_tick, __umpire_action, __umpire_choice, __umpire_outcome, __umpire_facts{}>>",
                expr(&claim.trigger),
                expr(&claim.target),
                if inputs { format!(", {INPUT}") } else { String::new() }
            ),
        );
        let count = claim.bound.map_or_else(
            || "0".into(),
            |bound| {
                format!(
                    "(IF __umpire_steps < {} THEN __umpire_steps + 1 ELSE __umpire_steps)",
                    bound + 1
                )
            },
        );
        let target = prime(&claim.target);
        line(
            &mut out,
            format!(
                "Monitor_{name} == (__umpire_edge_tick' = ~__umpire_edge_tick) /\\ (__umpire_pending' = (IF {} THEN 2 ELSE 1)) /\\ (__umpire_steps' = {count})",
                expr(&target)
            ),
        );
        line(
            &mut out,
            format!("ActiveEdge_{name} == (__umpire_pending = 1) /\\ {scoped} /\\ Monitor_{name}"),
        );
        line(&mut out, format!("PrefixEdge_{name} == (__umpire_pending = 0) /\\ Edge"));
        line(
            &mut out,
            format!(
                "Complete_{name} == ((__umpire_pending = 2) \\/ ((__umpire_pending = 1) /\\ ~ENABLED {scoped}) \\/ ((__umpire_pending = 0) /\\ ~ENABLED ModelNext)) /\\ UNCHANGED vars"
            ),
        );
        line(
            &mut out,
            format!(
                "ProgressNext_{name} == PrefixEdge_{name} \\/ Activate_{name} \\/ ActiveEdge_{name} \\/ Complete_{name}"
            ),
        );
        let mut spec = format!("Init /\\ [][ProgressNext_{name}]_vars");
        if claim.bound.is_none() {
            for (fair, relation) in fair_relations(model, name, &claim.assumption) {
                line(
                    &mut out,
                    format!("{fair} == (__umpire_pending = 1) /\\ {relation} /\\ Monitor_{name}"),
                );
                write!(spec, " /\\ WF_vars({fair})").ok();
            }
        }
        line(&mut out, format!("ProgressSpec_{name} == {spec}"));
        line(
            &mut out,
            format!(
                "Maximal_{name} == (([]<>__umpire_edge_tick) /\\ ([]<>(~__umpire_edge_tick))) \\/ (<>[]((__umpire_pending = 1) /\\ ~ENABLED {scoped}))"
            ),
        );
        let operator = format!("Progress_{name}");
        let mut property =
            format!("(Maximal_{name} => ((__umpire_pending = 1) ~> (__umpire_pending = 2)))");
        if let Some(bound) = claim.bound {
            write!(property, " /\\ [](__umpire_steps <= {bound})").ok();
        }
        line(&mut out, format!("{operator} == {property}"));
        progress.push(Progress {
            name: name.clone(),
            cfg: format!("SPECIFICATION ProgressSpec_{name}\n{constants_cfg}PROPERTY {operator}\n"),
            operator,
            allowed: allowed.iter().map(|a| a.name.clone()).collect(),
            fair: claim.assumption.fair.iter().fold(Vec::new(), |mut names, action| {
                if !names.contains(&action.name) {
                    names.push(action.name.clone());
                }
                names
            }),
            allowed_inputs: ordinals(model, inputs, |reference| claim.assumption.allows(reference)),
            fair_inputs: ordinals(model, inputs, |reference| {
                claim.assumption.allows(reference) && claim.assumption.is_fair(reference)
            }),
            bound: claim.bound,
        });
    }
    line(&mut out, "====");
    let max_steps = model
        .progress
        .iter()
        .filter_map(|p| p.bound)
        .max()
        .map_or(0, |bound| i128::from(bound) + 1);
    let mut observer_types = BTreeMap::from([
        ("__umpire_edge_tick".into(), Type::Bool),
        ("__umpire_pending".into(), Type::Int { min: 0, max: 2 }),
        ("__umpire_steps".into(), Type::Int { min: 0, max: max_steps }),
        ("__umpire_action".into(), Type::Text),
        ("__umpire_choice".into(), Type::Int { min: 0, max: 0 }),
        ("__umpire_outcome".into(), outcome_type.clone()),
        ("__umpire_facts".into(), Type::Seq(Box::new(Type::Unit))),
    ]);
    if inputs {
        let max = i128::try_from(catalog.len().saturating_sub(1)).unwrap_or(i128::MAX);
        observer_types.insert(INPUT.into(), Type::Int { min: 0, max });
    }
    Ok(Module {
        name: model.name.clone(),
        tla: out,
        cfg,
        metadata: Metadata {
            state_name: model.state_name.clone(),
            world_path: model.world_path.clone(),
            fields: model
                .fields
                .iter()
                .map(|f| Field { name: f.name.clone(), ty: f.ty.clone() })
                .collect(),
            actions: model
                .actions
                .iter()
                .map(|a| Action {
                    name: a.name.clone(),
                    operator: operator(&a.name),
                    internal: a.internal,
                    fields: a
                        .fields
                        .iter()
                        .map(|field| Field { name: field.name.clone(), ty: field.ty.clone() })
                        .collect(),
                })
                .collect(),
            catalog: if inputs { model.concrete() } else { Vec::new() },
            invariants,
            postconditions,
            progress,
            negative,
            observer_fields: observers.iter().map(|s| (*s).into()).collect(),
            observer_types,
            outcome_type,
        },
    })
}
/// One branch's conjuncts, with each of its expressions as `value` emits it.
fn step<'e>(
    model: &Lifted,
    action: &str,
    branch: &'e Branch,
    identity: Option<&str>,
    value: &mut dyn FnMut(&'e Expr) -> String,
) -> Vec<String> {
    let mut terms = vec![value(&branch.guard)];
    for check in &branch.checks {
        let check = value(check);
        terms.push(format!("({check}) = ({check})"));
    }
    let updated = |f: &FieldDef| {
        branch
            .updates
            .get(&f.name)
            .filter(|value| value.kind != ExprKind::Var(f.name.clone(), false))
    };
    let may_reject = !matches!(&branch.outcome.kind, ExprKind::Unit)
        && branch.outcome.kind != ExprKind::Enum(ACCEPTED.into());
    let changed: Vec<_> =
        model.fields.iter().filter_map(|f| updated(f).map(|update| (f, update))).collect();
    if may_reject && !changed.is_empty() {
        // A rejecting step that changed its state is a Model error, as natively.
        let outcome = value(&branch.outcome);
        let unchanged = conjoin(
            changed
                .iter()
                .map(|(f, update)| format!("{} = {}", value(update), f.name))
                .collect::<Vec<_>>(),
        );
        terms.push(format!(
            "Assert(({outcome} = {}) \\/ ({unchanged}), \"rejecting step changed state\")",
            text(ACCEPTED)
        ));
    }
    if !branch.preserve_self_loop {
        let mut steps: Vec<_> = model
            .fields
            .iter()
            .map(|f| {
                let next = branch.updates.get(&f.name).map_or_else(|| f.name.clone(), &mut *value);
                format!("{next} # {}", f.name)
            })
            .collect();
        // A rejection is emitted even when it leaves the state unchanged.
        if may_reject {
            steps.push(format!("{} # {}", value(&branch.outcome), text(ACCEPTED)));
        }
        terms.push(disjoin(steps));
    }
    for field in &model.fields {
        let next = branch.updates.get(&field.name).map_or_else(|| field.name.clone(), &mut *value);
        terms.push(format!("{}' = {next}", field.name));
    }
    terms.extend([
        format!("__umpire_action' = {}", text(action)),
        "__umpire_choice' = 0".into(),
        format!("__umpire_outcome' = {}", value(&branch.outcome)),
        "__umpire_facts' = <<>>".into(),
    ]);
    if model.has_inputs()
        && let Some(identity) = identity
    {
        terms.push(format!("{INPUT}' = {identity}"));
    }
    terms
}
pub(crate) const INPUT: &str = "__umpire_input";
/// The stock accepted outcome, as the front end spells it.
const ACCEPTED: &str = "Outcome::Accepted";

/// A payload variant's concrete inputs as `<<ordinal, values..>>` rows in catalog order, its
/// relation at one catalog position, and the finite existential choice over every position.
fn input_relation(
    out: &mut String,
    model: &Lifted,
    action: usize,
    entries: &[&Entry],
    branches: String,
) {
    let symbols = &model.names.inputs[action];
    let operator = operator(&model.actions[action].name);
    let index = &model.names.index;
    let rows = entries
        .iter()
        .map(|entry| {
            let mut row = vec![entry.ordinal.to_string()];
            row.extend(entry.values.iter().map(expr));
            format!("<<{}>>", row.join(", "))
        })
        .collect::<Vec<_>>();
    line(out, format!("{operator}_Inputs == <<{}>>", rows.join(", ")));
    let mut body = branches;
    for (position, symbol) in symbols.iter().enumerate().rev() {
        body = format!("LET {symbol} == {operator}_Inputs[{index}][{}] IN {body}", position + 2);
    }
    line(out, format!("{operator}_At({index}) == {body}"));
    line(
        out,
        format!("{operator} == \\E {index} \\in DOMAIN {operator}_Inputs : {operator}_At({index})"),
    );
}

/// Each concrete catalog position of a variant: its one-based position, exact identity and
/// canonical ordinal. A unit variant outside an input catalog is its own sole position.
fn positions(model: &Lifted, index: usize, action: &ActionDef) -> Vec<(usize, ActionRef, usize)> {
    let reference =
        |values: &[Expr]| ActionRef { name: action.name.clone(), values: values.to_vec() };
    match &model.catalog {
        Some(catalog) if model.has_inputs() => catalog
            .iter()
            .filter(|entry| entry.action == index)
            .enumerate()
            .map(|(position, entry)| (position + 1, reference(&entry.values), entry.ordinal))
            .collect(),
        _ => vec![(1, reference(&[]), 0)],
    }
}

/// The admitted relation of each variant: the whole existential relation when every
/// position is admitted, otherwise the choice restricted to the admitted exact positions.
fn scoped_relations(model: &Lifted, assumption: &AssumptionDef) -> Vec<String> {
    let mut relations = Vec::new();
    for (index, action) in model.actions.iter().enumerate() {
        let all = positions(model, index, action);
        let admitted: Vec<_> =
            all.iter().filter(|(_, reference, _)| assumption.allows(reference)).collect();
        if admitted.len() == all.len() {
            relations.push(operator(&action.name));
        } else if !admitted.is_empty() {
            let index = &model.names.index;
            let selected =
                admitted.iter().map(|(position, _, _)| position.to_string()).collect::<Vec<_>>();
            relations.push(format!(
                "\\E {index} \\in {{{}}} : {}_At({index})",
                selected.join(", "),
                operator(&action.name)
            ));
        }
    }
    relations
}

/// Weak fairness obligations: one per explicitly fair unit action, and one per exact fair
/// payload position, never one over a variant's existential union. Positional duplicates
/// share their canonical ordinal and so one obligation.
fn fair_relations(
    model: &Lifted,
    claim: &str,
    assumption: &AssumptionDef,
) -> Vec<(String, String)> {
    let mut relations = Vec::new();
    for (index, action) in model.actions.iter().enumerate() {
        let mut seen = Vec::new();
        for (position, reference, ordinal) in positions(model, index, action) {
            if !assumption.allows(&reference) || !assumption.is_fair(&reference) {
                continue;
            }
            let operator = operator(&action.name);
            if action.fields.is_empty() {
                relations.push((format!("Fair_{claim}_{operator}"), operator));
            } else if !seen.contains(&ordinal) {
                seen.push(ordinal);
                relations.push((
                    format!("Fair_{claim}_{operator}_{position}"),
                    format!("{operator}_At({position})"),
                ));
            }
        }
    }
    relations
}

/// Canonical catalog ordinals selected by a predicate, for typed progress metadata.
fn ordinals(model: &Lifted, inputs: bool, select: impl Fn(&ActionRef) -> bool) -> Vec<usize> {
    if !inputs {
        return Vec::new();
    }
    let mut out = Vec::new();
    for (index, action) in model.actions.iter().enumerate() {
        for (_, reference, ordinal) in positions(model, index, action) {
            if select(&reference) && !out.contains(&ordinal) {
                out.push(ordinal);
            }
        }
    }
    out
}

/// A typed expression as emitted TLA+, for diagnostics.
pub(crate) fn rendered(value: &Expr) -> String {
    expr(value)
}

fn line(out: &mut String, value: impl AsRef<str>) {
    out.push_str(value.as_ref());
    out.push('\n');
}
fn conjoin(terms: impl IntoIterator<Item = String>) -> String {
    let terms: Vec<_> = terms.into_iter().map(|s| format!("({s})")).collect();
    if terms.is_empty() { "TRUE".into() } else { terms.join(" /\\ ") }
}
fn disjoin(terms: Vec<String>) -> String {
    if terms.is_empty() {
        "FALSE".into()
    } else {
        terms.into_iter().map(|s| format!("({s})")).collect::<Vec<_>>().join(" \\/ ")
    }
}
fn text(value: &str) -> String {
    format!(
        "\"{}\"",
        value
            .replace('\\', "\\\\")
            .replace('"', "\\\"")
            .replace('\n', "\\n")
            .replace('\r', "\\r")
            .replace('\t', "\\t")
    )
}
fn default(ty: &Type) -> String {
    match ty {
        Type::Bool => "FALSE".into(),
        Type::Int { .. } => "0".into(),
        Type::Enum { variants, .. } => text(&variants[0]),
        Type::Text => "\"\"".into(),
        Type::Unit | Type::Seq(_) => "<<>>".into(),
        Type::Tuple(types) => {
            format!("<<{}>>", types.iter().map(default).collect::<Vec<_>>().join(", "))
        }
    }
}
fn prime(value: &Expr) -> Expr {
    let kind = match &value.kind {
        ExprKind::Var(name, _) => ExprKind::Var(name.clone(), true),
        ExprKind::Unary(op, value) => ExprKind::Unary(*op, Box::new(prime(value))),
        ExprKind::Binary(op, left, right) => {
            ExprKind::Binary(*op, Box::new(prime(left)), Box::new(prime(right)))
        }
        ExprKind::If(cond, yes, no) => {
            ExprKind::If(Box::new(prime(cond)), Box::new(prime(yes)), Box::new(prime(no)))
        }
        ExprKind::Sequence(values) => ExprKind::Sequence(values.iter().map(prime).collect()),
        ExprKind::Checks(values) => ExprKind::Checks(values.iter().map(prime).collect()),
        ExprKind::Length(value) => ExprKind::Length(Box::new(prime(value))),
        ExprKind::Append(sequence, value) => {
            ExprKind::Append(Box::new(prime(sequence)), Box::new(prime(value)))
        }
        ExprKind::GetOr(sequence, index, fallback) => ExprKind::GetOr(
            Box::new(prime(sequence)),
            Box::new(prime(index)),
            Box::new(prime(fallback)),
        ),
        other => other.clone(),
    };
    Expr { kind, ty: value.ty.clone() }
}
fn checked(raw: String, ty: &Type) -> String {
    if let Type::Int { min, max } = ty {
        format!(
            "(IF Assert(({raw}) \\in ({}..{}), \"checked Rust integer overflow\") THEN ({raw}) ELSE ({raw}))",
            integer(*min),
            integer(*max)
        )
    } else {
        raw
    }
}
fn quotient(left: &str, right: &str, ty: &Type) -> String {
    let quotient = format!("__umpire_Div(({left}), ({right}))");
    if let Type::Int { min, .. } = ty
        && *min < 0
    {
        format!(
            "(IF Assert(~(({left}) = {} /\\ ({right}) = -1), \"Rust signed division/remainder overflow\") THEN {quotient} ELSE 0)",
            integer(*min)
        )
    } else {
        quotient
    }
}
fn expr(value: &Expr) -> String {
    render(value, &mut |child| expr(child))
}
/// One node as TLA+, with each child as `child` emits it, once per textual occurrence.
fn render<'e>(value: &'e Expr, child: &mut dyn FnMut(&'e Expr) -> String) -> String {
    let mut list =
        |values: &'e [Expr]| values.iter().map(&mut *child).collect::<Vec<_>>().join(", ");
    match &value.kind {
        ExprKind::Bool(v) => {
            if *v {
                "TRUE".into()
            } else {
                "FALSE".into()
            }
        }
        ExprKind::Int(v) => integer(*v),
        ExprKind::Text(v) | ExprKind::Enum(v) => text(v),
        ExprKind::Unit => "<<>>".into(),
        ExprKind::Var(name, primed) => format!("{name}{}", if *primed { "'" } else { "" }),
        ExprKind::World(name) | ExprKind::Input(name) => name.clone(),
        ExprKind::Outcome => format!("{OUTCOME}'"),
        ExprKind::Tuple(values) | ExprKind::Sequence(values) => format!("<<{}>>", list(values)),
        ExprKind::Length(sequence) => format!("Len({})", child(sequence)),
        ExprKind::Checks(checks) => {
            format!("(<<{}>> = <<{}>>)", list(checks), vec!["TRUE"; checks.len()].join(", "))
        }
        ExprKind::Append(sequence, value) => {
            format!("Append({}, {})", child(sequence), child(value))
        }
        ExprKind::GetOr(sequence, index, fallback) => {
            let sequence = child(sequence);
            let index = child(index);
            let fallback = child(fallback);
            format!(
                "(IF ({fallback}) = ({fallback}) THEN (IF ({index}) < Len({sequence}) THEN ({sequence})[({index}) + 1] ELSE ({fallback})) ELSE ({fallback}))"
            )
        }
        ExprKind::Unary(op, inner) => {
            let inner = child(inner);
            match op {
                Unary::Not => format!("~({inner})"),
                Unary::Neg => checked(format!("-({inner})"), &value.ty),
            }
        }
        ExprKind::If(condition, yes, no) => {
            format!("(IF {} THEN {} ELSE {})", child(condition), child(yes), child(no))
        }
        ExprKind::Binary(op, left, right) => {
            let left = child(left);
            let right = child(right);
            let symbol = match op {
                Op::Add => "+",
                Op::Sub => "-",
                Op::Mul => "*",
                Op::And => "/\\",
                Op::Or => "\\/",
                Op::Eq => "=",
                Op::Ne => "#",
                Op::Lt => "<",
                Op::Le => "<=",
                Op::Gt => ">",
                Op::Ge => ">=",
                Op::Div | Op::Rem => "",
            };
            let raw = match op {
                Op::Div => quotient(&left, &right, &value.ty),
                Op::Rem => {
                    format!("({left}) - ({}) * ({right})", quotient(&left, &right, &value.ty))
                }
                _ => format!("({left}) {symbol} ({right})"),
            };
            if matches!(op, Op::Add | Op::Sub | Op::Mul | Op::Div | Op::Rem) {
                checked(raw, &value.ty)
            } else {
                format!("({raw})")
            }
        }
    }
}

/// The subexpressions one step operator repeats, each emitted once as a `LET` definition when
/// it is longer than `SHARED`. The front end lowers each statement over the values before it,
/// so a later condition or update re-reads whole earlier values; inlined, the text multiplies
/// with every conditional return and checked operation, while shared it stays linear.
struct Shared<'a> {
    nodes: std::collections::HashMap<&'a Expr, Node>,
    definitions: Vec<String>,
    prefix: &'a str,
}
#[derive(Default)]
struct Node {
    /// Textual occurrences: under each distinct parent, and as a root.
    uses: usize,
    /// Inlined length, saturating.
    length: usize,
    name: Option<String>,
}
const SHARED: usize = 400;
impl<'a> Shared<'a> {
    fn new(prefix: &'a str) -> Self {
        Self { nodes: std::collections::HashMap::new(), definitions: Vec::new(), prefix }
    }
    /// Count one textual occurrence of `value`, and its children's the first time.
    fn count(&mut self, value: &'a Expr) {
        let node = self.nodes.entry(value).or_default();
        node.uses += 1;
        if node.uses > 1 {
            return;
        }
        let mut children = Vec::new();
        let mut length = render(value, &mut |child| {
            children.push(child);
            String::new()
        })
        .len();
        for child in children {
            self.count(child);
            length = length.saturating_add(self.nodes[child].length);
        }
        if let Some(node) = self.nodes.get_mut(value) {
            node.length = length;
        }
    }
    fn emit(&mut self, value: &'a Expr) -> String {
        let shared =
            self.nodes.get(value).is_some_and(|node| node.uses > 1 && node.length > SHARED);
        if !shared {
            return render(value, &mut |child| self.emit(child));
        }
        if let Some(name) = self.nodes.get(value).and_then(|node| node.name.clone()) {
            return name;
        }
        let body = render(value, &mut |child| self.emit(child));
        let name = format!("{}{}", self.prefix, self.definitions.len() + 1);
        self.definitions.push(format!("LET {name} == {body} IN "));
        if let Some(node) = self.nodes.get_mut(value) {
            node.name = Some(name.clone());
        }
        name
    }
}

fn integer(value: i128) -> String {
    if value == i128::from(i32::MIN) { "(-2147483647 - 1)".into() } else { value.to_string() }
}
