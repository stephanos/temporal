use umpire::dsl::machine;
#[machine]
pub mod generated {
    use umpire::dsl::{Action, Finite, State, check, reject, Rejection};
    #[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash, Finite)]
    pub enum Mode { #[default] Off,  On }
    #[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Finite)]
    pub struct Token(#[inputs(0..=1)] pub u8);
    #[derive(Debug)]
    pub enum Fact { Changed }
    #[derive(State)]
    pub struct Model {
        pub left: Mode,
        pub right: Mode,
        #[starts(0..=0)]
        pub count: u8,
        pub token: Option<Token>,
    }
    #[derive(Action, Copy)]
    pub enum User { Advance, Toggle, Clear, Refuse }
    impl Model {
        #[on(User)]
        fn user(&mut self, action: User) -> Option<Fact> {
            match action {
                User::Advance if self.count < 1 => {
                    self.count += 1;
                    self.token = Some(Token(0));
                    Some(Fact::Changed)
                }
                User::Toggle => {
                    self.left = if self.left == Mode::Off { Mode::On } else { Mode::Off };
                    self.right = if self.right == Mode::Off { Mode::On } else { Mode::Off };
                    Some(Fact::Changed)
                }
                User::Clear if self.token.is_some() => { self.token = None; Some(Fact::Changed) }
                User::Refuse => { self.refuse(); None }
                _ => None,
            }
        }
        #[effect]
        fn refuse(&mut self) { reject!(Rejection::NotFound); }
        #[invariant]
        fn bounded(&self) { check!(self.count <= 1); }
    }
}
