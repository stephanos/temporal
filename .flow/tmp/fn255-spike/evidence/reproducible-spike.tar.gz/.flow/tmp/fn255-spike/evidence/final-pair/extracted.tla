---- MODULE Generated ----
EXTENDS Integers, TLC, Sequences
\* @type: (Int, Int) => Int;
__umpire_Div(__umpire_a, __umpire_b) ==
    IF Assert(__umpire_b # 0, "Rust integer division by zero") /\ Assert(~(__umpire_a = (-2147483647 - 1) /\ __umpire_b = -1), "Rust integer division overflow")
    THEN IF __umpire_b = (-2147483647 - 1)
         THEN IF __umpire_a = (-2147483647 - 1) THEN 1 ELSE 0
         ELSE IF __umpire_a < 0
              THEN LET (* @type: Int; *) __umpire_d == IF __umpire_b < 0 THEN -__umpire_b ELSE __umpire_b
                       (* @type: Int; *) __umpire_n == -(__umpire_a + 1)
                       (* @type: Int; *) __umpire_q == __umpire_n \div __umpire_d
                       (* @type: Int; *) __umpire_r == __umpire_n - __umpire_q * __umpire_d
                       (* @type: Int; *) __umpire_negative == -__umpire_q - (IF __umpire_r = __umpire_d - 1 THEN 1 ELSE 0)
                   IN IF __umpire_b < 0 THEN -__umpire_negative ELSE __umpire_negative
              ELSE IF __umpire_b < 0 THEN -(__umpire_a \div (-__umpire_b)) ELSE __umpire_a \div __umpire_b
    ELSE 0

VARIABLE \* @type: Str;
left
VARIABLE \* @type: Str;
right
VARIABLE \* @type: Int;
count
VARIABLE \* @type: Int;
token
VARIABLE \* @type: Bool;
__umpire_edge_tick
VARIABLE \* @type: Int;
__umpire_pending
VARIABLE \* @type: Int;
__umpire_steps
VARIABLE \* @type: Str;
__umpire_action
VARIABLE \* @type: Int;
__umpire_choice
VARIABLE \* @type: Str;
__umpire_outcome
VARIABLE \* @type: Seq(Str);
__umpire_facts
\* @type: <<Str, Str, Int, Int, Bool, Int, Int, Str, Int, Str, Seq(Str)>>;
vars == <<left, right, count, token, __umpire_edge_tick, __umpire_pending, __umpire_steps, __umpire_action, __umpire_choice, __umpire_outcome, __umpire_facts>>
\* @type: <<Str, Str, Int, Int>>;
ModelVars == <<left, right, count, token>>

\* @type: Bool;
Init == (left = "Mode::Off") /\ (right = "Mode::Off") /\ (count \in (0..1)) /\ (token = 0) /\ (__umpire_edge_tick = FALSE) /\ (__umpire_pending = 0) /\ (__umpire_steps = 0) /\ (__umpire_action = "") /\ (__umpire_choice = 0) /\ (__umpire_outcome = "Outcome::Accepted") /\ (__umpire_facts = <<>>)

\* @type: Bool;
User_Advance == (LET (* @type: Int; *) __umpire_l1 == (IF Assert(((count) + (1)) \in (0..255), "checked Rust integer overflow") THEN ((count) + (1)) ELSE ((count) + (1))) IN LET (* @type: Int; *) __umpire_l2 == (IF Assert(((1) + 1) \in (1..2147483647), "checked Rust integer overflow") THEN ((1) + 1) ELSE ((1) + 1)) IN (((count) < (1))) /\ (((IF Assert(((count) + (1)) \in (0..255), "checked Rust integer overflow") THEN ((count) + (1)) ELSE ((count) + (1)))) = ((IF Assert(((count) + (1)) \in (0..255), "checked Rust integer overflow") THEN ((count) + (1)) ELSE ((count) + (1))))) /\ (((IF Assert(((1) + 1) \in (1..2147483647), "checked Rust integer overflow") THEN ((1) + 1) ELSE ((1) + 1))) = ((IF Assert(((1) + 1) \in (1..2147483647), "checked Rust integer overflow") THEN ((1) + 1) ELSE ((1) + 1)))) /\ ((left # left) \/ (right # right) \/ (__umpire_l1 # count) \/ (__umpire_l2 # token)) /\ (left' = left) /\ (right' = right) /\ (count' = __umpire_l1) /\ (token' = __umpire_l2) /\ (__umpire_action' = "User::Advance") /\ (__umpire_choice' = 0) /\ (__umpire_outcome' = "Outcome::Accepted") /\ (__umpire_facts' = <<"Fact::Changed">>)) \/ ((((~(((count) < (1)))) /\ (TRUE))) /\ ((left # left) \/ (right # right) \/ (count # count) \/ (token # token)) /\ (left' = left) /\ (right' = right) /\ (count' = count) /\ (token' = token) /\ (__umpire_action' = "User::Advance") /\ (__umpire_choice' = 0) /\ (__umpire_outcome' = "Outcome::Accepted") /\ (__umpire_facts' = <<>>))
\* @type: Bool;
User_Toggle == (LET (* @type: Str; *) __umpire_l1 == (IF ((left) = ("Mode::Off")) THEN "Mode::On" ELSE "Mode::Off") IN LET (* @type: Str; *) __umpire_l2 == (IF ((right) = ("Mode::Off")) THEN "Mode::On" ELSE "Mode::Off") IN (TRUE) /\ (((IF ((left) = ("Mode::Off")) THEN "Mode::On" ELSE "Mode::Off")) = ((IF ((left) = ("Mode::Off")) THEN "Mode::On" ELSE "Mode::Off"))) /\ (((IF ((right) = ("Mode::Off")) THEN "Mode::On" ELSE "Mode::Off")) = ((IF ((right) = ("Mode::Off")) THEN "Mode::On" ELSE "Mode::Off"))) /\ ((__umpire_l1 # left) \/ (__umpire_l2 # right) \/ (count # count) \/ (token # token)) /\ (left' = __umpire_l1) /\ (right' = __umpire_l2) /\ (count' = count) /\ (token' = token) /\ (__umpire_action' = "User::Toggle") /\ (__umpire_choice' = 0) /\ (__umpire_outcome' = "Outcome::Accepted") /\ (__umpire_facts' = <<"Fact::Changed">>)) \/ ((FALSE) /\ ((left # left) \/ (right # right) \/ (count # count) \/ (token # token)) /\ (left' = left) /\ (right' = right) /\ (count' = count) /\ (token' = token) /\ (__umpire_action' = "User::Toggle") /\ (__umpire_choice' = 0) /\ (__umpire_outcome' = "Outcome::Accepted") /\ (__umpire_facts' = <<>>))
\* @type: Bool;
User_Clear == ((~(((token) = (0)))) /\ ((0) = (0)) /\ ((left # left) \/ (right # right) \/ (count # count) \/ (0 # token)) /\ (left' = left) /\ (right' = right) /\ (count' = count) /\ (token' = 0) /\ (__umpire_action' = "User::Clear") /\ (__umpire_choice' = 0) /\ (__umpire_outcome' = "Outcome::Accepted") /\ (__umpire_facts' = <<"Fact::Changed">>)) \/ ((((~(~(((token) = (0))))) /\ (TRUE))) /\ ((left # left) \/ (right # right) \/ (count # count) \/ (token # token)) /\ (left' = left) /\ (right' = right) /\ (count' = count) /\ (token' = token) /\ (__umpire_action' = "User::Clear") /\ (__umpire_choice' = 0) /\ (__umpire_outcome' = "Outcome::Accepted") /\ (__umpire_facts' = <<>>))
\* @type: Bool;
User_Refuse == ((TRUE) /\ (left' = left) /\ (right' = right) /\ (count' = count) /\ (token' = token) /\ (__umpire_action' = "User::Refuse") /\ (__umpire_choice' = 0) /\ (__umpire_outcome' = "Outcome::Rejected(NotFound)") /\ (__umpire_facts' = <<>>)) \/ ((FALSE) /\ ((left # left) \/ (right # right) \/ (count # count) \/ (token # token)) /\ (left' = left) /\ (right' = right) /\ (count' = count) /\ (token' = token) /\ (__umpire_action' = "User::Refuse") /\ (__umpire_choice' = 0) /\ (__umpire_outcome' = "Outcome::Accepted") /\ (__umpire_facts' = <<>>))
\* @type: Bool;
ModelNext == (User_Advance) \/ (User_Toggle) \/ (User_Clear) \/ (User_Refuse)
\* @type: Bool;
ModelEdge == __umpire_edge_tick' # __umpire_edge_tick
\* @type: Bool;
Edge == ModelNext /\ (__umpire_edge_tick' = ~__umpire_edge_tick) /\ UNCHANGED <<__umpire_pending, __umpire_steps>>
\* @type: Bool;
Complete == ~ENABLED ModelNext /\ UNCHANGED vars
\* @type: Bool;
Next == Edge \/ Complete
\* @type: Bool;
Spec == Init /\ [][Next]_vars

\* @type: Bool;
Invariant_bounded == (<<((count) <= (1))>> = <<TRUE>>)

VARIABLE spike_has_step
VARIABLE spike_before_left
VARIABLE spike_before_right
VARIABLE spike_before_count
VARIABLE spike_before_token

SpikeInit == Init /\ spike_has_step = FALSE /\ spike_before_left = left /\ spike_before_right = right /\ spike_before_count = count /\ spike_before_token = token
SpikeNext == Edge /\ spike_has_step' = TRUE /\ spike_before_left' = left /\ spike_before_right' = right /\ spike_before_count' = count /\ spike_before_token' = token
====
