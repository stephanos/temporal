#![forbid(unsafe_code)]
use umpire::dsl::{Machine, ActionValues};
use umpire_checker::Interpreted;
mod adapters;
mod case_0;
mod case_1;
fn main() -> Result<(), Box<dyn std::error::Error>> {
 let mut snapshots = Vec::new();
{
        use case_0::generated;
        let world = generated::world;
        let identity = |a: &<generated::World as Machine>::Action| ActionValues::<generated::World>::action_value(a).0.into();
        let interpreted = Interpreted::new(world())?;
        let compiled = adapters::agree(adapters::native(&world(), identity), adapters::native(&interpreted, identity))?;
        std::fs::write(std::path::Path::new(&std::env::var("FN255_EVIDENCE")?).join("native-0.txt"), format!("{compiled:#?}"))?;
        snapshots.push(compiled.clone());
        if !false && std::env::var_os("FN255_CONTROLS_ONLY").is_none() {
        let source = include_str!("case_0.rs");
        let module = umpire_tla::Tla::emit(&umpire_tla::Lift::parse("case_0.rs", source)?)?;
        let checked = adapters::tlc(std::path::Path::new("/Users/stephan/Workspace/skunkworks/umpire/temporal/.worktrees/prep2551-generator/.flow/tmp/fn255-spike/evidence/tools"), &module)?;
        std::fs::write(std::path::Path::new(&std::env::var("FN255_EVIDENCE")?).join("tlc-0.txt"), format!("{checked:#?}"))?;
        adapters::agree(Ok(compiled), Ok(checked))?;
        }
        adapters::lowering_controls(world)?;
        println!("case=0 seed=201190345 complete");
    }
{
        use case_1::generated;
        let world = generated::world;
        let identity = |a: &<generated::World as Machine>::Action| ActionValues::<generated::World>::action_value(a).0.into();
        let interpreted = Interpreted::new(world())?;
        let compiled = adapters::agree(adapters::native(&world(), identity), adapters::native(&interpreted, identity))?;
        std::fs::write(std::path::Path::new(&std::env::var("FN255_EVIDENCE")?).join("native-1.txt"), format!("{compiled:#?}"))?;
        snapshots.push(compiled.clone());
        if !false && std::env::var_os("FN255_CONTROLS_ONLY").is_none() {
        let source = include_str!("case_1.rs");
        let module = umpire_tla::Tla::emit(&umpire_tla::Lift::parse("case_1.rs", source)?)?;
        let checked = adapters::tlc(std::path::Path::new("/Users/stephan/Workspace/skunkworks/umpire/temporal/.worktrees/prep2551-generator/.flow/tmp/fn255-spike/evidence/tools"), &module)?;
        std::fs::write(std::path::Path::new(&std::env::var("FN255_EVIDENCE")?).join("tlc-1.txt"), format!("{checked:#?}"))?;
        adapters::agree(Ok(compiled), Ok(checked))?;
        }
        adapters::lowering_controls(world)?;
        println!("case=1 seed=3068600943 complete");
    }
Ok(())
}
